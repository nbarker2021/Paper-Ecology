﻿# FLCR-34 - Electron-Hole-Exciton Accounting

**Series:** Formalizing LCR, Unifying Standard Models  
**Artifact:** formal paper source  
**Status:** first-pass rich rewrite; requires final citation and build pass.  
**Claim posture:** maximal local claim posture with explicit lane boundaries.

## Abstract

This paper formalizes electron-hole-exciton formalism as standard-model-adjacent accounting for residues. The operative object is exciton accounting. The core result is that standard electron, hole, recombination, screening, and exciton models can explain part of the open residue surface when material context is declared. The paper also defines how this result routes forward: FLCR-34 supplies the missing condensed-matter bridge for papers that need carrier-pair accounting. Its main residue is explicit: material-specific bands, lifetimes, mobilities, and spectra require data-bound calibration.

## Keywords

exciton accounting; LCR; receipt; claim lane; normal form.

## 1. Contribution And Scope

- Defines exciton accounting as a first-class FLCR object.
- States the local result: standard electron, hole, recombination, screening, and exciton models can explain part of the open residue surface when material context is declared.
- Routes downstream use through claim lanes rather than inherited prose: FLCR-34 supplies the missing condensed-matter bridge for papers that need carrier-pair accounting.
- Preserves the residue boundary: material-specific bands, lifetimes, mobilities, and spectra require data-bound calibration.

This paper is part of the LCR-native base layer. Standard Model or physical
language is permitted only as deferred mapping, analogy, or explicitly bounded
future calibration. The editable surface is the claim lane and source-routing
layer; the base objects must remain stable enough for downstream papers to
consume them without ambiguity.

## 2. Source Routing

Primary routed sources:

- `NP-12_Electron_Hole_Exciton_Accounting_For_Open_Math.md`
- `supplements/SM_BRIDGE_SUPPLEMENT.md`

Cross-corpus evidence classes:

- `CAM_CLAIM_100_SCORE_AUDIT.md`
- `NSIT_TOOL_CLOSURE_MATRIX.md`
- `NSIT_REASONED_CLOSURE_PASS.md`
- `PAPER_REWORKS_CRYSTAL_PROJECTION.json`
- Kimi standards, glue, window, and node databases where applicable
- NotebookLM review prompts and orbital source manifests

## 3. Definitions

- **Hole.** The standard quasiparticle absence state in a band model.
- **Exciton.** A bound electron-hole excitation requiring material-specific parameters.
- **Receipt boundary.** The exact scope in which the paper's result can be replayed or consumed.
- **Promotion route.** The evidence path required before a stronger downstream claim can use this result.

## 4. Formal Claims

| Claim | Lane | Statement |
|-------|------|-----------|
| Theorem 34.1 | `standard_theorem_citation_bound_result` | standard electron, hole, recombination, screening, and exciton models can explain part of the open residue surface when material context is declared |
| Proposition 34.2 | `normal_form_result` | exciton accounting can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 34.3 | `falsifier_or_open_obligation` | material-specific bands, lifetimes, mobilities, and spectra require data-bound calibration |

## 5. Paper-Specific Development

1. Identify the local object and its assigned sources for FLCR-34.
2. Separate what is internally receipt-bound from what is citation-bound, CAM-bound, calibration-bound, or still an obligation.
3. State the strongest admissible claim in its current lane.
4. Export only the lane-safe result to downstream papers and preserve the residue.

### Proof Sketch

The proof strategy for FLCR-34 is a typed construction argument. The paper names hole as the active object, binds it to the routed legacy and orbital sources, and then allows downstream use only through the declared claim lane. This does not erase stronger ambitions; it keeps them addressable as dependencies, calibration tasks, or falsifiers.

## 6. Construction

The construction is intentionally staged. First, the paper names the finite or
typed object that can be inspected directly. Second, it declares the admissible
operations over that object. Third, it records the receipt or source class that
allows another paper to consume the result. Fourth, it names the residue that
must not be silently promoted.

For this paper, the operative object is `Electron-Hole-Exciton Accounting`. Its safe consumption
rule is:

```text
source object -> declared operation -> receipt/lane -> downstream import
```

The unsafe consumption rule is:

```text
source phrase -> downstream identity claim
```

That second pattern is explicitly rejected by FLCR-01 and must be rewritten as
a claim-lane promotion with evidence.

## 7. Evidence And Receipts

| Evidence source | What it contributes |
|-----------------|---------------------|
| Legacy paper body | Primary formal and source-integration material assigned by the series map. |
| Internal and pyramid supplements | Cross-paper reasoning windows, deferred back-application slots, and route constraints. |
| NSIT tool closure matrix | Existing verifier/tool families that can close internal or batch claims. |
| CAM/crystal and Kimi evidence | Projected memory, source routing, standards reports, and window/node databases. |

### Standard Model Definition Dependencies

This paper consumes the dedicated Standard Model Defining layer. These papers define the external Standard Model or adjacent standard-physics object before this FLCR paper translates it into LCR language.

| SMD paper | Definition surface | Required use |
|---|---|---|
| `SMD-01` | Standard Model Definition Contract And Evidence Boundary | Definition surface that must be cited before this paper promotes the corresponding Standard Model-facing claim. |
| `SMD-07` | Higgs Sector, Vacuum Structure, And Mass Terms | Definition surface that must be cited before this paper promotes the corresponding Standard Model-facing claim. |
| `SMD-10` | Electron Hole Exciton And Condensed Matter Correspondence | Definition surface that must be cited before this paper promotes the corresponding Standard Model-facing claim. |
| `SMD-12` | Standard Model Comparator And Falsifier Protocol | Definition surface that must be cited before this paper promotes the corresponding Standard Model-facing claim. |

This paper also imports SMB-01, the Standard Model Closure Bridge. SMB-01 supplies the closure-by-lane rule: rows are no longer treated as unresolved by default; they are closed when standard formalism, FLCR proof, CAM/crystal reapplication, normal-form translation, or external calibration satisfies the lane, and they remain obligations only when a required field is missing.

### Closed Rows Applied In This Paper

| Row | Closure | Evidence | Boundary |
|---|---|---|---|
| Hole as effective vacancy carrier | closed by standard condensed-matter formalism | `SMD-10`, exciton source registry | Closes the meaning of hole inside band/effective theory. |
| Exciton as electron-hole bound state | closed by standard formalism | `SMD-10` | Closes vocabulary and model class, not material-specific values. |
| LCR vacancy/residue analogy | closed as normal-form correspondence | `FLCR-03`, `FLCR-16`, `SMD-10` | Closes addressability/bookkeeping analogy only. |

This paper can now make the stronger claim that electron-hole-exciton formalism is an available standard model for vacancy, complement, recombination, screening, and bound-state behavior. LCR can use that formalism where it preserves the distinction between standard material model and internal residue address.

### Active Comparator Rows

| Comparator | External side | LCR side | Current result | Next required action |
|---|---|---|---|---|
| Hole/vacancy | unoccupied band state | open residue/vacancy slot | correspondence closed | Keep as model correspondence unless a material system is named. |
| Exciton bound state | electron-hole pair with effective mass/screening | paired residue/excitation lane | formalism closed | Add material parameters for quantitative claims. |
| Recombination/relaxation | material-dependent process | correction/repair path | analogy only | Requires dataset, rate equation, or simulation. |

### Executable Evidence Bound In This Pass

This paper now treats electron-hole-exciton formalism as a closed external vocabulary when material assumptions are stated, and as an open calibration row when material parameters are missing. That lets the paper stop treating holes and excitons as mysterious placeholders while still preserving the boundary around measured material behavior.

| Evidence | Path | Result imported here | Boundary preserved |
|---|---|---|---|
| Electron-hole-exciton definition surface | `SMD-10` | Closes the standard vocabulary: hole as an unoccupied state in a filled band with positive effective carrier behavior; exciton as an electron-hole bound state modeled by screening and effective masses. | Does not close material-specific binding energy, recombination, transport, or ontology beyond the model. |
| Exciton source registry | `D:/Paper Reworks/publication_series/Formalizing_LCR_Unifying_Standard_Models/standard_model_defining_papers/IRL_STANDARD_MODEL_SOURCE_REGISTRY.json` | Supplies `IRL-EXCITON-SPRINGER` and `IRL-EXCITON-2D-REVIEW` as citation-bound external sources. | External sources close definitions and formal targets, not FLCR-specific physical identity. |
| NSIT reasoned closure pass | `D:/Paper Reworks/NSIT_REASONED_CLOSURE_PASS.md` | States that electron-hole-exciton formalism closes a large part of the vacancy/complement vocabulary for papers 07, 15, 16, and 22. | Requires material model, Hamiltonian/equations, units, and citation/data before measured claims promote. |

The upgraded claim is: FLCR-34 can use electron-hole-exciton formalism to explain vacancy/residue bookkeeping where the analogy is explicitly declared and the material model is named. The paper cannot claim material-specific exciton energies or recombination behavior without parameter rows.

### Online Source Rows Applied In This Pass

| Online source | Claim-lane effect | Boundary retained |
|---|---|---|
| `IRL-EXCITON-2D-REVIEW` | Closes standard electron-hole-exciton vocabulary: bound electron-hole pairs, reduced screening, stronger Coulomb interactions, and material-dependent exciton physics. | Material-specific binding and recombination remain parameter/data-bound. |
| `IRL-NIST-CARRIER-DYNAMICS` | Supplies experimental/metrology lane for exciton formation, electron-hole separation, recombination, and free-carrier dynamics. | Measurements require a chosen material system and protocol. |
| `IRL-NIST-PV-EXCITON` | Supplies materials row for exciton separation into free electrons and holes at heterojunction interfaces. | Does not turn LCR vacancy bookkeeping into a measured material claim. |

Online data therefore closes the claim that electron-hole-exciton formalism is available and relevant. The remaining work is mapping a specific LCR residue to a specific material model and measured dataset.

### Assertive Closure Promotions

| Row | Closure now allowed | Evidence | Residue moved out of the open row |
|---|---|---|---|
| Hole vocabulary | closed by standard formalism | `SMD-10`, `IRL-EXCITON-2D-REVIEW` | Ontological claim beyond the model. |
| Exciton vocabulary | closed by standard formalism | `SMD-10`, exciton review, NIST carrier/PV sources | Material-specific binding, lifetime, recombination. |
| LCR vacancy/residue correspondence | closed as bookkeeping/addressability analogy when declared | `NSIT_REASONED_CLOSURE_PASS`, `SMD-10` | Measured material claim without parameters. |

The non-timid conclusion is: the electron-hole-exciton bridge is not an open mystery. It is solved as a standard-formalism correspondence and remains data-bound only for specific materials.

## 8. Dependencies And Downstream Use

This paper may be imported by later FLCR papers only through the claim lanes
above. The default downstream consumers are:

- `FLCR-11` through `FLCR-18` for window, receipt, admission, CA, algebraic,
  curvature, residue, and exceptional machinery.
- `FLCR-28` through `FLCR-30` for CAM/crystal, corpus ribbon, and universal
  normal-form intake.
- `FLCR-31` through `FLCR-40` only after the LCR-native result has been cited
  and the translation claim has its own evidence lane.

## 9. Limitations And Falsifiers

- material-specific bands, lifetimes, mobilities, and spectra require data-bound calibration
- External calibration claims require units, datasets, citations, and reproducible data binding.
- A later translation paper may strengthen this result only by adding the missing lane evidence.

A falsifier for this paper is any example that satisfies the declared input
conditions while violating the stated construction, receipt, or lane boundary.
An interpretation that merely wants a stronger downstream conclusion is not a
falsifier; it is an obligation routed to a later paper.

## 10. Publication Readiness Tasks

- Attach exact validator paths and receipt hashes.
- Replace source-family references with final citation entries where external
  theorems are used.
- Run the claim-lane validator against every theorem, proposition, and protocol.
- Regenerate LaTeX and final PDF after `pandoc` or `pdflatex` is available.

## Dual Positioning: Story And Formal Carrier

This paper must be read in two synchronized ways. Sequentially, it explains why
the next state exists in the corpus story. Formally, it binds that state to
accepted mathematics, IRL formalism, code receipts, validators, CAM/crystal
lookups, and claim-lane boundaries.

Assigned original ribbon role(s): orbital publication overlay.

| Original slot | Family | Lift | Role | Proof form |
|---|---|---:|---|---|
| orbital | publication overlay | n/a | no legacy original slot assigned yet | intake and routing proof |

The formal obligation is to state the strongest valid claim available for this
paper without letting interpretation silently change the addressed object. Any
author interpretation belongs beside the formalism as a declared relabeling,
bridge, or analog, and must be accompanied by the evidence lane that makes the
claim consumable by later papers.

## State-Bound Proof Contract

This paper receives: mature LCR-native corpus and orbital evidence intake.

It must produce: Electron-Hole-Exciton Accounting as publication overlay or synthesis route.

Semantic transition: route external, comparative, or synthesis material around the original proof ribbon without overwriting original slot obligations.

Accepted formalism targets to bind in the journal rewrite:

- source routing and dependency graphs
- citation-bound comparison
- normal-form correspondence tables
- falsifier and calibration boundaries

| Slot | Contract |
|---|---|
| orbital | publication overlay; must declare sources, dependencies, and calibration/falsifier boundaries |

The rewrite should use these accepted tools as the formal carrier and should
keep the author's interpretation as an explicit relabeling, correspondence, or
bridge. A claim may strengthen only when a receipt, standard citation,
CAM/crystal reapplication, normal-form result, calibration datum, or falsifier
boundary is attached.

## Past Work And Crystal Evidence Expansion

This pass expands the paper from prior work, CAM/crystal projections, NSIT
tooling, Kimi windows, and routed supplements. The intent is not to paste
source text wholesale. The intent is to bind each useful past result into this
paper's state-bound proof role.

### Expansion Rule For This Slot

Use past work as orbital evidence: route all imports through dependency, citation, normal-form, calibration, and falsifier lanes.

### Routed Full Sources

| Source | Placement reason |
|---|---|
| `NP-12_Electron_Hole_Exciton_Accounting_For_Open_Math.md` | primary assigned source for the paper's formal spine |
| `supplements/SM_BRIDGE_SUPPLEMENT.md` | primary assigned source for the paper's formal spine |

### Routed Partial/Orbital Sources

| Source | Placement reason |
|---|---|
| `supplements/SM_BRIDGE_SUPPLEMENT.md` | cross-cutting supplement; import only paper-relevant rows, receipts, or guard language |
| `supplements/RECEIPT_VERIFIER_CATALOG.md` | cross-cutting supplement; import only paper-relevant rows, receipts, or guard language |
| `supplements/INTERNAL_REASONING_PYRAMID_INDEX.md` | cross-cutting supplement; import only paper-relevant rows, receipts, or guard language |
| `supplements/INTERNAL_REASONING_5P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; import only paper-relevant rows, receipts, or guard language |
| `supplements/INTERNAL_REASONING_7P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; import only paper-relevant rows, receipts, or guard language |
| `supplements/INTERNAL_REASONING_9P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; import only paper-relevant rows, receipts, or guard language |
| `CAM_CLAIM_100_SCORE_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_TOOL_CLOSURE_MATRIX.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_REASONED_CLOSURE_PASS.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `ORBITAL_DATA_CROSS_POPULATION_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `AGENT_CRYSTAL_WORK_HARVEST.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `PAPER_REWORKS_CRYSTAL_PROJECTION.json` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| additional routed sources | 4 more entries remain in `SOURCE_PLACEMENT.md` |

### Crystal And Standards Evidence To Bind

- Paper Reworks crystal projection: 33 paper markdown files, 9 supplements, 5 queues, 6 lattice-forge unification artifacts, 140 faces, 140 vignettes, and 280 CAM nodes.
- Kimi standards/window intake: 192/192 corpus conformance verdicts PASS; 140/142 obligations have candidate routes; 2/4/8/16/32 window lattice is available for cross-paper reads.
- Agent crystal harvest: Claude memory, Kimi MannyAI starter, D:/MannyAI current build, repo-harvest CAM, NotebookLM/MannyAI bundles, and downloaded crystal payloads are orbital evidence surfaces.
- NSIT inventory baseline: 220 validators, 1786 receipt/data artifacts, 1137 formal-paper-like artifacts, 114 supplements, and 86 memory/CAM artifacts.

### Paper-Specific CAM/Score Rows

No direct `00-32` CAM score row is assigned; use this paper as an orbital or translation intake.

### Paper-Specific NSIT Closure Rows

No direct NSIT row matched the assigned legacy papers in the first-pass matrix; search validators by object name during the next receipt pass.

### Source Signals Extracted For Rewrite

- `NP-12_Electron_Hole_Exciton_Accounting_For_Open_Math.md`: # NP-12 â€” Electron-Hole-Exciton Accounting For Open Math **Status:** active study / reasoned closure candidate. ## Publication Draft: Formal Scientific Body ### Abstract that some open physical bridge claims may be ordinary semiconductor or The study will classify each candidate claim into one of four buckets: requires_cqecmplx_receipt overclaimed_or_rejected ### Claim-Strength Correction This paper is not only a guard against overclaiming. It is also a guard against underclaiming. If standard condensed-matter formalism already supplies the standard_model_closed_pending_citation_or_data_bind The remaining CQECMPLX claim is then narrower and stronger: CQECMPLX supplies addressability, obligation state, routing, and receipts. ### Keywords state; recombination; band gap; physical bridge; claim taxonomy. ### Core Question ### First Research Pass: Standard Formalism addressing, receipt, and o
- `supplements/SM_BRIDGE_SUPPLEMENT.md`: # Standard Model Bridge Supplement ## Purpose This supplement carries Standard Model bridge material so Paper 13 and its neighboring physics papers can stay focused. It separates algebraic transport, receipt-backed charge bookkeeping, bridge estimates, and physical numeric gaps. ## Claim Boundary - Closed structural layer: `U(1) x SU(2) x SU(3)` carrier bookkeeping where receipts exist. - Closed bridge layer: Standard Model charge table, anomaly cancellation from that table, SU(5) charge embedding, SU(5) observer decomposition when verifier-backed. ## Spine Routing | Quark/color transport | Paper 13 | Preserve charge-table/anomaly/SU(5) receipts without bloating Paper 13. | | Observer post-SU3 route | Paper 19 | Preserve observer decomposition and numeric gap status. | | Monster/energy bounds | Paper 29 | Keep speculative/high-bound status fenced. | ## Source Intake Log ## Archive/Mirror

### Required Rewrite Use

1. Promote any already-receipted internal result into the formal claim ledger
   with its receipt or validator path.
2. Convert each CAM/crystal/Kimi item into either a citation/evidence row, a
   workbook replay step, or a named open obligation.
3. Preserve the author's interpretation as label/correspondence work unless a
   receipt, standard theorem, normal form, calibration datum, or falsifier lane
   supports stronger language.

## Claim Binding Queue

This queue converts the reasoned closure pass into paper-local work. It states
which claims may be strengthened now, which evidence must be attached next, and
which residues must remain separate.

| Queue | Promote now | Bind next | Residue |
|---|---|---|---|
| Electron-Hole-Exciton Standard Accounting | Promote standard hole/exciton vocabulary and LCR vacancy/residue bookkeeping when SMD-10 is cited. | Bind material model, band structure, effective masses, screening, and parameter rows before material-specific claims. | Binding energy, recombination, lifetime, and transport stay calibration/data-bound. |

### Binding Discipline

Each queue item must be applied as a delta:

```text
local claim at paper time
-> attached later source/tool/receipt/theorem
-> revised representation
-> invariant boundary and remaining residue
```

This preserves the sequential story while allowing later tools, crystals, and
standard formalisms to return through the proper lane.

## Claim Delta Ledger

This ledger applies the paper's claim-binding queues as explicit back-application
deltas. It keeps the sequential paper story intact while allowing later
receipts, standard formalisms, CAM/crystal routes, and validators to sharpen the
claim.

| Delta | Local claim at paper time | Later evidence | Revised representation | Boundary kept |
|---|---|---|---|---|
| Search By Object Name | No direct reasoned-closure queue was assigned from the first queue map. | Search source routing, verifier catalog, CAM/crystal routes, and paper-local object names. | Create a specific binding queue when an object-name match finds a validator, receipt, theorem, or calibration route. | Until then, claims remain in their existing lanes. |

The revised representation is the strongest phrasing available for the current
paper draft. It should be moved into the main theorem/proposition language only
when the named evidence is attached in the manifest or workbook replay.

## Archive Evidence Cards And Source-Backed Upgrades

This section imports routed archive/mirror source cards directly into the paper.
Each card is a compact provenance object: source path, archive score, contribution,
routed spine paper, and integration action.

| Source card | Score | Contribution | Integration action |
|---|---:|---|---|
| SMD-10: Electron Hole Exciton And Condensed Matter Correspondence | 100 | Defines hole, exciton, screening, effective-mass, and material-boundary vocabulary for FLCR-34. | Use as definition surface; do not promote material-specific behavior without parameters and data. |
| NSIT reasoned closure: electron-hole-exciton formalism | 95 | Reclassifies vacancy/complement language as largely closed by standard formalism when material assumptions are stated. | Route material-specific rows to calibration/data. |

### Material Claim Upgrades From Cards

| Upgrade target | Evidence card | How it improves the paper | Boundary |
|---|---|---|---|
| definition-surface replay | SMD-10 electron-hole-exciton | Use this card to fill the hole/exciton vocabulary, source registry, and material-boundary rows. | No material-specific claim promotes without material parameters. |
| reasoned-closure replay | NSIT electron-hole-exciton standard accounting | Use this card to reclassify vacancy/residue language from open metaphor to standard-formalism correspondence where applicable. | Binding, recombination, lifetime, and transport remain data-bound. |

These upgrades should be folded into the main body during the next prose rewrite:
definitions should become more specific, proof sketches should cite the relevant
receipt/tool/card, and limitations should preserve the card's stated boundary.

## Journal Apparatus

### Article Type And Intended Venue Fit

This manuscript is written as a formal-methods and mathematical-systems paper
inside the series *Formalizing LCR, Unifying Standard Models*. Its intended
reader is a technical reviewer who needs claim boundaries, reproducibility
routes, and cross-paper dependencies to be visible without relying on private
context.

### Structured Contribution Statement

| Item | Statement |
|---|---|
| Publication ID | `FLCR-34` |
| Legacy source slot(s) | `orbital` |
| Ribbon role | routes external, standard-model, or synthesis material around the original proof ribbon |
| Proof form | source intake, correspondence table, dependency statement, and falsifier boundary |
| Received state | mature LCR-native corpus and orbital evidence intake |
| Produced state | Electron-Hole-Exciton Accounting as publication overlay or synthesis route |

### Claim-Evidence Table

| Claim | Lane | Evidence to attach | Boundary |
|---|---|---|---|
| Theorem 34.1 | `standard_theorem_citation_bound_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | standard electron, hole, recombination, screening, and exciton models can explain part of the open residue surface when material context is declared |
| Proposition 34.2 | `normal_form_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | exciton accounting can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 34.3 | `falsifier_or_open_obligation` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | material-specific bands, lifetimes, mobilities, and spectra require data-bound calibration |

### Figure Plan

| Figure | Purpose | Caption |
|---|---|---|
| FLCR-34-F1 | Publication overlay dependency map | Schematic showing how `FLCR-34` turns its received state into the produced state while preserving claim lanes and residue boundaries. |
| FLCR-34-F2 | Evidence routing map | Diagram of source papers, archive cards, CAM/crystal routes, validators, and workbook replay paths used by this manuscript. |
| FLCR-34-F3 | Same-family lift context | Diagram placing this paper in the original `00-79` ribbon family and showing predecessor/successor slots. |

### In-Text Figure FLCR-34-F1: Publication overlay dependency map

```text
received state
  -> Publication overlay dependency map
  -> formal claim lane
  -> evidence object / receipt / citation
  -> produced state
  -> remaining residue
```

### Table Plan

| Table | Purpose |
|---|---|
| FLCR-34-T1 | Dependency and translation table |
| FLCR-34-T2 | Claim-lane/evidence-boundary table |
| FLCR-34-T3 | Archive evidence card and source-backed upgrade table |
| FLCR-34-T4 | Workbook replay and falsifier table |

### Worked Example

Route one standard-model or synthesis claim back to its LCR-native source papers. The example must name the input object, the operation,
the evidence object, the allowed revised claim, and the remaining boundary.

### Nomenclature And Glossary

| Term | Paper-local meaning |
|---|---|
| CAM | Defined by this paper as part of the `publication_overlay` proof role; final copyedit should replace this row with the exact paper-local definition. |
| claim lane | Defined by this paper as part of the `publication_overlay` proof role; final copyedit should replace this row with the exact paper-local definition. |
| crystal | Defined by this paper as part of the `publication_overlay` proof role; final copyedit should replace this row with the exact paper-local definition. |
| dependency | Defined by this paper as part of the `publication_overlay` proof role; final copyedit should replace this row with the exact paper-local definition. |
| publication overlay | Defined by this paper as part of the `publication_overlay` proof role; final copyedit should replace this row with the exact paper-local definition. |
| receipt | Defined by this paper as part of the `publication_overlay` proof role; final copyedit should replace this row with the exact paper-local definition. |
| synthesis lane | Defined by this paper as part of the `publication_overlay` proof role; final copyedit should replace this row with the exact paper-local definition. |
| translation claim | Defined by this paper as part of the `publication_overlay` proof role; final copyedit should replace this row with the exact paper-local definition. |

### Appendix FLCR-34-A: Evidence Package

The appendix for this paper should contain:

1. Legacy source excerpts or source-card references used in the final claim ledger.
2. Receipt and verifier paths, including pass/fail/partial status.
3. CAM/crystal query or projection rows used by the paper.
4. Kimi/NSIT/window evidence used for conformance or routing.
5. Falsifier, calibration, or external-data rows that remain unresolved.

### Data And Code Availability

All editable source files, manifests, source-routing matrices, validation
reports, and generated PDF/TeX outputs are local to:

```text
D:\Paper Reworks\publication_series\Formalizing_LCR_Unifying_Standard_Models
D:\Paper Reworks\FINAL_PAPERS_FLCR_UNIFIED
```

Code and verifier references are cited by path in the manifest, archive evidence
cards, receipt catalog, or workbook replay tables. External datasets or
standards citations must be attached before any calibration-bound claim is
promoted.

### Reviewer Checklist

| Check | Reviewer question |
|---|---|
| Claim lane | Does every strong claim declare its lane and evidence type? |
| Boundary | Does the paper preserve what it does not prove? |
| Reproducibility | Is there a receipt, verifier, source card, citation, or replay table for the claim? |
| Cross-paper import | Does the paper cite the prior FLCR/OPR slot before consuming its result? |
| Interpretation | Does the analog layer preserve the addressed state while changing labels/access paths? |

### Declarations

No human-subjects, clinical, or animal-research protocol is asserted by this
paper. External empirical claims require separate dataset, calibration, or
domain-validation attachments. Competing-interest and funding statements remain
to be supplied by the author before submission.

## 11. Peer-Review Expansion Pass 34

### 11.1 Sequential Carry-Forward

Prior paper carry-forward: `FLCR-33` produced formal result of original slot 15 plus the same-family lift path toward slot 25 and hands this paper the next typed import boundary.

This paper receives: mature LCR-native corpus and orbital evidence intake

It must produce: Electron-Hole-Exciton Accounting as publication overlay or synthesis route

Semantic transition: route external, comparative, or synthesis material around the original proof ribbon without overwriting original slot obligations

### 11.2 Peer-Review Diagnosis

`FLCR-34` is the `publication_overlay` paper at lift depth `?`. Its journal role is
to turn the current ribbon slot into a reviewable proof object, not merely to
repeat corpus language. The required proof form is:

```text
source intake, correspondence table, dependency statement, and falsifier boundary
```

For peer review, the paper should foreground accepted formalism, exact receipts,
and falsifier boundaries before adding author interpretation. The interpretation
can remain ambitious, but the addressed object must be visible and stable.

### 11.3 Formal Method To Use

Use bridge mapping, projection, calibration boundary, and sample-preservation proof. The review-facing result should be a bridge that distinguishes structural correspondence from calibrated physical identity.

Accepted formalism targets to bind:

| Formalism target | How it should enter the paper |
|---|---|
| `source routing and dependency graphs` | route into evidence, citation, receipt, or obligation lane |
| `citation-bound comparison` | route into evidence, citation, receipt, or obligation lane |
| `normal-form correspondence tables` | route into evidence, citation, receipt, or obligation lane |
| `falsifier and calibration boundaries` | route into evidence, citation, receipt, or obligation lane |

### 11.4 Claim Ledger For This Paper

| Claim | Lane | Review-facing statement |
|---|---|---|
| Theorem 34.1 | `standard_theorem_citation_bound_result` | standard electron, hole, recombination, screening, and exciton models can explain part of the open residue surface when material context is declared |
| Proposition 34.2 | `normal_form_result` | exciton accounting can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 34.3 | `falsifier_or_open_obligation` | material-specific bands, lifetimes, mobilities, and spectra require data-bound calibration |

Every row above must be paired with at least one evidence object before final
publication: a receipt, standard theorem citation, CAM/crystal reapplication,
normal-form result, calibration datum, or explicit falsifier/open-obligation
boundary.

### 11.5 Evidence Intake And Routing

| Source class | Items | Required publication treatment |
|---|---|---|
| Legacy/full sources | `NP-12_Electron_Hole_Exciton_Accounting_For_Open_Math.md`, `supplements/SM_BRIDGE_SUPPLEMENT.md` | Rewrite into the formal spine; do not paste as source clips. |
| Evidence inputs | `CAM_CLAIM_100_SCORE_AUDIT.md`, `NSIT_TOOL_CLOSURE_MATRIX.md`, `NSIT_REASONED_CLOSURE_PASS.md`, `PAPER_REWORKS_CRYSTAL_PROJECTION.json` | Bind to claim lanes and source-routing rows. |
| Receipts | pending | Attach exact path, hash, input, operation, output, and residue. |
| Validators | pending | Report pass/fail scope and domain limits. |
| CAM/crystal sources | `PAPER_REWORKS_CRYSTAL_PROJECTION.json`, `AGENT_CRYSTAL_WORK_HARVEST.json`, `D:\DockerContainers\Manny Docker Starter\mannyai\standards`, `C:\Users\nbark\Downloads\Papers-20260626T194053Z-3-001\Papers` | Use as addressable memory and reapplication routes, not as vague authority. |

Source signal to preserve during rewrite:

```text
- `NP-12_Electron_Hole_Exciton_Accounting_For_Open_Math.md`: # NP-12 â€” Electron-Hole-Exciton Accounting For Open Math **Status:** active study / reasoned closure candidate. ## Publication Draft: Formal Scientific Body ### Abstract that some open physical bridge claims may be ordinary semiconductor or The study will classify each candidate claim into one of four buckets: requires_cqecmplx_receipt overclaimed_or_rejected ### Claim-Strength Correction This paper is not only a guard against overclaiming. It is also a guard against underclaiming. If standard condensed-matter formalism already supplies the standard_model_closed_pending_citation_or_data_bind The remaining CQECMPLX claim is then narrower and stronger: CQECMPLX supplies addressability, obligation state, routing, and receipts. ### Keywords state; recombination; band gap; physical bridge; claim taxonomy. ### Core Question ### Fir...
```

### 11.6 Results Section To Build

The results section should contain a compact theorem/proposition block,
followed by the concrete table or figure that lets a reviewer inspect the
object. The minimum result package is:

1. Define the exact object being acted on at this slot.
2. State the admissible operation or transformation.
3. Show the receipt, enumeration, derivation, or external theorem supporting it.
4. State what remains residue and where that residue is routed.
5. Export the downstream import rule for later papers.

### 11.7 Figures And Tables Required

Primary figure concept: bridge diagram separating LCR-native object, adapter, external formalism, and calibration lane.

| Planned figure | Publication purpose |
|---|---|
| FLCR-34-F1: Publication overlay dependency map | Build into final journal package. |
| FLCR-34-F2: Evidence routing map | Build into final journal package. |
| FLCR-34-F3: Same-family lift context | Build into final journal package. |

| Planned table | Publication purpose |
|---|---|
| FLCR-34-T1: Dependency and translation table | Build into final journal package. |
| FLCR-34-T2: Claim-lane/evidence-boundary table | Build into final journal package. |
| FLCR-34-T3: Archive evidence card and source-backed upgrade table | Build into final journal package. |
| FLCR-34-T4: Workbook replay and falsifier table | Build into final journal package. |

### 11.8 Analog And Workbook Upgrade

The workbook must show a label-preserving transfer for `Electron-Hole-Exciton Accounting`. A low-tech
reader should be able to reconstruct the addressed state with physical tokens,
spoken order, gesture, memory, or hand enumeration. The analog exercise must
answer:

| Check | Required answer |
|---|---|
| Addressed state | What object is unchanged by the interpretation? |
| Label/access change | Which name, coordinate, analogy, or query path changed? |
| Evidence lane | Which claim lane permits the transfer? |
| Downstream import | Which later paper may consume it and with what boundary? |

### 11.9 Reviewer-Facing Limitations

- This paper proves only the object and domain stated in its claim ledger.
- Physical, Standard Model, observer, or calibration language must remain in a
  mapped lane unless this paper attaches the relevant external formalism and
  calibration data.
- CAM/crystal and forge language must be operationalized as lookup, receipt,
  address, or reapplication surfaces.
- Any unresolved item is an open channel from the declared prestate, not a
  silent license to promote the claim.

### 11.10 Concrete Editorial Tasks

- Replace any source-dump paragraphs with theorem, method, result, limitation,
  and reproducibility subsections.
- Attach exact receipt paths and hashes for all verifier-backed claims.
- Add the planned figure/table package to the final PDF build.
- Add citation placeholders for external mathematics or physics used by this
  paper.
- Update the companion and workbook so they explain the same proof object at
  human and analog-access layers.
