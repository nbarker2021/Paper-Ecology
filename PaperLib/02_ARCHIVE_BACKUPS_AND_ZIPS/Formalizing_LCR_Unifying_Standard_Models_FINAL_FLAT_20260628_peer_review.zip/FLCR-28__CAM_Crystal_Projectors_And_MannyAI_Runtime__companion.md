# FLCR-28 Companion - CAM, Crystal Projectors, And MannyAI Runtime

## What This Paper Is Doing

This paper formalizes CAM/crystal projector mechanics and MannyAI runtime intake. The operative object is crystal projector. The core result is that CAM-addressed objects can be projected through multiple representational faces while remaining addressable by the same memory contract. The paper also defines how this result routes forward: this paper becomes the runtime intake lane for Claude, Kimi, MannyAI, NotebookLM, and future crystal work. Its main residue is explicit: private or missing CAM vault data must remain marked as pending rather than assumed.

In plainer terms: this paper defines one reliable piece of the LCR stack and
states exactly how later papers are allowed to use it. It is not trying to win
every downstream claim locally. It is making the local result strong enough
that later papers can build on it without changing what was proved.

## Strongest Claim

Theorem 28.1: CAM-addressed objects can be projected through multiple representational faces while remaining addressable by the same memory contract

Lane: `cam_crystal_reapplication_result`.

## Why It Matters

- Defines crystal projector as a first-class FLCR object.
- States the local result: CAM-addressed objects can be projected through multiple representational faces while remaining addressable by the same memory contract.
- Routes downstream use through claim lanes rather than inherited prose: this paper becomes the runtime intake lane for Claude, Kimi, MannyAI, NotebookLM, and future crystal work.
- Preserves the residue boundary: private or missing CAM vault data must remain marked as pending rather than assumed.

## What It Does Not Claim Yet

- private or missing CAM vault data must remain marked as pending rather than assumed
- External calibration claims require units, datasets, citations, and reproducible data binding.
- A later translation paper may strengthen this result only by adding the missing lane evidence.

## How Later Papers Should Use It

Later papers should cite this paper by claim and lane. If a later paper needs a
stronger statement, it must add the missing receipt, standard theorem citation,
CAM/crystal reapplication, normal-form proof, calibration datum, or falsifier
boundary. It should not simply inherit stronger language from older drafts.

## Reader Check

Before accepting a downstream use of this paper, ask:

1. Which exact claim is being consumed?
2. Which lane admits that claim?
3. What receipt, theorem, CAM route, or calibration source travels with it?
4. What residue is still forbidden from promotion?

## Why This State Happens Next

This companion layer carries the semantic story: why this paper appears here,
why the preceding state needs this move, and how the next paper is allowed to
consume it. Its job is not to weaken the formal claim; its job is to make the
state transition legible.

Assigned original ribbon role(s): orbital publication overlay.

The interpretive move in this paper must be presented as label management over
an already-addressed state. Where the paper changes language, it must say what
object remains invariant and what access path, label, or analogy changed.

## Narrative State Contract

The story obligation is to show why the received state naturally demands this
paper's transition:

```text
received state -> CAM, Crystal Projectors, And MannyAI Runtime -> produced state
```

Received state: mature LCR-native corpus and orbital evidence intake.

Produced state: CAM, Crystal Projectors, And MannyAI Runtime as publication overlay or synthesis route.

The companion should make the transition intelligible without treating metaphor
as proof. It may use the author's interpretation aggressively, but it must keep
the invariant object visible.

## Past Work Story Intake

This paper's story layer should explain how the older papers, supplements, and
crystal projections make the next state feel necessary rather than arbitrary.

For this slot, the narrative emphasis is:

Use past work as orbital evidence: route all imports through dependency, citation, normal-form, calibration, and falsifier lanes.

The companion should explicitly distinguish three voices:

| Voice | What belongs here |
|---|---|
| Accepted formalism | Standard math, CS, physics, or verified code result that already exists outside the interpretation. |
| Author interpretation | The LCR/CAM/crystal relabeling that makes the state addressable in this corpus. |
| Corpus story | Why this paper has to happen at this exact ribbon position and what later papers inherit. |

## Claim Reclassification Story

The companion should explain the claim-binding queue in human terms: what the
older paper was allowed to say at its time, what later evidence now lets it say
more sharply, and what still cannot be promoted.

| Queue | Promote now | Bind next | Residue |
|---|---|---|---|
| none directly assigned | Use source routing and claim lanes to identify paper-local binding actions. | Search verifier catalog and CAM/crystal routes by object name. | Keep unbound claims in falsifier/open-obligation lanes. |

## Delta Story

The human-readable story for this paper should present the deltas as honest
growth rather than contradiction. The earlier paper was correct at its local
time slice; the later evidence returns through a named lane and sharpens the
representation.

| Delta | Local claim at paper time | Later evidence | Revised representation | Boundary kept |
|---|---|---|---|---|
| Search By Object Name | No direct reasoned-closure queue was assigned from the first queue map. | Search source routing, verifier catalog, CAM/crystal routes, and paper-local object names. | Create a specific binding queue when an object-name match finds a validator, receipt, theorem, or calibration route. | Until then, claims remain in their existing lanes. |

## Archive Evidence Story Cards

These cards explain what older mirrors, toolkit supplements, claim contracts,
or formal variants add to this paper's story.

| Source card | Score | Contribution | Integration action |
|---|---:|---|---|
| none routed | 0 | Search catalog by object name in the next pass. | No paper-local evidence card attached yet. |

## Forge-As-Expression Story

The practical reading is: CAM is the memory surface, while lattice-forge is the
action surface. This paper's interpretation should therefore explain how its
state becomes a lookup, verifier, receipt, event, or cached answer rather than
remaining only a prose claim.

## Journal Reader Guide

Read the formal paper as a journal manuscript with three layers:

1. The main argument states what this paper proves or routes.
2. The figures and tables show how the state moves through the ribbon.
3. The appendix/glossary/checklist make the claim boundaries reviewable.

For `FLCR-28`, the most important figure is `FLCR-28-F1`: Publication overlay dependency map.
The most important table is `FLCR-28-T1`: Dependency and translation table.
