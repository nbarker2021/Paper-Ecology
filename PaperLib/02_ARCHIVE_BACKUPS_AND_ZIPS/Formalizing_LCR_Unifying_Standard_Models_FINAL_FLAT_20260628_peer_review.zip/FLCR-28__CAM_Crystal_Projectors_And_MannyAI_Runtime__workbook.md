# FLCR-28 Workbook - CAM, Crystal Projectors, And MannyAI Runtime

## Purpose

This workbook turns the formal paper into a reproducible inspection exercise.
It is not a separate proof. It is the analog/digital bridge that lets a reader
reconstruct the object, claim lane, evidence route, and remaining obligation.

## Materials

- The `formal.md` file for `FLCR-28`.
- The routed legacy source files.
- `CLAIM_LANE_SCHEMA.json`.
- Any validator or receipt named in the final manifest.
- CAM/crystal sources listed in `paper.yml`.

## Exercise Sequence

| Step | Action |
|------|--------|
| Step 1 | Reconstruct the local object: crystal projector. |
| Step 2 | Write the receipt row that would demonstrate: CAM-addressed objects can be projected through multiple representational faces while remaining addressable by the same memory contract. |
| Step 3 | Route the residue without promoting it: private or missing CAM vault data must remain marked as pending rather than assumed. |

## Evidence Table To Fill During Review

| Evidence source | Expected use |
|-----------------|--------------|
| Legacy paper body | Primary formal and source-integration material assigned by the series map. |
| Internal and pyramid supplements | Cross-paper reasoning windows, deferred back-application slots, and route constraints. |
| NSIT tool closure matrix | Existing verifier/tool families that can close internal or batch claims. |
| CAM/crystal and Kimi evidence | Projected memory, source routing, standards reports, and window/node databases. |

## Receipt Stub

```yaml
paper: FLCR-28
claim: TBD
lane: TBD
input_object: TBD
operation: TBD
output_object: TBD
residue: TBD
falsifier: TBD
receipt_hash: external_or_pending
```

## Completion Criteria

- The reader can identify the main object without importing downstream claims.
- Every strong statement has a claim lane.
- Every missing datum is an obligation, not an unlabeled gap.
- Any CAM/crystal query is linked to a source path or marked as pending.

## Label-Preserving Analog Transfer

The workbook must demonstrate that the author's interpretation changes labels,
coordinates, access paths, or analog handles, not the underlying addressed
state. The analog route should therefore be auditable against the formal claim
lane and the original ribbon role.

| Original slot | Family | Lift | Role | Proof form |
|---|---|---:|---|---|
| orbital | publication overlay | n/a | no legacy original slot assigned yet | intake and routing proof |

| Transfer check | Required answer |
|---|---|
| Addressed state | What object, receipt, theorem, or construction is unchanged? |
| Label/access change | Which name, analogy, coordinate, or query path changed? |
| Evidence lane | Which claim lane permits the transfer? |
| Downstream import | Which later paper may consume this result, and with what boundary? |

## State-Preserving Analog Contract

Analog invariance test: an orbital index: it may point to many source states, but it must not relabel them as a single proved theorem without a lane.

The workbook exercise is to fill this table with concrete receipts, equations,
citations, code paths, or CAM/crystal queries:

| Check | Required content |
|---|---|
| Received state | Exact source object entering the paper |
| Formal carrier | Accepted theorem, construction, verifier, or receipt being used |
| Interpretation label | The author's label, analogy, or access-path change |
| Invariant state | What remains unchanged under that relabeling |
| Produced state | What downstream paper is allowed to import |

| Slot | Contract |
|---|---|
| orbital | publication overlay; must declare sources, dependencies, and calibration/falsifier boundaries |

## Crystal/CAM Replay Checklist

Use this checklist to turn past work into auditable workbook material.

| Replay item | Required workbook action |
|---|---|
| Routed full sources | Reconstruct the local object and cite the exact source rows used. |
| CAM/crystal report | Query or cite the face/vignette/CAM node route relevant to this paper. |
| Kimi standards/window data | Mark conformance/window evidence separately from claim validity. |
| NSIT closure matrix | Attach validator rows where they close the paper's internal claim. |
| Claude score audit | Use the score as admission posture, not as a replacement for receipts. |
| Analog interpretation | Show the invariant state before and after relabeling. |

### Sources To Replay First

| Source | Placement reason |
|---|---|
| `supplements/CRYSTAL_CAM_PROJECTOR_SUPPLEMENT.md` | primary assigned source for the paper's formal spine |
| `AGENT_CRYSTAL_WORK_HARVEST.md` | primary assigned source for the paper's formal spine |
| `PAPER_REWORKS_CRYSTAL_REPORT.md` | primary assigned source for the paper's formal spine |
| `supplements/CRYSTAL_CAM_PROJECTOR_SUPPLEMENT.md` | cross-cutting supplement; import only paper-relevant rows, receipts, or guard language |
| `supplements/METAFORGE_MATERIALS_SUPPLEMENT.md` | cross-cutting supplement; import only paper-relevant rows, receipts, or guard language |
| `supplements/SPECTRE_TILING_SUPPLEMENT.md` | cross-cutting supplement; import only paper-relevant rows, receipts, or guard language |
| `supplements/RECEIPT_VERIFIER_CATALOG.md` | cross-cutting supplement; import only paper-relevant rows, receipts, or guard language |
| `supplements/APPLIED_FORGES_WORKBOOK.md` | cross-cutting supplement; import only paper-relevant rows, receipts, or guard language |
| `supplements/INTERNAL_REASONING_PYRAMID_INDEX.md` | cross-cutting supplement; import only paper-relevant rows, receipts, or guard language |
| `supplements/INTERNAL_REASONING_5P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; import only paper-relevant rows, receipts, or guard language |
| `supplements/INTERNAL_REASONING_7P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; import only paper-relevant rows, receipts, or guard language |
| `supplements/INTERNAL_REASONING_9P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; import only paper-relevant rows, receipts, or guard language |
| `CAM_CLAIM_100_SCORE_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_TOOL_CLOSURE_MATRIX.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_REASONED_CLOSURE_PASS.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `ORBITAL_DATA_CROSS_POPULATION_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| additional routed sources | 17 more entries remain in `SOURCE_PLACEMENT.md` |

## Claim Binding Workbook

For each queue item, fill the replay row before strengthening the paper.

| Queue item | Local claim | Later evidence | Revised claim | Boundary kept |
|---|---|---|---|---|
| TBD | TBD | TBD | TBD | TBD |

| Queue | Promote now | Bind next | Residue |
|---|---|---|---|
| none directly assigned | Use source routing and claim lanes to identify paper-local binding actions. | Search verifier catalog and CAM/crystal routes by object name. | Keep unbound claims in falsifier/open-obligation lanes. |

## Delta Replay Table

The workbook should make each delta reproducible.

| Delta | Replay action | Boundary check |
|---|---|---|
| Search By Object Name | Search by object name and add the first concrete receipt/citation/calibration candidate. | Until then, claims remain in their existing lanes. |

## Archive Evidence Replay Cards

Use these cards as workbook replay targets.

| Upgrade target | Evidence card | How it improves the paper | Boundary |
|---|---|---|---|
| object-name search | none yet | Search verifier catalog, CAM routes, and source placement for a concrete card. | No promotion without evidence. |

| Replay field | Required value |
|---|---|
| Source card | Which archive/mirror card is being used? |
| Exact source path | Where is the original source? |
| Receipt or verifier | What executable or receipt object does it name? |
| Claim effect | What claim becomes stronger, narrower, or better bounded? |
| Boundary retained | What the card still refuses to promote. |

## Forge Actionization Workbook

Fill one row for every claim this paper wants to actionize.

| CAM item | Forge/API action | Typed result | Receipt/cache row | Boundary |
|---|---|---|---|---|
| TBD | TBD | TBD | TBD | TBD |

Leech lookup APIs to test or cite:

- `Forge.leech_lookup(address=0, payload=None)`
- `Forge.verify_leech_lookup()`
- `lattice_forge.lattice_codes.verify_lattice_code_chain`
- `lattice_forge.lattice_codes.verify_golay_24`
- `lattice_forge.enumerated_glue.derive_classical_leech_minimal_landing`
- `lattice_forge.enumerated_glue.encode_leech_ribbon`

## Journal Submission Workbook

Before this paper is submitted, complete these rows.

| Artifact | Status | Required completion |
|---|---|---|
| Figures `FLCR-28-F1`, `FLCR-28-F2`, `FLCR-28-F3` | planned | Convert text schematics into final diagrams or leave as formal schematic figures. |
| Tables `FLCR-28-T1`-`FLCR-28-T4` | planned | Ensure all claim/evidence/source-card/workbook rows are complete. |
| Glossary | drafted | Replace generic term meanings with paper-local definitions. |
| Appendix FLCR-28-A | drafted | Attach receipt paths, verifier paths, source cards, and remaining external requirements. |
| Reviewer checklist | drafted | Mark pass/fail before final PDF build. |
