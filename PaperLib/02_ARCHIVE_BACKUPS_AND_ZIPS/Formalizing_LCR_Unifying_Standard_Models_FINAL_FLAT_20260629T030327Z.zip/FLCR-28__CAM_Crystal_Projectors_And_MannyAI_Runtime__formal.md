# FLCR-28 - CAM, Crystal Projectors, And Runtime

**Series:** Formalizing LCR, Unifying Standard Models  
**Artifact:** formal paper source  
**Status:** first-pass rich rewrite; requires final citation and build pass.  
**Claim posture:** maximal local claim posture with explicit lane boundaries.

## Abstract

This paper formalizes CAM/crystal projector mechanics and runtime intake. The operative object is crystal projector. The core result is that CAM-addressed objects can be projected through multiple representational faces while remaining addressable by the same memory contract. The paper also defines how this result routes forward: this paper becomes the runtime intake lane for agent-generated, standards-window, runtime, notebook-derived, and future crystal work. Its main residue is explicit: private or missing CAM vault data must remain marked as pending rather than assumed.

## Keywords

crystal projector; LCR; receipt; claim lane; normal form.

## 1. Contribution And Scope

- Defines crystal projector as a first-class FLCR object.
- States the local result: CAM-addressed objects can be projected through multiple representational faces while remaining addressable by the same memory contract.
- Routes downstream use through claim lanes rather than inherited prose: this paper becomes the runtime intake lane for agent-generated, standards-window, runtime, notebook-derived, and future crystal work.
- Preserves the residue boundary: private or missing CAM vault data must remain marked as pending rather than assumed.

This paper is part of the LCR-native base layer. Standard Model or physical
language is permitted only as deferred mapping, analogy, or explicitly bounded
future calibration. The editable surface is the claim lane and source-routing
layer; the base objects must remain stable enough for downstream papers to
consume them without ambiguity.

## 2. Source Routing

Primary routed sources:

- `supplements/CRYSTAL_CAM_PROJECTOR_SUPPLEMENT.md`
- `AGENT_CRYSTAL_WORK_HARVEST.md`
- `PAPER_REWORKS_CRYSTAL_REPORT.md`

Cross-corpus evidence classes:

- `CAM_CLAIM_100_SCORE_AUDIT.md`
- `NSIT_TOOL_CLOSURE_MATRIX.md`
- `NSIT_REASONED_CLOSURE_PASS.md`
- `PAPER_REWORKS_CRYSTAL_PROJECTION.json`
- standards, glue, window, and node databases where applicable
- notebook-derived review prompts and orbital source manifests

## 3. Definitions

- **Crystal projector.** A runtime that loads, projects, and reads addressable crystal/CAM objects through multiple faces.
- **2x2 handshake.** The minimal adapter insertion that preserves address, form, claim lane, and receipt.
- **Receipt boundary.** The exact scope in which the paper's result can be replayed or consumed.
- **Promotion route.** The evidence path required before a stronger downstream claim can use this result.

## 4. Formal Claims

| Claim | Lane | Statement |
|-------|------|-----------|
| Theorem 28.1 | `cam_crystal_reapplication_result` | CAM-addressed objects can be projected through multiple representational faces while remaining addressable by the same memory contract |
| Proposition 28.2 | `normal_form_result` | crystal projector can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 28.3 | `falsifier_or_open_obligation` | private or missing CAM vault data must remain marked as pending rather than assumed |

## 5. Paper-Specific Development

1. Identify the local object and its assigned sources for FLCR-28.
2. Separate what is internally receipt-bound from what is citation-bound, CAM-bound, calibration-bound, or still an obligation.
3. State the strongest admissible claim in its current lane.
4. Export only the lane-safe result to downstream papers and preserve the residue.

### Proof Sketch

The proof strategy for FLCR-28 is a typed construction argument. The paper names crystal projector as the active object, binds it to the routed legacy and orbital sources, and then allows downstream use only through the declared claim lane. This does not erase stronger ambitions; it keeps them addressable as dependencies, calibration tasks, or falsifiers.

## 6. Construction

The construction is intentionally staged. First, the paper names the finite or
typed object that can be inspected directly. Second, it declares the admissible
operations over that object. Third, it records the receipt or source class that
allows another paper to consume the result. Fourth, it names the residue that
must not be silently promoted.

For this paper, the operative object is `CAM, Crystal Projectors, And Runtime`. Its safe consumption
rule is:

```text
source object -> declared operation -> receipt/lane -> downstream import
```

The unsafe consumption rule is:

```text
source phrase -> downstream identity claim
```

That second pattern is explicitly rejected by FLCR-01 and must be rewritten as
a claim-lane promotion with evidence.

## 7. Evidence And Receipts

| Evidence source | What it contributes |
|-----------------|---------------------|
| Legacy paper body | Primary formal and source-integration material assigned by the series map. |
| Internal and pyramid supplements | Cross-paper reasoning windows, deferred back-application slots, and route constraints. |
| NSIT tool closure matrix | Existing verifier/tool families that can close internal or batch claims. |
| CAM/crystal and standards-window evidence | Projected memory, source routing, standards reports, and window/node databases. |

### Standards And Runtime Intake Binding

The runtime instruction suite supplies a runtime doctrine that this paper must
own rather than leave as a loose external note. The operative rule is CAM-first:
substrate reasoning routes through the CQE CAM crystal before runtime-local CAM
state, and runtime-local state is then used for agents, crystals, products,
coins, and runtime traces. The paper therefore treats the current runtime MCP
surface as an intake adapter in progress: it can expose CAM and Carrier-CEM
tools, but full publication closure requires first-routing enforcement in the
server path.

The relevant evidence rows are:

| Artifact | FLCR-28 use |
|---|---|
| `local evidence artifact` | Defines CAM-first routing and the wall/gating discipline this paper imports. |
| `local evidence artifact` | Makes runtime errors correction lanes rather than terminal failures. |
| `local evidence artifact` | Allows adapter construction by function and receipt rather than by stale names. |
| `local evidence artifact` | Current MCP surface; evidence for adapter existence and for the remaining first-routing obligation. |
| `suite_resolution_report.json` unresolved row `CQE-paper-formal-S29` | Routes "The 8 Estimators" into this paper as a CAM/crystal estimator manifest obligation. |

Thus Theorem 28.1 is strengthened: a crystal projector is not merely a visual or
textual metaphor, but an address-preserving adapter layer whose valid outputs
must carry source, face, lane, and receipt fields. It is not yet allowed to
claim that every runtime tool already enforces first-routing; that remains a
runtime obligation and falsifier until the MCP dispatch path calls the CQE CAM
before tool execution.

## 8. Dependencies And Downstream Use

This paper may be imported by later FLCR papers only through the claim lanes
above. The default downstream consumers are:

- `FLCR-11` through `FLCR-18` for window, receipt, admission, CA, algebraic,
  curvature, residue, and exceptional machinery.
- `FLCR-28` through `FLCR-30` for CAM/crystal, corpus ribbon, and universal
  normal-form intake.
- `FLCR-31` through `FLCR-40` only after the LCR-native result has been cited
  and the translation claim has its own evidence lane.

## 9. Limitations And Falsifiers

- private or missing CAM vault data must remain marked as pending rather than assumed
- External calibration claims require units, datasets, citations, and reproducible data binding.
- A later translation paper may strengthen this result only by adding the missing lane evidence.

A falsifier for this paper is any example that satisfies the declared input
conditions while violating the stated construction, receipt, or lane boundary.
An interpretation that merely wants a stronger downstream conclusion is not a
falsifier; it is an obligation routed to a later paper.

## 10. Publication Readiness Tasks

- Validator identities and receipt hashes are recorded in the manifest or receipt appendix.
- External theorems require final citation entries before journal submission.
- Every theorem, proposition, and protocol must retain a claim lane and evidence boundary.
- The Markdown, LaTeX, and PDF forms are generated from the same canonical source.

## Dual Positioning: Story And Formal Carrier

This paper must be read in two synchronized ways. Sequentially, it explains why
the next state exists in the corpus story. Formally, it binds that state to
accepted mathematics, IRL formalism, code receipts, validators, CAM/crystal
lookups, and claim-lane boundaries.

Assigned original ribbon role(s): orbital publication overlay.

| Original slot | Family | Lift | Role | Proof form |
|---|---|---:|---|---|
| orbital | publication overlay | n/a | no legacy original slot assigned yet | intake and routing proof |

The formal obligation is to state the strongest valid claim available for this
paper without letting interpretation silently change the addressed object. Any
author interpretation belongs beside the formalism as a declared relabeling,
bridge, or analog, and must be accompanied by the evidence lane that makes the
claim consumable by later papers.

## State-Bound Proof Contract

This paper receives: mature LCR-native corpus and orbital evidence intake.

It must produce: CAM, Crystal Projectors, And Runtime as publication overlay or synthesis route.

Semantic transition: route external, comparative, or synthesis material around the original proof ribbon without overwriting original slot obligations.

Accepted formalism targets to bind in the journal rewrite:

- source routing and dependency graphs
- citation-bound comparison
- normal-form correspondence tables
- falsifier and calibration boundaries

| Slot | Contract |
|---|---|
| orbital | publication overlay; must declare sources, dependencies, and calibration/falsifier boundaries |

The formal carrier uses these accepted tools while preserving interpretive
claims as explicit relabelings, correspondences, or bridges. Claim promotion is admissible only when a receipt, standard citation,
CAM/crystal reapplication, normal-form result, calibration datum, or falsifier
boundary is attached.

## Provenance And Crystal Evidence Integration

This section integrates prior work, CAM/crystal projections, NSIT tooling,
standards-window evidence, and routed supplements as provenance-bearing
evidence. Source material is not treated as manuscript text; it is bound into
the paper only through claim lanes, receipts, validators, normal forms,
calibration rows, or explicit falsifier boundaries.

### Expansion Rule For This Slot

Use past work as orbital evidence: route all imports through dependency, citation, normal-form, calibration, and falsifier lanes.

### Primary Evidence Inputs

| Source | Placement reason |
|---|---|
| `supplements/CRYSTAL_CAM_PROJECTOR_SUPPLEMENT.md` | primary assigned source for the paper's formal spine |
| `AGENT_CRYSTAL_WORK_HARVEST.md` | primary assigned source for the paper's formal spine |
| `PAPER_REWORKS_CRYSTAL_REPORT.md` | primary assigned source for the paper's formal spine |

### Secondary And Orbital Evidence Inputs

| Source | Placement reason |
|---|---|
| `supplements/CRYSTAL_CAM_PROJECTOR_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/METAFORGE_MATERIALS_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/SPECTRE_TILING_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/RECEIPT_VERIFIER_CATALOG.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/APPLIED_FORGES_WORKBOOK.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_PYRAMID_INDEX.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_5P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_7P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_9P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `CAM_CLAIM_100_SCORE_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_TOOL_CLOSURE_MATRIX.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_REASONED_CLOSURE_PASS.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| Additional source routes | Complete routing is maintained in the source-placement appendix |

### Crystal And Standards Evidence To Bind

- Paper Reworks crystal projection: 33 paper markdown files, 9 supplements, 5 queues, 6 lattice-forge unification artifacts, 140 faces, 140 vignettes, and 280 CAM nodes.
- Standards-window intake: 192/192 corpus conformance verdicts PASS; 140/142 obligations have candidate routes; 2/4/8/16/32 window lattice is available for cross-paper reads.
- Agent/crystal harvest: agent-generated memory, runtime standards starter, current runtime build, repo-harvest CAM, notebook-derived bundles, and downloaded crystal payloads are orbital evidence surfaces.
- NSIT inventory baseline: 220 validators, 1786 receipt/data artifacts, 1137 formal-paper-like artifacts, 114 supplements, and 86 memory/CAM artifacts.

### Paper-Specific CAM/Score Rows

No direct `00-32` CAM score row is assigned; use this paper as an orbital or translation intake.

### Paper-Specific NSIT Closure Rows

No direct NSIT row matched the assigned legacy papers in the first-pass matrix; validator matching by object name remains a receipt-attachment requirement.

### Source Integration Summary

The legacy source and internal reasoning supplement are treated as source
evidence rather than manuscript prose. Their contributions enter this paper as
claim-lane entries, receipt or validator references, finite-domain statements,
and limitation boundaries. Speculative or cross-domain interpretations remain
separate from closed local results until an explicit adapter, citation,
normal-form derivation, calibration row, or falsifier is attached.
## Claim Binding Queue

This queue records the evidence discipline for claim strengthening. It separates claims that already have support from residues that remain in falsifier or open-obligation lanes.

| Queue | Promote now | Bind next | Residue |
|---|---|---|---|
| none directly assigned | Source routing and claim lanes identify paper-local binding actions. | Verifier catalogs and CAM/crystal routes provide object-name evidence candidates. | Unbound claims remain in falsifier/open-obligation lanes. |

### Binding Discipline

Each queue item is represented as a delta:

```text
local claim at paper time
-> attached later source/tool/receipt/theorem
-> revised representation
-> invariant boundary and remaining residue
```

This preserves the sequential story while allowing later tools, crystals, and
standard formalisms to return through the proper lane.

## Claim Delta Ledger

This ledger applies the paper's claim-binding queues as explicit back-application
deltas. It keeps the sequential paper story intact while allowing later
receipts, standard formalisms, CAM/crystal routes, and validators to sharpen the
claim.

| Delta | Local claim at paper time | Later evidence | Revised representation | Boundary kept |
|---|---|---|---|---|
| Search By Object Name | No direct reasoned-closure queue was assigned from the first queue map. | Search source routing, verifier catalog, CAM/crystal routes, and paper-local object names. | Create a specific binding queue when an object-name match finds a validator, receipt, theorem, or calibration route. | Until then, claims remain in their existing lanes. |

The revised representation records the strongest claim supported by the current evidence package. Promotion into theorem or proposition language occurs only when the named evidence is attached in the manifest or workbook replay.

## Source-Backed Evidence Summary

Routed archive and mirror cards are treated as provenance summaries rather than
body text. They identify candidate receipts, validators, theorem registries, or
supplemental source routes. A card strengthens this paper only when its
contribution is bound to a claim lane, evidence object, and boundary.

| Evidence card | Score | Publication contribution | Boundary |
|---|---:|---|---|
| No routed archive card attached yet | 0 | source-backed contribution | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| Additional evidence cards | 0 total | The complete card inventory is maintained in the archive evidence matrix. | Cards are source-discovery aids until bound to paper-local evidence. |

## Journal Apparatus

### Article Type And Intended Venue Fit

This manuscript is written as a formal-methods and mathematical-systems paper
inside the series *Formalizing LCR, Unifying Standard Models*. Its intended
reader is a technical reviewer who needs claim boundaries, reproducibility
routes, and cross-paper dependencies to be visible without relying on private
context.

### Structured Contribution Statement

| Item | Statement |
|---|---|
| Publication ID | `FLCR-28` |
| Legacy source slot(s) | `orbital` |
| Ribbon role | routes external, standard-model, or synthesis material around the original proof ribbon |
| Proof form | source intake, correspondence table, dependency statement, and falsifier boundary |
| Received state | mature LCR-native corpus and orbital evidence intake |
| Produced state | CAM, Crystal Projectors, And Runtime as publication overlay or synthesis route |

### Claim-Evidence Table

| Claim | Lane | Evidence to attach | Boundary |
|---|---|---|---|
| Theorem 28.1 | `cam_crystal_reapplication_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | CAM-addressed objects can be projected through multiple representational faces while remaining addressable by the same memory contract |
| Proposition 28.2 | `normal_form_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | crystal projector can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 28.3 | `falsifier_or_open_obligation` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | private or missing CAM vault data must remain marked as pending rather than assumed |

### Figure Plan

| Figure | Purpose | Caption |
|---|---|---|
| FLCR-28-F1 | Publication overlay dependency map | Schematic showing how `FLCR-28` turns its received state into the produced state while preserving claim lanes and residue boundaries. |
| FLCR-28-F2 | Evidence routing map | Diagram of source papers, archive cards, CAM/crystal routes, validators, and workbook replay paths used by this manuscript. |
| FLCR-28-F3 | Same-family lift context | Diagram placing this paper in the original `00-79` ribbon family and showing predecessor/successor slots. |

### In-Text Figure FLCR-28-F1: Publication overlay dependency map

```text
received state
  -> Publication overlay dependency map
  -> formal claim lane
  -> evidence object / receipt / citation
  -> produced state
  -> remaining residue
```

### Table Plan

| Table | Purpose |
|---|---|
| FLCR-28-T1 | Dependency and translation table |
| FLCR-28-T2 | Claim-lane/evidence-boundary table |
| FLCR-28-T3 | Archive evidence card and source-backed upgrade table |
| FLCR-28-T4 | Workbook replay and falsifier table |

### Worked Example

Route one standard-model or synthesis claim back to its LCR-native source papers. The example must name the input object, the operation,
the evidence object, the allowed revised claim, and the remaining boundary.

### Nomenclature And Glossary

| Term | Paper-local meaning |
|---|---|
| CAM | Defined by this paper as part of the `publication_overlay` proof role; final definition is recorded in the paper-local glossary. |
| claim lane | Defined by this paper as part of the `publication_overlay` proof role; final definition is recorded in the paper-local glossary. |
| crystal | Defined by this paper as part of the `publication_overlay` proof role; final definition is recorded in the paper-local glossary. |
| dependency | Defined by this paper as part of the `publication_overlay` proof role; final definition is recorded in the paper-local glossary. |
| publication overlay | Defined by this paper as part of the `publication_overlay` proof role; final definition is recorded in the paper-local glossary. |
| receipt | Defined by this paper as part of the `publication_overlay` proof role; final definition is recorded in the paper-local glossary. |
| synthesis lane | Defined by this paper as part of the `publication_overlay` proof role; final definition is recorded in the paper-local glossary. |
| translation claim | Defined by this paper as part of the `publication_overlay` proof role; final definition is recorded in the paper-local glossary. |

### Appendix FLCR-28-A: Evidence Package

The appendix records:

1. Legacy source excerpts or source-card references used in the final claim ledger.
2. Receipt and verifier paths, including pass/fail/partial status.
3. CAM/crystal query or projection rows used by the paper, with source identity and boundary.
4. Standards-window and NSIT evidence used for conformance or routing.
5. Falsifier, calibration, or external-data rows that remain unresolved.

### Data And Code Availability

The publication package contains the canonical Markdown sources, manifests, source-routing matrices, validation reports, and generated PDF/TeX outputs.

Code and verifier references are cited through manifests, archive evidence cards, receipt catalogs, or workbook replay tables. External datasets or
standards citations must be attached before any calibration-bound claim is
promoted.

### Reviewer Checklist

| Check | Reviewer question |
|---|---|
| Claim lane | Does every strong claim declare its lane and evidence type? |
| Boundary | Does the paper preserve what it does not prove? |
| Reproducibility | Is there a receipt, verifier, source card, citation, or replay table for the claim? |
| Cross-paper import | Does the paper cite the prior FLCR/OPR slot before consuming its result? |
| Interpretation | Does the analog layer preserve the addressed state while changing labels/access paths? |

### Declarations

No human-subjects, clinical, or animal-research protocol is asserted by this
paper. External empirical claims require separate dataset, calibration, or
domain-validation attachments. Competing-interest and funding statements are recorded in the submission metadata.

## 11. Publication Integration Addendum

### 11.1 Role In The Series

`FLCR-28` (`CAM, Crystal Projectors, And Runtime`) occupies the `publication_overlay` role at lift depth `n/a`.
The paper receives mature LCR-native corpus and orbital evidence intake. It produces CAM, Crystal Projectors, And Runtime as publication overlay or synthesis route. The state transition is:
route external, comparative, or synthesis material around the original proof ribbon without overwriting original slot obligations.

The paper-local proof form is:

```text
source intake, correspondence table, dependency statement, and falsifier boundary
```

The integration result is a source-intake and synthesis surface with dependency, citation, calibration, and falsifier boundaries. This addendum records how that result is
consumed by the publication series without relying on editorial instructions or
private working context.

### 11.2 Formal Carrier

| Formal carrier | Function |
|---|---|
| source routing and dependency graphs | Formal carrier for the paper-local result. |
| citation-bound comparison | Formal carrier for the paper-local result. |
| normal-form correspondence tables | Formal carrier for the paper-local result. |
| falsifier and calibration boundaries | Formal carrier for the paper-local result. |

The LCR, CAM, crystal, forge, and analog vocabulary functions as a typed access
layer over these carriers. A relabeling is admissible only when the addressed
object, evidence lane, boundary, and downstream import rule remain attached.

### 11.3 Claim Ledger

| Claim | Lane | Statement |
|---|---|---|
| Theorem 28.1 | `cam_crystal_reapplication_result` | CAM-addressed objects can be projected through multiple representational faces while remaining addressable by the same memory contract |
| Proposition 28.2 | `normal_form_result` | crystal projector can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 28.3 | `falsifier_or_open_obligation` | private or missing CAM vault data must remain marked as pending rather than assumed |

These claims are consumed at their stated lane. A stronger downstream statement
creates a new claim envelope with its own evidence object.

### 11.4 Evidence Package

| Evidence class | Routed items | Status |
|---|---|---|
| Legacy sources | `supplements/CRYSTAL_CAM_PROJECTOR_SUPPLEMENT.md`, `AGENT_CRYSTAL_WORK_HARVEST.md`, `PAPER_REWORKS_CRYSTAL_REPORT.md` | routed evidence |
| Evidence inputs | `CAM_CLAIM_100_SCORE_AUDIT.md`, `NSIT_TOOL_CLOSURE_MATRIX.md`, `NSIT_REASONED_CLOSURE_PASS.md`, `PAPER_REWORKS_CRYSTAL_PROJECTION.json` | routed evidence |
| CAM/crystal sources | `PAPER_REWORKS_CRYSTAL_PROJECTION.json`, `AGENT_CRYSTAL_WORK_HARVEST.json`, `runtime standards artifact`, `notebook-derived source bundle` | routed evidence |
| Standards-window inputs | `window_summary.json`, `node DBs`, `window DBs` | routed evidence |
| Receipts | external requirement | not attached in this source package |
| Validators | external requirement | not attached in this source package |

Standards-window, runtime, and notebook-derived artifacts are treated
as evidence-routing surfaces. They support source discovery, conformance
checking, and reapplication, but they do not replace citations, receipts,
normal-form derivations, calibration rows, or falsifiers.

### 11.5 Results Representation

The paper's results section is organized around five publication objects:

1. the exact object acted on at this slot;
2. the admissible operation or transformation;
3. the receipt, enumeration, derivation, lookup, or external theorem supporting
   the operation;
4. the residue or boundary left after the result;
5. the downstream import rule.

### 11.6 Figures And Tables

| Figure | Role |
|---|---|
| FLCR-28-F1: Publication overlay dependency map | Visualizes the proof object, routing, or boundary. |
| FLCR-28-F2: Evidence routing map | Visualizes the proof object, routing, or boundary. |
| FLCR-28-F3: Same-family lift context | Visualizes the proof object, routing, or boundary. |

| Table | Role |
|---|---|
| FLCR-28-T1: Dependency and translation table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-28-T2: Claim-lane/evidence-boundary table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-28-T3: Archive evidence card and source-backed upgrade table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-28-T4: Workbook replay and falsifier table | Records claim lanes, evidence, sources, or falsifiers. |

### 11.7 Limits And Falsifiers

The paper proves only the object and domain declared in its claim ledger.
Physical, Standard Model, observer, calibration, or synthesis claims require
the additional lane evidence stated by their destination papers. CAM/crystal
and forge language is operational only when represented as an address, lookup,
receipt, validator, or reapplication path.
