# Glossary Index

| Term | Appears in papers |
|---|---|
| CAM | `FLCR-01`, `FLCR-02`, `FLCR-03`, `FLCR-04`, `FLCR-05`, `FLCR-06`, `FLCR-07`, `FLCR-08`, `FLCR-09`, `FLCR-10`, `FLCR-11`, `FLCR-12`, `FLCR-13`, `FLCR-14`, `FLCR-15`, `FLCR-16`, `FLCR-17`, `FLCR-18`, `FLCR-19`, `FLCR-20`, `FLCR-21`, `FLCR-22`, `FLCR-23`, `FLCR-24`, `FLCR-25`, `FLCR-26`, `FLCR-27`, `FLCR-28`, `FLCR-29`, `FLCR-30`, `FLCR-31`, `FLCR-32`, `FLCR-33`, `FLCR-34`, `FLCR-35`, `FLCR-36`, `FLCR-37`, `FLCR-38`, `FLCR-39`, `FLCR-40` |
| addressable slot | `FLCR-02`, `FLCR-12`, `FLCR-20` |
| admission | `FLCR-05`, `FLCR-15`, `FLCR-23`, `FLCR-35` |
| atlas | `FLCR-04`, `FLCR-14`, `FLCR-22`, `FLCR-31`, `FLCR-32` |
| boundary | `FLCR-05`, `FLCR-15`, `FLCR-23`, `FLCR-35` |
| bounded domain | `FLCR-03`, `FLCR-13`, `FLCR-21`, `FLCR-30`, `FLCR-36` |
| bridge | `FLCR-08`, `FLCR-18`, `FLCR-26` |
| calibration | `FLCR-08`, `FLCR-18`, `FLCR-26` |
| carrier | `FLCR-06`, `FLCR-16`, `FLCR-24`, `FLCR-33`, `FLCR-37` |
| causal edge | `FLCR-07`, `FLCR-17`, `FLCR-25`, `FLCR-39` |
| center state | `FLCR-02`, `FLCR-12`, `FLCR-20` |
| claim lane | `FLCR-01`, `FLCR-02`, `FLCR-03`, `FLCR-04`, `FLCR-05`, `FLCR-06`, `FLCR-07`, `FLCR-08`, `FLCR-09`, `FLCR-10`, `FLCR-11`, `FLCR-12`, `FLCR-13`, `FLCR-14`, `FLCR-15`, `FLCR-16`, `FLCR-17`, `FLCR-18`, `FLCR-19`, `FLCR-20`, `FLCR-21`, `FLCR-22`, `FLCR-23`, `FLCR-24`, `FLCR-25`, `FLCR-26`, `FLCR-27`, `FLCR-28`, `FLCR-29`, `FLCR-30`, `FLCR-31`, `FLCR-32`, `FLCR-33`, `FLCR-34`, `FLCR-35`, `FLCR-36`, `FLCR-37`, `FLCR-38`, `FLCR-39`, `FLCR-40` |
| correction surface | `FLCR-03`, `FLCR-13`, `FLCR-21`, `FLCR-30`, `FLCR-36` |
| correspondence | `FLCR-08`, `FLCR-18`, `FLCR-26` |
| crystal | `FLCR-01`, `FLCR-02`, `FLCR-03`, `FLCR-04`, `FLCR-05`, `FLCR-06`, `FLCR-07`, `FLCR-08`, `FLCR-09`, `FLCR-10`, `FLCR-11`, `FLCR-12`, `FLCR-13`, `FLCR-14`, `FLCR-15`, `FLCR-16`, `FLCR-17`, `FLCR-18`, `FLCR-19`, `FLCR-20`, `FLCR-21`, `FLCR-22`, `FLCR-23`, `FLCR-24`, `FLCR-25`, `FLCR-26`, `FLCR-27`, `FLCR-28`, `FLCR-29`, `FLCR-30`, `FLCR-31`, `FLCR-32`, `FLCR-33`, `FLCR-34`, `FLCR-35`, `FLCR-36`, `FLCR-37`, `FLCR-38`, `FLCR-39`, `FLCR-40` |
| dependency | `FLCR-28`, `FLCR-34`, `FLCR-40` |
| dependency graph | `FLCR-01`, `FLCR-11`, `FLCR-19`, `FLCR-29` |
| enumeration | `FLCR-02`, `FLCR-12`, `FLCR-20` |
| face | `FLCR-04`, `FLCR-14`, `FLCR-22`, `FLCR-31`, `FLCR-32` |
| falsifier | `FLCR-05`, `FLCR-15`, `FLCR-23`, `FLCR-35` |
| finite domain | `FLCR-02`, `FLCR-12`, `FLCR-20` |
| fold | `FLCR-04`, `FLCR-14`, `FLCR-22`, `FLCR-31`, `FLCR-32` |
| invariant payload | `FLCR-06`, `FLCR-16`, `FLCR-24`, `FLCR-33`, `FLCR-37` |
| lattice surface | `FLCR-09` |
| ledger | `FLCR-07`, `FLCR-17`, `FLCR-25`, `FLCR-39` |
| lift boundary | `FLCR-01`, `FLCR-11`, `FLCR-19`, `FLCR-29` |
| lookup | `FLCR-09` |
| multi-scale | `FLCR-10`, `FLCR-27`, `FLCR-38` |
| negative receipt | `FLCR-07`, `FLCR-17`, `FLCR-25`, `FLCR-39` |
| obligation | `FLCR-07`, `FLCR-17`, `FLCR-25`, `FLCR-39` |
| open-slot preservation | `FLCR-01`, `FLCR-11`, `FLCR-19`, `FLCR-29` |
| path composition | `FLCR-06`, `FLCR-16`, `FLCR-24`, `FLCR-33`, `FLCR-37` |
| projection | `FLCR-08`, `FLCR-18`, `FLCR-26` |
| publication overlay | `FLCR-28`, `FLCR-34`, `FLCR-40` |
| query cache | `FLCR-09` |
| readout | `FLCR-10`, `FLCR-27`, `FLCR-38` |
| receipt | `FLCR-01`, `FLCR-02`, `FLCR-03`, `FLCR-04`, `FLCR-05`, `FLCR-06`, `FLCR-07`, `FLCR-08`, `FLCR-09`, `FLCR-10`, `FLCR-11`, `FLCR-12`, `FLCR-13`, `FLCR-14`, `FLCR-15`, `FLCR-16`, `FLCR-17`, `FLCR-18`, `FLCR-19`, `FLCR-20`, `FLCR-21`, `FLCR-22`, `FLCR-23`, `FLCR-24`, `FLCR-25`, `FLCR-26`, `FLCR-27`, `FLCR-28`, `FLCR-29`, `FLCR-30`, `FLCR-31`, `FLCR-32`, `FLCR-33`, `FLCR-34`, `FLCR-35`, `FLCR-36`, `FLCR-37`, `FLCR-38`, `FLCR-39`, `FLCR-40` |
| repair row | `FLCR-05`, `FLCR-15`, `FLCR-23`, `FLCR-35` |
| representation transport | `FLCR-04`, `FLCR-14`, `FLCR-22`, `FLCR-31`, `FLCR-32` |
| residue | `FLCR-03`, `FLCR-13`, `FLCR-21`, `FLCR-30`, `FLCR-36` |
| same-family lift | `FLCR-10`, `FLCR-27`, `FLCR-38` |
| synthesis lane | `FLCR-28`, `FLCR-34`, `FLCR-40` |
| terminal address | `FLCR-09` |
| translation claim | `FLCR-28`, `FLCR-34`, `FLCR-40` |
| transport | `FLCR-06`, `FLCR-16`, `FLCR-24`, `FLCR-33`, `FLCR-37` |
| unbounded burden | `FLCR-03`, `FLCR-13`, `FLCR-21`, `FLCR-30`, `FLCR-36` |
| window | `FLCR-10`, `FLCR-27`, `FLCR-38` |
