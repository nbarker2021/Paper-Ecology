# FLCR-28 Workbook - CAM, Crystal Projectors, And Runtime

## Purpose

This workbook turns the CAM/crystal projector paper into a replayable runtime
exercise. A reader should be able to take a source object in any form, assign a
CAM address, project it through faces, collect vignettes, and route the result
to the next paper or algorithm without losing the source boundary.

## Materials

- `FLCR-28/formal.md`
- `CLAIM_LANE_SCHEMA.json`
- `PAPER_REWORKS_CRYSTAL_PROJECTION.json`
- `AGENT_CRYSTAL_WORK_HARVEST.json`
- standards/window/node databases
- runtime/source folders
- Lattice forge actionization APIs
- Any source document, receipt, validator, figure, notebook, memory, or analog
  object being imported

## Projector Algorithm

Use this algorithm for every CAM/crystal import:

| Step | Action | Output |
|---|---|---|
| 1 | Create or locate the crystal | CAM address, source path, source hash if available |
| 2 | Load available faces | formal, companion, workbook, receipt, JSON, validator, API, memory, analog |
| 3 | Shine light through each face | claim-lane query, dependency query, residue query, falsifier query |
| 4 | Capture vignettes | small evidence readouts with source path and boundary |
| 5 | Route to next algorithm | import, compare, normal-form, tarpit, forge, calibration, falsifier, or obligation |

## 2x2 Adapter Handshake Worksheet

| Quadrant | Fill for this import |
|---|---|
| Source object | Exact source state, file, receipt, or memory object |
| Source face | Which representation is being projected |
| Target lane | Which claim lane the destination paper can consume |
| Target action | What the next algorithm is allowed to do |

The adapter succeeds only if all four cells are filled. If one cell is missing,
the row becomes an open obligation, not a silent import.

## CAM Address Receipt

```yaml
paper: FLCR-28
cam_address: ""
source_path: ""
source_hash: "external_or_pending"
faces_loaded:
  - formal
  - receipt
  - validator
projector_query: ""
vignette_output: ""
target_paper: ""
target_lane: ""
target_action: ""
residue: ""
falsifier: ""
```

## Face Query Table

| Face | Query | Required answer |
|---|---|---|
| Formal text | What claim does this support? | Claim sentence and lane |
| Receipt | What operation was replayed? | Input, operation, output, residue |
| Validator | What domain passed or failed? | Scope, count, pass/fail, limitation |
| Source card | What older work contributes? | Contribution and boundary |
| Forge/API | What lookup can be run? | Function, input, output, cache row |
| Analog | What state is preserved by relabeling? | Invariant object and transfer rule |
| Agent memory | What did the agent produce? | Source path, confidence, required corroboration |

## Vignette Record

Each vignette should be short but complete:

| Field | Required content |
|---|---|
| Vignette ID | Stable local ID |
| Source face | Which face produced the readout |
| Useful datum | What the readout contributes |
| Destination | Paper, supplement, forge, validator, or normal-form queue |
| Boundary | What the readout refuses to prove |
| Next action | Import, compare, calibrate, falsify, or leave as obligation |

## Forge Actionization

Use this table when a CAM object can become a lookup, verifier, or cached
answer.

| CAM item | Forge/API action | Typed result | Receipt/cache row | Boundary |
|---|---|---|---|---|
| Leech address candidate | `Forge.leech_lookup(address, payload)` | lookup result | lookup receipt | proves addressable construction only at input scope |
| Leech verifier | `Forge.verify_leech_lookup()` | pass/fail | verifier receipt | does not replace external calibration |
| Lattice code chain | `verify_lattice_code_chain` | chain validity | lattice receipt | limited to implemented code path |
| Golay-24 route | `verify_golay_24` | code validity | Golay receipt | not a physical claim by itself |
| Leech ribbon | `encode_leech_ribbon` | encoded ribbon | encoding receipt | downstream identity requires adapter |

## Worked Replay: Importing Standards-Window Evidence

| Step | Filled value |
|---|---|
| Source object | standards-window report |
| Source face | conformance verdict and window database |
| Vignette | 192/192 conformance can support standards-surface claims |
| Target lane | `normal_form_result` or `cam_crystal_reapplication_result` |
| Target paper | FLCR-30, FLCR-39, FLCR-40 |
| Boundary | conformance is not physical calibration |
| Next action | attach standards row to claim-lane or falsifier table |

## Worked Replay: Importing agent-generated/runtime Crystal Work

| Step | Filled value |
|---|---|
| Source object | Agent crystal harvest or runtime artifact |
| Source face | memory, source route, generated crystal, or instruction doc |
| Vignette | identifies a source, claim, route, or missing obligation |
| Target lane | `cam_crystal_reapplication_result` until corroborated |
| Target paper | whichever paper owns the object being routed |
| Boundary | agent output is not proof without receipt/citation/validator |
| Next action | source-placement, claim-binding, or workbook replay row |

## Analog Exercise

Build a physical crystal projector with index cards:

1. One card is the CAM address.
2. Each face is a different card: formal, receipt, validator, source, analog,
   forge, memory.
3. Shine a "query" by choosing one question: claim, dependency, residue,
   falsifier, or downstream use.
4. Write one vignette card.
5. Place the vignette in the target paper's tray.
6. Keep the source card attached so the vignette cannot become anonymous proof.

## Completion Criteria

- Every projected object has a CAM address or source path.
- Every face read produces a vignette with boundary.
- Every downstream import has a lane.
- Every forge action has an input, output, and receipt/cache row.
- Private or unavailable vault data remains explicitly marked as unavailable.
- No paper consumes agent memory, crystal output, or forge lookup as proof
  without the required receipt, citation, normal-form, calibration, or falsifier
  row.
