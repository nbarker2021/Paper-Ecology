# FLCR-16 - Mass Residue And Carrier Accounting

**Series:** Formalizing LCR, Unifying Standard Models  
**Artifact:** formal paper source  
**Status:** first-pass rich rewrite; requires final citation and build pass.  
**Claim posture:** maximal local claim posture with explicit lane boundaries.

## Abstract

This paper formalizes mass-like residue as carrier accounting before QFT translation. The operative object is mass-residue carrier. The core result is that finite sector residues can be carried as internal accounting quantities with explicit source and sector labels. The paper also defines how this result routes forward: FLCR-33 may translate the accounting into Higgs/QFT language only with citation and calibration boundaries. Its main residue is explicit: measured Higgs mass, QFT field identity, and physical mass calibration are not closed locally.

## Keywords

mass-residue carrier; LCR; receipt; claim lane; normal form.

## 1. Contribution And Scope

- Defines mass-residue carrier as a first-class FLCR object.
- States the local result: finite sector residues can be carried as internal accounting quantities with explicit source and sector labels.
- Routes downstream use through claim lanes rather than inherited prose: FLCR-33 may translate the accounting into Higgs/QFT language only with citation and calibration boundaries.
- Preserves the residue boundary: measured Higgs mass, QFT field identity, and physical mass calibration are not closed locally.

This paper is part of the LCR-native base layer. Standard Model or physical
language is permitted only as deferred mapping, analogy, or explicitly bounded
future calibration. The editable surface is the claim lane and source-routing
layer; the base objects must remain stable enough for downstream papers to
consume them without ambiguity.

## 2. Source Routing

Primary routed sources:

- `15_QFT_Higgs_Mass_Residue_Carrier.md`
- `virtuous/15_QFT_Higgs_Mass-Residue_Carrier_VIRTUOUS.md`
- `supplements/15_INTERNAL_REASONING_SUPPLEMENT.md`

Cross-corpus evidence classes:

- `CAM_CLAIM_100_SCORE_AUDIT.md`
- `NSIT_TOOL_CLOSURE_MATRIX.md`
- `NSIT_REASONED_CLOSURE_PASS.md`
- `PAPER_REWORKS_CRYSTAL_PROJECTION.json`
- standards, glue, window, and node databases where applicable
- notebook-derived review prompts and orbital source manifests

## 3. Definitions

- **Mass residue.** A carried residual scalar or sector label before physical unit assignment.
- **Sector label.** The finite class in which a residue is interpreted.
- **Receipt boundary.** The exact scope in which the paper's result can be replayed or consumed.
- **Promotion route.** The evidence path required before a stronger downstream claim can use this result.

## 4. Formal Claims

| Claim | Lane | Statement |
|-------|------|-----------|
| Theorem 16.1 | `receipt_bound_internal_result` | finite sector residues can be carried as internal accounting quantities with explicit source and sector labels |
| Proposition 16.2 | `normal_form_result` | mass-residue carrier can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 16.3 | `falsifier_or_open_obligation` | measured Higgs mass, QFT field identity, and physical mass calibration are not closed locally |

## 5. Paper-Specific Development

1. Identify the local object and its assigned sources for FLCR-16.
2. Separate what is internally receipt-bound from what is citation-bound, CAM-bound, calibration-bound, or still an obligation.
3. State the strongest admissible claim in its current lane.
4. Export only the lane-safe result to downstream papers and preserve the residue.

### Proof Sketch

The proof strategy for FLCR-16 is a typed construction argument. The paper names mass residue as the active object, binds it to the routed legacy and orbital sources, and then allows downstream use only through the declared claim lane. This does not erase stronger ambitions; it keeps them addressable as dependencies, calibration tasks, or falsifiers.

## 6. Construction

The construction is intentionally staged. First, the paper names the finite or
typed object that can be inspected directly. Second, it declares the admissible
operations over that object. Third, it records the receipt or source class that
allows another paper to consume the result. Fourth, it names the residue that
must not be silently promoted.

For this paper, the operative object is `Mass Residue And Carrier Accounting`. Its safe consumption
rule is:

```text
source object -> declared operation -> receipt/lane -> downstream import
```

The unsafe consumption rule is:

```text
source phrase -> downstream identity claim
```

That second pattern is explicitly rejected by FLCR-01 and must be rewritten as
a claim-lane promotion with evidence.

## 7. Evidence And Receipts

| Evidence source | What it contributes |
|-----------------|---------------------|
| Legacy paper body | Primary formal and source-integration material assigned by the series map. |
| Internal and pyramid supplements | Cross-paper reasoning windows, deferred back-application slots, and route constraints. |
| NSIT tool closure matrix | Existing verifier/tool families that can close internal or batch claims. |
| CAM/crystal and standards-window evidence | Projected memory, source routing, standards reports, and window/node databases. |

## 8. Dependencies And Downstream Use

This paper may be imported by later FLCR papers only through the claim lanes
above. The default downstream consumers are:

- `FLCR-11` through `FLCR-18` for window, receipt, admission, CA, algebraic,
  curvature, residue, and exceptional machinery.
- `FLCR-28` through `FLCR-30` for CAM/crystal, corpus ribbon, and universal
  normal-form intake.
- `FLCR-31` through `FLCR-40` only after the LCR-native result has been cited
  and the translation claim has its own evidence lane.

## 9. Limitations And Falsifiers

- measured Higgs mass, QFT field identity, and physical mass calibration are not closed locally
- External calibration claims require units, datasets, citations, and reproducible data binding.
- A later translation paper may strengthen this result only by adding the missing lane evidence.

A falsifier for this paper is any example that satisfies the declared input
conditions while violating the stated construction, receipt, or lane boundary.
An interpretation that merely wants a stronger downstream conclusion is not a
falsifier; it is an obligation routed to a later paper.

## 10. Publication Readiness Tasks

- Validator identities and receipt hashes are recorded in the manifest or receipt appendix.
- External theorems require final citation entries before journal submission.
- Every theorem, proposition, and protocol must retain a claim lane and evidence boundary.
- The Markdown, LaTeX, and PDF forms are generated from the same canonical source.

## Dual Positioning: Story And Formal Carrier

This paper must be read in two synchronized ways. Sequentially, it explains why
the next state exists in the corpus story. Formally, it binds that state to
accepted mathematics, IRL formalism, code receipts, validators, CAM/crystal
lookups, and claim-lane boundaries.

Assigned original ribbon role(s): `15`/carrier_action.

| Original slot | Family | Lift | Role | Proof form |
|---|---|---:|---|---|
| `15` | carrier_action | 1 | order-2 slot-5: carry the state through a path, traversal, or admissible motion | carrier/transducer/path proof |

The formal obligation is to state the strongest valid claim available for this
paper without letting interpretation silently change the addressed object. Any
author interpretation belongs beside the formalism as a declared relabeling,
bridge, or analog, and must be accompanied by the evidence lane that makes the
claim consumable by later papers.

## State-Bound Proof Contract

This paper receives: state emitted by prior slot 14 and reopened at original slot 15 (QFT Higgs Mass Residue Carrier).

It must produce: formal result of original slot 15 plus the same-family lift path toward slot 25.

Semantic transition: carry the state through an admissible path, traversal, transport, or transducer.

Accepted formalism targets to bind in the journal rewrite:

- path composition
- automata and transducers
- transport maps
- invariant preservation along morphisms

| Slot | Family | Lift | Produced proof form |
|---|---|---:|---|
| `15` | carrier_action | 1 | carrier/transducer/path proof |

The formal carrier uses these accepted tools while preserving interpretive
claims as explicit relabelings, correspondences, or bridges. Claim promotion is admissible only when a receipt, standard citation,
CAM/crystal reapplication, normal-form result, calibration datum, or falsifier
boundary is attached.

## Provenance And Crystal Evidence Integration

This section integrates prior work, CAM/crystal projections, NSIT tooling,
standards-window evidence, and routed supplements as provenance-bearing
evidence. Source material is not treated as manuscript text; it is bound into
the paper only through claim lanes, receipts, validators, normal forms,
calibration rows, or explicit falsifier boundaries.

### Expansion Rule For This Slot

Use past work to bind transport: path, transducer, traversal, carrier medium, invariant, and external calibration boundary.

### Primary Evidence Inputs

| Source | Placement reason |
|---|---|
| `15_QFT_Higgs_Mass_Residue_Carrier.md` | primary assigned source for the paper's formal spine |
| `supplements/15_INTERNAL_REASONING_SUPPLEMENT.md` | paper-local reasoning supplement contributing to definitions, proof sketch, and limitations |
| `virtuous\15_QFT_Higgs_Mass-Residue_Carrier_VIRTUOUS.md` | prior enriched paper body; should be mined for mature claims and proof ordering |

### Secondary And Orbital Evidence Inputs

| Source | Placement reason |
|---|---|
| `supplements/RECEIPT_VERIFIER_CATALOG.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_PYRAMID_INDEX.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_5P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_7P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_9P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `CAM_CLAIM_100_SCORE_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_TOOL_CLOSURE_MATRIX.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_REASONED_CLOSURE_PASS.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `ORBITAL_DATA_CROSS_POPULATION_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `AGENT_CRYSTAL_WORK_HARVEST.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `PAPER_REWORKS_CRYSTAL_PROJECTION.json` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NEW_PAPER_NEEDS.md` | route relevant obligations into this paper's burden table: NP-06 Empirical Calibration Protocols For Physics Bridges |
| Additional source routes | Complete routing is maintained in the source-placement appendix |

### Crystal And Standards Evidence To Bind

- Paper Reworks crystal projection: 33 paper markdown files, 9 supplements, 5 queues, 6 lattice-forge unification artifacts, 140 faces, 140 vignettes, and 280 CAM nodes.
- Standards-window intake: 192/192 corpus conformance verdicts PASS; 140/142 obligations have candidate routes; 2/4/8/16/32 window lattice is available for cross-paper reads.
- Agent/crystal harvest: agent-generated memory, runtime standards starter, current runtime build, repo-harvest CAM, notebook-derived bundles, and downloaded crystal payloads are orbital evidence surfaces.
- NSIT inventory baseline: 220 validators, 1786 receipt/data artifacts, 1137 formal-paper-like artifacts, 114 supplements, and 86 memory/CAM artifacts.

### Paper-Specific CAM/Score Rows

| 15 | 89 | internal mass-residue map closed | CL affirmative verifier: mass = VOA weight, 2 massless + 6 massive, Paper 18 VOA support | measured Higgs/QFT mass calibration |

### Paper-Specific NSIT Closure Rows

No direct NSIT row matched the assigned legacy papers in the first-pass matrix; validator matching by object name remains a receipt-attachment requirement.

### Source Integration Summary

The legacy source and internal reasoning supplement are treated as source
evidence rather than manuscript prose. Their contributions enter this paper as
claim-lane entries, receipt or validator references, finite-domain statements,
and limitation boundaries. Speculative or cross-domain interpretations remain
separate from closed local results until an explicit adapter, citation,
normal-form derivation, calibration row, or falsifier is attached.
## Claim Binding Queue

This queue records the evidence discipline for claim strengthening. It separates claims that already have support from residues that remain in falsifier or open-obligation lanes.

| Queue | Lane | Promote now | Bind next | Residue |
|---|---|---|---|---|
| Symbolic Carrier Versus Physical Carrier | `external_calibration_result` | Promote addressable symbolic-carrier and transport claims where the paper names carrier, path, residue, or traversal rules. | Map every physical carrier phrase to a standard physics object, Hamiltonian/model, dataset, or calibration route before treating it as measured physics. | Physical identity, units, material constants, and measured transport remain calibration-bound. |
| Electron-Hole-Exciton Standard Accounting | `standard_theorem_citation_bound_result` | Treat hole, vacancy, exciton, recombination, screening, band-gap, and effective-mass language as standard-model correspondence when a material model is present. | Attach standard equations/citations and state what LCR adds: addressability, obligation routing, and residue bookkeeping. | Actual material behavior and quantitative exciton claims need a material model, units, and data. |

### Binding Discipline

Each queue item is represented as a delta:

```text
local claim at paper time
-> attached later source/tool/receipt/theorem
-> revised representation
-> invariant boundary and remaining residue
```

This preserves the sequential story while allowing later tools, crystals, and
standard formalisms to return through the proper lane.

## Claim Delta Ledger

This ledger applies the paper's claim-binding queues as explicit back-application
deltas. It keeps the sequential paper story intact while allowing later
receipts, standard formalisms, CAM/crystal routes, and validators to sharpen the
claim.

| Delta | Local claim at paper time | Later evidence | Revised representation | Boundary kept |
|---|---|---|---|---|
| Symbolic Vs Physical Carrier | This paper may use carrier language for addressable symbolic transport inside the LCR/CAM system. | Standard physics carrier terminology, local verifier receipts, material/plasma/transport supplements, and calibration routes. | Split symbolic carrier closure from measured physical carrier identity. | Physical identity, units, Hamiltonians, datasets, and measured constants remain external-calibration claims. |
| Electron Hole Exciton Accounting | Vacancy, complement, hole, residue, and excitation language may appear as LCR addressability/residue vocabulary. | Standard electron-hole-exciton formalism, material-model rows, band-gap/screening/recombination equations, and NP-12 routing. | Treat hole/exciton vocabulary as standard correspondence where a material model exists, while preserving LCR's contribution as addressability and obligation bookkeeping. | Quantitative material behavior requires model parameters, units, citations, and data. |

The revised representation records the strongest claim supported by the current evidence package. Promotion into theorem or proposition language occurs only when the named evidence is attached in the manifest or workbook replay.

## Source-Backed Evidence Summary

Routed archive and mirror cards are treated as provenance summaries rather than
body text. They identify candidate receipts, validators, theorem registries, or
supplemental source routes. A card strengthens this paper only when its
contribution is bound to a claim lane, evidence object, and boundary.

| Evidence card | Score | Publication contribution | Boundary |
|---|---:|---|---|
| FORMAL: Paper 11 — C-Form: Theory Admission Gate Gluon | 77 | **C = the admission filter Gluon** — the trust anchor that filters external theories by Gluon mass matching. In the lattice_forge substrate, C is realized as the **admission gate** that: - Takes an external theory's G... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| SUMMARY-II-Folded-Strand-Physics: Summary Paper II — Folded Strand Physics: The Gluon as Quark, Mass, Curvature, Tower, and Moonshine | 75 | This paper presents the **physics applications** of the Gluon formalism. We do not use the word "Gluon" because the fit is good. We use it because the substrate **IS** SU(3), and the physics IS the **standard model ga... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| PAPER-BODY: CQE Paper 32 — The Supervisor Cursor: Superpermutations as the Compressed Dimensional Action Graph | 69 | - **O-32.1** — The n=8 corridor: 120 symbols between 46085 and 46205. Egan's n=7 search methods (kernel graphs over 2-cycle/3-cycle quotients) transported to n=8 inside this format. - **O-32.2** — Validate the octad-o... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| PAPER-BODY: Paper 15 - QFT/Higgs Mass-Residue Carrier | 69 | This paper states a local transport problem, gives a formal vocabulary for it, binds it to a ForgeFactory/Rhenium tool surface, and supplies an analog workbook sheet. The paper is written as a proof-facing document ra... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| CQE-paper-15.50: Paper 15.50 - Mass-Residue Carrier Claim Contract | 69 | Paper 15.50 keeps the strongest useful object visible: a finite residue carrier with a real receipt. The physical interpretation is the next problem, not an automatic consequence. | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| Additional evidence cards | 12 total | The complete card inventory is maintained in the archive evidence matrix. | Cards are source-discovery aids until bound to paper-local evidence. |

## Journal Apparatus

### Article Type And Intended Venue Fit

This manuscript is written as a formal-methods and mathematical-systems paper
inside the series *Formalizing LCR, Unifying Standard Models*. Its intended
reader is a technical reviewer who needs claim boundaries, reproducibility
routes, and cross-paper dependencies to be visible without relying on private
context.

### Structured Contribution Statement

| Item | Statement |
|---|---|
| Publication ID | `FLCR-16` |
| Legacy source slot(s) | `15` |
| Ribbon role | order-2 slot-5: carry the state through a path, traversal, or admissible motion |
| Proof form | carrier/transducer/path proof |
| Received state | state emitted by prior slot 14 and reopened at original slot 15 (QFT Higgs Mass Residue Carrier) |
| Produced state | formal result of original slot 15 plus the same-family lift path toward slot 25 |

### Claim-Evidence Table

| Claim | Lane | Evidence to attach | Boundary |
|---|---|---|---|
| Theorem 16.1 | `receipt_bound_internal_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | finite sector residues can be carried as internal accounting quantities with explicit source and sector labels |
| Proposition 16.2 | `normal_form_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | mass-residue carrier can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 16.3 | `falsifier_or_open_obligation` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | measured Higgs mass, QFT field identity, and physical mass calibration are not closed locally |

### Figure Plan

| Figure | Purpose | Caption |
|---|---|---|
| FLCR-16-F1 | Carrier path and invariant payload | Schematic showing how `FLCR-16` turns its received state into the produced state while preserving claim lanes and residue boundaries. |
| FLCR-16-F2 | Evidence routing map | Diagram of source papers, archive cards, CAM/crystal routes, validators, and workbook replay paths used by this manuscript. |
| FLCR-16-F3 | Same-family lift context | Diagram placing this paper in the original `00-79` ribbon family and showing predecessor/successor slots. |

### In-Text Figure FLCR-16-F1: Carrier path and invariant payload

```text
received state
  -> Carrier path and invariant payload
  -> formal claim lane
  -> evidence object / receipt / citation
  -> produced state
  -> remaining residue
```

### Table Plan

| Table | Purpose |
|---|---|
| FLCR-16-T1 | Carrier transport table |
| FLCR-16-T2 | Claim-lane/evidence-boundary table |
| FLCR-16-T3 | Archive evidence card and source-backed upgrade table |
| FLCR-16-T4 | Workbook replay and falsifier table |

### Worked Example

Carry one state through a path/transducer and show what remains invariant. The example must name the input object, the operation,
the evidence object, the allowed revised claim, and the remaining boundary.

### Nomenclature And Glossary

| Term | Paper-local meaning |
|---|---|
| CAM | Defined by this paper as part of the `carrier_action` proof role; final definition is recorded in the paper-local glossary. |
| carrier | Defined by this paper as part of the `carrier_action` proof role; final definition is recorded in the paper-local glossary. |
| claim lane | Defined by this paper as part of the `carrier_action` proof role; final definition is recorded in the paper-local glossary. |
| crystal | Defined by this paper as part of the `carrier_action` proof role; final definition is recorded in the paper-local glossary. |
| invariant payload | Defined by this paper as part of the `carrier_action` proof role; final definition is recorded in the paper-local glossary. |
| path composition | Defined by this paper as part of the `carrier_action` proof role; final definition is recorded in the paper-local glossary. |
| receipt | Defined by this paper as part of the `carrier_action` proof role; final definition is recorded in the paper-local glossary. |
| transport | Defined by this paper as part of the `carrier_action` proof role; final definition is recorded in the paper-local glossary. |

### Appendix FLCR-16-A: Evidence Package

The appendix records:

1. Legacy source excerpts or source-card references used in the final claim ledger.
2. Receipt and verifier paths, including pass/fail/partial status.
3. CAM/crystal query or projection rows used by the paper, with source identity and boundary.
4. Standards-window and NSIT evidence used for conformance or routing.
5. Falsifier, calibration, or external-data rows that remain unresolved.

### Data And Code Availability

The publication package contains the canonical Markdown sources, manifests, source-routing matrices, validation reports, and generated PDF/TeX outputs.

Code and verifier references are cited through manifests, archive evidence cards, receipt catalogs, or workbook replay tables. External datasets or
standards citations must be attached before any calibration-bound claim is
promoted.

### Reviewer Checklist

| Check | Reviewer question |
|---|---|
| Claim lane | Does every strong claim declare its lane and evidence type? |
| Boundary | Does the paper preserve what it does not prove? |
| Reproducibility | Is there a receipt, verifier, source card, citation, or replay table for the claim? |
| Cross-paper import | Does the paper cite the prior FLCR/OPR slot before consuming its result? |
| Interpretation | Does the analog layer preserve the addressed state while changing labels/access paths? |

### Declarations

No human-subjects, clinical, or animal-research protocol is asserted by this
paper. External empirical claims require separate dataset, calibration, or
domain-validation attachments. Competing-interest and funding statements are recorded in the submission metadata.

## 11. Publication Integration Addendum

### 11.1 Role In The Series

`FLCR-16` (`Mass Residue And Carrier Accounting`) occupies the `carrier_action` role at lift depth `1`.
The paper receives state emitted by prior slot 14 and reopened at original slot 15 (QFT Higgs Mass Residue Carrier). It produces formal result of original slot 15 plus the same-family lift path toward slot 25. The state transition is:
carry the state through an admissible path, traversal, transport, or transducer.

The paper-local proof form is:

```text
carrier/transducer/path proof
```

The integration result is a state-preserving carrier or transducer route with recorded loss/residue. This addendum records how that result is
consumed by the publication series without relying on editorial instructions or
private working context.

### 11.2 Formal Carrier

| Formal carrier | Function |
|---|---|
| path composition | Formal carrier for the paper-local result. |
| automata and transducers | Formal carrier for the paper-local result. |
| transport maps | Formal carrier for the paper-local result. |
| invariant preservation along morphisms | Formal carrier for the paper-local result. |

The LCR, CAM, crystal, forge, and analog vocabulary functions as a typed access
layer over these carriers. A relabeling is admissible only when the addressed
object, evidence lane, boundary, and downstream import rule remain attached.

### 11.3 Claim Ledger

| Claim | Lane | Statement |
|---|---|---|
| Theorem 16.1 | `receipt_bound_internal_result` | finite sector residues can be carried as internal accounting quantities with explicit source and sector labels |
| Proposition 16.2 | `normal_form_result` | mass-residue carrier can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 16.3 | `falsifier_or_open_obligation` | measured Higgs mass, QFT field identity, and physical mass calibration are not closed locally |

These claims are consumed at their stated lane. A stronger downstream statement
creates a new claim envelope with its own evidence object.

### 11.4 Evidence Package

| Evidence class | Routed items | Status |
|---|---|---|
| Legacy sources | `15_QFT_Higgs_Mass_Residue_Carrier.md`, `virtuous/15_QFT_Higgs_Mass-Residue_Carrier_VIRTUOUS.md`, `supplements/15_INTERNAL_REASONING_SUPPLEMENT.md` | routed evidence |
| Evidence inputs | `CAM_CLAIM_100_SCORE_AUDIT.md`, `NSIT_TOOL_CLOSURE_MATRIX.md`, `NSIT_REASONED_CLOSURE_PASS.md`, `PAPER_REWORKS_CRYSTAL_PROJECTION.json` | routed evidence |
| CAM/crystal sources | `PAPER_REWORKS_CRYSTAL_PROJECTION.json`, `AGENT_CRYSTAL_WORK_HARVEST.json`, `runtime standards artifact`, `notebook-derived source bundle` | routed evidence |
| Standards-window inputs | `window_summary.json`, `node DBs`, `window DBs` | routed evidence |
| Receipts | external requirement | not attached in this source package |
| Validators | external requirement | not attached in this source package |

Standards-window, runtime, and notebook-derived artifacts are treated
as evidence-routing surfaces. They support source discovery, conformance
checking, and reapplication, but they do not replace citations, receipts,
normal-form derivations, calibration rows, or falsifiers.

### 11.5 Results Representation

The paper's results section is organized around five publication objects:

1. the exact object acted on at this slot;
2. the admissible operation or transformation;
3. the receipt, enumeration, derivation, lookup, or external theorem supporting
   the operation;
4. the residue or boundary left after the result;
5. the downstream import rule.

### 11.6 Figures And Tables

| Figure | Role |
|---|---|
| FLCR-16-F1: Carrier path and invariant payload | Visualizes the proof object, routing, or boundary. |
| FLCR-16-F2: Evidence routing map | Visualizes the proof object, routing, or boundary. |
| FLCR-16-F3: Same-family lift context | Visualizes the proof object, routing, or boundary. |

| Table | Role |
|---|---|
| FLCR-16-T1: Carrier transport table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-16-T2: Claim-lane/evidence-boundary table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-16-T3: Archive evidence card and source-backed upgrade table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-16-T4: Workbook replay and falsifier table | Records claim lanes, evidence, sources, or falsifiers. |

### 11.7 Limits And Falsifiers

The paper proves only the object and domain declared in its claim ledger.
Physical, Standard Model, observer, calibration, or synthesis claims require
the additional lane evidence stated by their destination papers. CAM/crystal
and forge language is operational only when represented as an address, lookup,
receipt, validator, or reapplication path.
