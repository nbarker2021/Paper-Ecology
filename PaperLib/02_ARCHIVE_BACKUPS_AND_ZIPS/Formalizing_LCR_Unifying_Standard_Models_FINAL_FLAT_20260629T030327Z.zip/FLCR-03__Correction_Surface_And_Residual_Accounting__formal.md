# FLCR-03 - Correction Surface And Residual Accounting

**Series:** Formalizing LCR, Unifying Standard Models  
**Artifact:** formal paper source  
**Status:** first-pass rich rewrite; requires final citation and build pass.  
**Claim posture:** maximal local claim posture with explicit lane boundaries.

## Abstract

This paper formalizes the correction surface as an exact Boolean residual between a linear radius-1 carrier and the Rule 30 target. Over GF(2), Rule 30 decomposes into Rule 90 plus the residual C and not R. The correction surface is therefore a finite syndrome-like obstruction, not an unexplained repair force and not a physical field without later calibration.

## Keywords

Rule 30; Rule 90; GF(2); residual; syndrome.

## 1. Contribution And Scope

- States the algebraic normal form decomposition of Rule 30 against Rule 90.
- Identifies the local correction condition C=1 and R=0.
- Treats correction as a typed residual/syndrome object for later repair.
- Rejects contradictory firing-set variants unless they carry a migration receipt.

This paper is part of the LCR-native base layer. Standard Model or physical
language is permitted only as deferred mapping, analogy, or explicitly bounded
future calibration. The editable surface is the claim lane and source-routing
layer; the base objects must remain stable enough for downstream papers to
consume them without ambiguity.

### Series Posture Inherited From FLCR-01

This paper inherits the FLCR-01 doctrine. Guardrails are automation controls:
they govern AI agents, validators, build scripts, generated prose, and claim
promotion workflows. They are not restrictions on human creativity or
hypothesis formation.

The paper should therefore name the strongest intended reading of `Correction Surface And Residual Accounting`,
display the parts already proved at this layer, and route the remaining
distance as explicit open obligations. Those obligations are channels from the
current prestate into later exploration.

The analog/workbook layer is also an access kit. It should preserve the local
state in forms that can eventually be replayed without electricity, internet,
computers, or paper. Later papers may work toward literal physics even where
this local paper only supplies the finite or LCR-native carrier.

## 2. Source Routing

Primary routed sources:

- `02_Correction_Surface.md`
- `supplements/02_INTERNAL_REASONING_SUPPLEMENT.md`

Cross-corpus evidence classes:

- `CAM_CLAIM_100_SCORE_AUDIT.md`
- `NSIT_TOOL_CLOSURE_MATRIX.md`
- `NSIT_REASONED_CLOSURE_PASS.md`
- `PAPER_REWORKS_CRYSTAL_PROJECTION.json`
- standards, glue, window, and node databases where applicable
- notebook-derived review prompts and orbital source manifests

## 3. Definitions

- **Rule 30 ANF.** R30(L,C,R) = L xor C xor R xor (C and R) over GF(2).
- **Rule 90 base.** R90(L,C,R) = L xor R.
- **Correction residual.** corr = R30 xor R90 = C xor (C and R) = C and not R.
- **Syndrome-like obstruction.** A localized mismatch record that identifies repair demand without itself being the repaired theorem.

## 4. Formal Claims

| Claim | Lane | Statement |
|-------|------|-----------|
| Theorem 3.1 | `receipt_bound_internal_result` | The Rule 30 correction surface over the binary LCR chart is exactly C and not R. |
| Proposition 3.2 | `receipt_bound_internal_result` | The left bit indexes two copies of the same obstruction because the residual condition is independent of L. |
| Protocol 3.3 | `falsifier_or_open_obligation` | Any later physical, McKay, VOA, or telemetry interpretation must consume this residual through a typed promotion lane. |

## 5. Paper-Specific Development

1. Write Rule 30 and Rule 90 in algebraic normal form over GF(2).
2. Take their xor difference and reduce it to C and not R.
3. Enumerate the eight states and verify that only C=1,R=0 fires, with L free.
4. Export the firing rows as typed residuals for boundary repair rather than as completed downstream interpretations.

### Proof Sketch

The identity is algebraic and finite. Rule 30 is L xor C xor R xor CR; Rule 90 is L xor R. Xor cancellation removes L and R, leaving C xor CR. Over Boolean values this is C(1 xor R), equivalent to C and not R. The complete truth table verifies the same result over the whole domain.

## 6. Construction

The construction is intentionally staged. First, the paper names the finite or
typed object that can be inspected directly. Second, it declares the admissible
operations over that object. Third, it records the receipt or source class that
allows another paper to consume the result. Fourth, it names the residue that
must not be silently promoted.

For this paper, the operative object is `Correction Surface And Residual Accounting`. Its safe consumption
rule is:

```text
source object -> declared operation -> receipt/lane -> downstream import
```

The unsafe consumption rule is:

```text
source phrase -> downstream identity claim
```

That second pattern is explicitly rejected by FLCR-01 and must be rewritten as
a claim-lane promotion with evidence.

## 7. Evidence And Receipts

| Evidence source | What it contributes |
|-----------------|---------------------|
| Paper 02 legacy body | Correction theorem, finite verifier, D4 projection intake. |
| Internal supplement 02 | GF(2) ANF, syndrome/innovation/proof-obligation framing. |
| NSIT tool matrix | Rule90/Lucas decomposition receipt closes the internal correction core. |
| CAM Claim 100 Score Audit | Paper 02 scored 93 internally closed; McKay parity routed beyond paper-local scope. |

## 8. Dependencies And Downstream Use

This paper may be imported by later FLCR papers only through the claim lanes
above. The default downstream consumers are:

- `FLCR-11` through `FLCR-18` for window, receipt, admission, CA, algebraic,
  curvature, residue, and exceptional machinery.
- `FLCR-28` through `FLCR-30` for CAM/crystal, corpus ribbon, and universal
  normal-form intake.
- `FLCR-31` through `FLCR-40` only after the LCR-native result has been cited
  and the translation claim has its own evidence lane.

## 9. Limitations And Falsifiers

- This paper closes the local finite residual, not the unbounded McKay or Moonshine route.
- Correction is not a measured force, field, or particle interaction at this stage.
- Any three-state correction import conflicts with the stated Boolean identity unless explicitly re-scoped.

A falsifier for this paper is any example that satisfies the declared input
conditions while violating the stated construction, receipt, or lane boundary.
An interpretation that merely wants a stronger downstream conclusion is not a
falsifier; it is an obligation routed to a later paper.

## 10. Publication Readiness Tasks

- Validator identities and receipt hashes are recorded in the manifest or receipt appendix.
- External theorems require final citation entries before journal submission.
- Every theorem, proposition, and protocol must retain a claim lane and evidence boundary.
- The Markdown, LaTeX, and PDF forms are generated from the same canonical source.

## Dual Positioning: Story And Formal Carrier

This paper must be read in two synchronized ways. Sequentially, it explains why
the next state exists in the corpus story. Formally, it binds that state to
accepted mathematics, IRL formalism, code receipts, validators, CAM/crystal
lookups, and claim-lane boundaries.

Assigned original ribbon role(s): `02`/residual_action.

| Original slot | Family | Lift | Role | Proof form |
|---|---|---:|---|---|
| `02` | residual_action | 0 | order-1 slot-2: mark the correction, residue, vacancy, or mismatch surface | residual accounting and bounded/unbounded split |

The formal obligation is to state the strongest valid claim available for this
paper without letting interpretation silently change the addressed object. Any
author interpretation belongs beside the formalism as a declared relabeling,
bridge, or analog, and must be accompanied by the evidence lane that makes the
claim consumable by later papers.

## State-Bound Proof Contract

This paper receives: state emitted by prior slot 01 and reopened at original slot 02 (Correction Surface).

It must produce: formal result of original slot 02 plus the same-family lift path toward slot 12.

Semantic transition: measure the mismatch, residue, vacancy, correction surface, or remaining obligation after enumeration.

Accepted formalism targets to bind in the journal rewrite:

- residue classes and quotient accounting
- error-correction or syndrome notation
- truth tables and exhaustive finite checks
- bounded versus unbounded domain separation

| Slot | Family | Lift | Produced proof form |
|---|---|---:|---|
| `02` | residual_action | 0 | residual accounting and bounded/unbounded split |

The formal carrier uses these accepted tools while preserving interpretive
claims as explicit relabelings, correspondences, or bridges. Claim promotion is admissible only when a receipt, standard citation,
CAM/crystal reapplication, normal-form result, calibration datum, or falsifier
boundary is attached.

## Provenance And Crystal Evidence Integration

This section integrates prior work, CAM/crystal projections, NSIT tooling,
standards-window evidence, and routed supplements as provenance-bearing
evidence. Source material is not treated as manuscript text; it is bound into
the paper only through claim lanes, receipts, validators, normal forms,
calibration rows, or explicit falsifier boundaries.

### Expansion Rule For This Slot

Use past work to split closed core from residue: correction tables, mismatch rows, open obligations, and bounded/unbounded domains must remain separate.

### Primary Evidence Inputs

| Source | Placement reason |
|---|---|
| `02_Correction_Surface.md` | primary assigned source for the paper's formal spine |
| `supplements/02_INTERNAL_REASONING_SUPPLEMENT.md` | paper-local reasoning supplement contributing to definitions, proof sketch, and limitations |

### Secondary And Orbital Evidence Inputs

| Source | Placement reason |
|---|---|
| `supplements/SM_BRIDGE_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/RECEIPT_VERIFIER_CATALOG.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_PYRAMID_INDEX.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_5P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_7P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_9P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `CAM_CLAIM_100_SCORE_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_TOOL_CLOSURE_MATRIX.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_REASONED_CLOSURE_PASS.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `ORBITAL_DATA_CROSS_POPULATION_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `AGENT_CRYSTAL_WORK_HARVEST.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `PAPER_REWORKS_CRYSTAL_PROJECTION.json` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| Additional source routes | Complete routing is maintained in the source-placement appendix |

### Crystal And Standards Evidence To Bind

- Paper Reworks crystal projection: 33 paper markdown files, 9 supplements, 5 queues, 6 lattice-forge unification artifacts, 140 faces, 140 vignettes, and 280 CAM nodes.
- Standards-window intake: 192/192 corpus conformance verdicts PASS; 140/142 obligations have candidate routes; 2/4/8/16/32 window lattice is available for cross-paper reads.
- Agent/crystal harvest: agent-generated memory, runtime standards starter, current runtime build, repo-harvest CAM, notebook-derived bundles, and downloaded crystal payloads are orbital evidence surfaces.
- NSIT inventory baseline: 220 validators, 1786 receipt/data artifacts, 1137 formal-paper-like artifacts, 114 supplements, and 86 memory/CAM artifacts.

### Paper-Specific CAM/Score Rows

| 02 | 93 | internally closed | exact Rule30/Rule90 correction surface, two-state firing set, Paper 03 coordinate preservation | McKay parity and E-lift routed beyond paper-local scope |

### Paper-Specific NSIT Closure Rows

No direct NSIT row matched the assigned legacy papers in the first-pass matrix; validator matching by object name remains a receipt-attachment requirement.

### Source Integration Summary

The legacy source and internal reasoning supplement are treated as source
evidence rather than manuscript prose. Their contributions enter this paper as
claim-lane entries, receipt or validator references, finite-domain statements,
and limitation boundaries. Speculative or cross-domain interpretations remain
separate from closed local results until an explicit adapter, citation,
normal-form derivation, calibration row, or falsifier is attached.
## Claim Binding Queue

This queue records the evidence discipline for claim strengthening. It separates claims that already have support from residues that remain in falsifier or open-obligation lanes.

| Queue | Promote now | Bind next | Residue |
|---|---|---|---|
| none directly assigned | Source routing and claim lanes identify paper-local binding actions. | Verifier catalogs and CAM/crystal routes provide object-name evidence candidates. | Unbound claims remain in falsifier/open-obligation lanes. |

### Binding Discipline

Each queue item is represented as a delta:

```text
local claim at paper time
-> attached later source/tool/receipt/theorem
-> revised representation
-> invariant boundary and remaining residue
```

This preserves the sequential story while allowing later tools, crystals, and
standard formalisms to return through the proper lane.

## Claim Delta Ledger

This ledger applies the paper's claim-binding queues as explicit back-application
deltas. It keeps the sequential paper story intact while allowing later
receipts, standard formalisms, CAM/crystal routes, and validators to sharpen the
claim.

| Delta | Local claim at paper time | Later evidence | Revised representation | Boundary kept |
|---|---|---|---|---|
| Search By Object Name | No direct reasoned-closure queue was assigned from the first queue map. | Search source routing, verifier catalog, CAM/crystal routes, and paper-local object names. | Create a specific binding queue when an object-name match finds a validator, receipt, theorem, or calibration route. | Until then, claims remain in their existing lanes. |

The revised representation records the strongest claim supported by the current evidence package. Promotion into theorem or proposition language occurs only when the named evidence is attached in the manifest or workbook replay.

## Source-Backed Evidence Summary

Routed archive and mirror cards are treated as provenance summaries rather than
body text. They identify candidate receipts, validators, theorem registries, or
supplemental source routes. A card strengthens this paper only when its
contribution is bound to a claim lane, evidence object, and boundary.

| Evidence card | Score | Publication contribution | Boundary |
|---|---:|---|---|
| CQE-paper-04.25: Paper 4.25 - Toolkit for Boundary Repair | 81 | Paper 4.25 describes the review tools for boundary repair. The tools help a reader construct and inspect repair rows. They do not add claims beyond the Paper 4 theorem. The toolkit works with: ```text correction state... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| FINAL_FORMAL_PAPER: Complete Formal Claims: The Folded Strand | 75 | We present the complete closed-form claim set of the CQE_CMPLX corpus: - 33 papers = 33 folding operations on a self-complementary strand - 144 tools = cumulative analog kit = digital twin surface - 135 digital twins ... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| SUMMARY-V-32-Theorems-Registry: Summary Paper V — The 32 Theorems in One Table: Closed-Form Registry | 75 | This paper is the **complete closed-form registry of all 32 theorems** in the CQE_CMPLX corpus. Each theorem is stated precisely, given its formal context (where it is proven), and listed with its verifier. The table ... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| CQE-paper-02.50: Paper 2.50 - Correction Surface Claim Contract | 73 | Paper 2.50 lets later papers import the correction surface honestly. It keeps the finite theorem available while preserving the distinction between residue, obligation, and proof. | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| FORMAL: Paper 01 — Side-Flip SU(2) Doublet (T_BIJECTIVE) | 73 | **PROVEN by structural identification** on the T3 chart/J₃(O) isomorphism. | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| Additional evidence cards | 26 total | The complete card inventory is maintained in the archive evidence matrix. | Cards are source-discovery aids until bound to paper-local evidence. |

## Journal Apparatus

### Article Type And Intended Venue Fit

This manuscript is written as a formal-methods and mathematical-systems paper
inside the series *Formalizing LCR, Unifying Standard Models*. Its intended
reader is a technical reviewer who needs claim boundaries, reproducibility
routes, and cross-paper dependencies to be visible without relying on private
context.

### Structured Contribution Statement

| Item | Statement |
|---|---|
| Publication ID | `FLCR-03` |
| Legacy source slot(s) | `02` |
| Ribbon role | order-1 slot-2: mark the correction, residue, vacancy, or mismatch surface |
| Proof form | residual accounting and bounded/unbounded split |
| Received state | state emitted by prior slot 01 and reopened at original slot 02 (Correction Surface) |
| Produced state | formal result of original slot 02 plus the same-family lift path toward slot 12 |

### Claim-Evidence Table

| Claim | Lane | Evidence to attach | Boundary |
|---|---|---|---|
| Theorem 3.1 | `receipt_bound_internal_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | The Rule 30 correction surface over the binary LCR chart is exactly C and not R. |
| Proposition 3.2 | `receipt_bound_internal_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | The left bit indexes two copies of the same obstruction because the residual condition is independent of L. |
| Protocol 3.3 | `falsifier_or_open_obligation` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | Any later physical, McKay, VOA, or telemetry interpretation must consume this residual through a typed promotion lane. |

### Figure Plan

| Figure | Purpose | Caption |
|---|---|---|
| FLCR-03-F1 | Residual split diagram | Schematic showing how `FLCR-03` turns its received state into the produced state while preserving claim lanes and residue boundaries. |
| FLCR-03-F2 | Evidence routing map | Diagram of source papers, archive cards, CAM/crystal routes, validators, and workbook replay paths used by this manuscript. |
| FLCR-03-F3 | Same-family lift context | Diagram placing this paper in the original `00-79` ribbon family and showing predecessor/successor slots. |

### In-Text Figure FLCR-03-F1: Residual split diagram

```text
received state
  -> Residual split diagram
  -> formal claim lane
  -> evidence object / receipt / citation
  -> produced state
  -> remaining residue
```

### Table Plan

| Table | Purpose |
|---|---|
| FLCR-03-T1 | Residual accounting table |
| FLCR-03-T2 | Claim-lane/evidence-boundary table |
| FLCR-03-T3 | Archive evidence card and source-backed upgrade table |
| FLCR-03-T4 | Workbook replay and falsifier table |

### Worked Example

Split one claim into closed core, residue, bounded domain, and unbounded burden. The example must name the input object, the operation,
the evidence object, the allowed revised claim, and the remaining boundary.

### Nomenclature And Glossary

| Term | Paper-local meaning |
|---|---|
| CAM | Defined by this paper as part of the `residual_action` proof role; final definition is recorded in the paper-local glossary. |
| bounded domain | Defined by this paper as part of the `residual_action` proof role; final definition is recorded in the paper-local glossary. |
| claim lane | Defined by this paper as part of the `residual_action` proof role; final definition is recorded in the paper-local glossary. |
| correction surface | Defined by this paper as part of the `residual_action` proof role; final definition is recorded in the paper-local glossary. |
| crystal | Defined by this paper as part of the `residual_action` proof role; final definition is recorded in the paper-local glossary. |
| receipt | Defined by this paper as part of the `residual_action` proof role; final definition is recorded in the paper-local glossary. |
| residue | Defined by this paper as part of the `residual_action` proof role; final definition is recorded in the paper-local glossary. |
| unbounded burden | Defined by this paper as part of the `residual_action` proof role; final definition is recorded in the paper-local glossary. |

### Appendix FLCR-03-A: Evidence Package

The appendix records:

1. Legacy source excerpts or source-card references used in the final claim ledger.
2. Receipt and verifier paths, including pass/fail/partial status.
3. CAM/crystal query or projection rows used by the paper, with source identity and boundary.
4. Standards-window and NSIT evidence used for conformance or routing.
5. Falsifier, calibration, or external-data rows that remain unresolved.

### Data And Code Availability

The publication package contains the canonical Markdown sources, manifests, source-routing matrices, validation reports, and generated PDF/TeX outputs.

Code and verifier references are cited through manifests, archive evidence cards, receipt catalogs, or workbook replay tables. External datasets or
standards citations must be attached before any calibration-bound claim is
promoted.

### Reviewer Checklist

| Check | Reviewer question |
|---|---|
| Claim lane | Does every strong claim declare its lane and evidence type? |
| Boundary | Does the paper preserve what it does not prove? |
| Reproducibility | Is there a receipt, verifier, source card, citation, or replay table for the claim? |
| Cross-paper import | Does the paper cite the prior FLCR/OPR slot before consuming its result? |
| Interpretation | Does the analog layer preserve the addressed state while changing labels/access paths? |

### Declarations

No human-subjects, clinical, or animal-research protocol is asserted by this
paper. External empirical claims require separate dataset, calibration, or
domain-validation attachments. Competing-interest and funding statements are recorded in the submission metadata.

## 11. Publication Integration Addendum

### 11.1 Role In The Series

`FLCR-03` (`Correction Surface And Residual Accounting`) occupies the `residual_action` role at lift depth `0`.
The paper receives state emitted by prior slot 01 and reopened at original slot 02 (Correction Surface). It produces formal result of original slot 02 plus the same-family lift path toward slot 12. The state transition is:
measure the mismatch, residue, vacancy, correction surface, or remaining obligation after enumeration.

The paper-local proof form is:

```text
residual accounting and bounded/unbounded split
```

The integration result is a bounded residual object separated from its downstream repair obligations. This addendum records how that result is
consumed by the publication series without relying on editorial instructions or
private working context.

### 11.2 Formal Carrier

| Formal carrier | Function |
|---|---|
| residue classes and quotient accounting | Formal carrier for the paper-local result. |
| error-correction or syndrome notation | Formal carrier for the paper-local result. |
| truth tables and exhaustive finite checks | Formal carrier for the paper-local result. |
| bounded versus unbounded domain separation | Formal carrier for the paper-local result. |

The LCR, CAM, crystal, forge, and analog vocabulary functions as a typed access
layer over these carriers. A relabeling is admissible only when the addressed
object, evidence lane, boundary, and downstream import rule remain attached.

### 11.3 Claim Ledger

| Claim | Lane | Statement |
|---|---|---|
| Theorem 3.1 | `receipt_bound_internal_result` | The Rule 30 correction surface over the binary LCR chart is exactly C and not R. |
| Proposition 3.2 | `receipt_bound_internal_result` | The left bit indexes two copies of the same obstruction because the residual condition is independent of L. |
| Protocol 3.3 | `falsifier_or_open_obligation` | Any later physical, McKay, VOA, or telemetry interpretation must consume this residual through a typed promotion lane. |

These claims are consumed at their stated lane. A stronger downstream statement
creates a new claim envelope with its own evidence object.

### 11.4 Evidence Package

| Evidence class | Routed items | Status |
|---|---|---|
| Legacy sources | `02_Correction_Surface.md`, `supplements/02_INTERNAL_REASONING_SUPPLEMENT.md` | routed evidence |
| Evidence inputs | `CAM_CLAIM_100_SCORE_AUDIT.md`, `NSIT_TOOL_CLOSURE_MATRIX.md`, `NSIT_REASONED_CLOSURE_PASS.md`, `PAPER_REWORKS_CRYSTAL_PROJECTION.json` | routed evidence |
| CAM/crystal sources | `PAPER_REWORKS_CRYSTAL_PROJECTION.json`, `AGENT_CRYSTAL_WORK_HARVEST.json`, `runtime standards artifact`, `notebook-derived source bundle` | routed evidence |
| Standards-window inputs | `window_summary.json`, `node DBs`, `window DBs` | routed evidence |
| Receipts | external requirement | not attached in this source package |
| Validators | external requirement | not attached in this source package |

Standards-window, runtime, and notebook-derived artifacts are treated
as evidence-routing surfaces. They support source discovery, conformance
checking, and reapplication, but they do not replace citations, receipts,
normal-form derivations, calibration rows, or falsifiers.

### 11.5 Results Representation

The paper's results section is organized around five publication objects:

1. the exact object acted on at this slot;
2. the admissible operation or transformation;
3. the receipt, enumeration, derivation, lookup, or external theorem supporting
   the operation;
4. the residue or boundary left after the result;
5. the downstream import rule.

### 11.6 Figures And Tables

| Figure | Role |
|---|---|
| FLCR-03-F1: Residual split diagram | Visualizes the proof object, routing, or boundary. |
| FLCR-03-F2: Evidence routing map | Visualizes the proof object, routing, or boundary. |
| FLCR-03-F3: Same-family lift context | Visualizes the proof object, routing, or boundary. |

| Table | Role |
|---|---|
| FLCR-03-T1: Residual accounting table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-03-T2: Claim-lane/evidence-boundary table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-03-T3: Archive evidence card and source-backed upgrade table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-03-T4: Workbook replay and falsifier table | Records claim lanes, evidence, sources, or falsifiers. |

### 11.7 Limits And Falsifiers

The paper proves only the object and domain declared in its claim ledger.
Physical, Standard Model, observer, calibration, or synthesis claims require
the additional lane evidence stated by their destination papers. CAM/crystal
and forge language is operational only when represented as an address, lookup,
receipt, validator, or reapplication path.
