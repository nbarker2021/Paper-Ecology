﻿# FLCR-36 - Condensed Matter, Materials, And Metamaterials

**Series:** Formalizing LCR, Unifying Standard Models  
**Artifact:** formal paper source  
**Status:** first-pass rich rewrite; requires final citation and build pass.  
**Claim posture:** maximal local claim posture with explicit lane boundaries.

## Abstract

This paper formalizes condensed-matter/materials translation of forge candidates and exciton accounting. The operative object is materials translation. The core result is that forge-generated material candidates can be translated into condensed-matter hypotheses when descriptors, band context, and validation lane are attached. The paper also defines how this result routes forward: FLCR-36 ties FLCR-21, FLCR-34, and external materials data into one validation map. Its main residue is explicit: fabrication, finite-element performance, spectroscopy, and device claims remain empirical.

## Keywords

materials translation; LCR; receipt; claim lane; normal form.

## 1. Contribution And Scope

- Defines materials translation as a first-class FLCR object.
- States the local result: forge-generated material candidates can be translated into condensed-matter hypotheses when descriptors, band context, and validation lane are attached.
- Routes downstream use through claim lanes rather than inherited prose: FLCR-36 ties FLCR-21, FLCR-34, and external materials data into one validation map.
- Preserves the residue boundary: fabrication, finite-element performance, spectroscopy, and device claims remain empirical.

This paper is part of the LCR-native base layer. Standard Model or physical
language is permitted only as deferred mapping, analogy, or explicitly bounded
future calibration. The editable surface is the claim lane and source-routing
layer; the base objects must remain stable enough for downstream papers to
consume them without ambiguity.

## 2. Source Routing

Primary routed sources:

- `22_MetaForge_Applied_Materials.md`
- `supplements/METAFORGE_MATERIALS_SUPPLEMENT.md`
- `NP-12_Electron_Hole_Exciton_Accounting_For_Open_Math.md`

Cross-corpus evidence classes:

- `CAM_CLAIM_100_SCORE_AUDIT.md`
- `NSIT_TOOL_CLOSURE_MATRIX.md`
- `NSIT_REASONED_CLOSURE_PASS.md`
- `PAPER_REWORKS_CRYSTAL_PROJECTION.json`
- standards, glue, window, and node databases where applicable
- notebook-derived review prompts and orbital source manifests

## 3. Definitions

- **Material hypothesis.** A candidate plus descriptor, predicted mechanism, and validation lane.
- **Spectroscopy boundary.** The external measurement lane for material electronic claims.
- **Receipt boundary.** The exact scope in which the paper's result can be replayed or consumed.
- **Promotion route.** The evidence path required before a stronger downstream claim can use this result.

## 4. Formal Claims

| Claim | Lane | Statement |
|-------|------|-----------|
| Theorem 36.1 | `external_calibration_result` | forge-generated material candidates can be translated into condensed-matter hypotheses when descriptors, band context, and validation lane are attached |
| Proposition 36.2 | `normal_form_result` | materials translation can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 36.3 | `falsifier_or_open_obligation` | fabrication, finite-element performance, spectroscopy, and device claims remain empirical |

## 5. Paper-Specific Development

1. Identify the local object and its assigned sources for FLCR-36.
2. Separate what is internally receipt-bound from what is citation-bound, CAM-bound, calibration-bound, or still an obligation.
3. State the strongest admissible claim in its current lane.
4. Export only the lane-safe result to downstream papers and preserve the residue.

### Proof Sketch

The proof strategy for FLCR-36 is a typed construction argument. The paper names material hypothesis as the active object, binds it to the routed legacy and orbital sources, and then allows downstream use only through the declared claim lane. This does not erase stronger ambitions; it keeps them addressable as dependencies, calibration tasks, or falsifiers.

## 6. Construction

The construction is intentionally staged. First, the paper names the finite or
typed object that can be inspected directly. Second, it declares the admissible
operations over that object. Third, it records the receipt or source class that
allows another paper to consume the result. Fourth, it names the residue that
must not be silently promoted.

For this paper, the operative object is `Condensed Matter, Materials, And Metamaterials`. Its safe consumption
rule is:

```text
source object -> declared operation -> receipt/lane -> downstream import
```

The unsafe consumption rule is:

```text
source phrase -> downstream identity claim
```

That second pattern is explicitly rejected by FLCR-01 and must be rewritten as
a claim-lane promotion with evidence.

## 7. Evidence And Receipts

| Evidence source | What it contributes |
|-----------------|---------------------|
| Legacy paper body | Primary formal and source-integration material assigned by the series map. |
| Internal and pyramid supplements | Cross-paper reasoning windows, deferred back-application slots, and route constraints. |
| NSIT tool closure matrix | Existing verifier/tool families that can close internal or batch claims. |
| CAM/crystal and standards-window evidence | Projected memory, source routing, standards reports, and window/node databases. |

### Standard Model Definition Dependencies

This paper consumes the dedicated Standard Model Defining layer. These papers define the external Standard Model or adjacent standard-physics object before this FLCR paper translates it into LCR language.

| SMD paper | Definition surface | Required use |
|---|---|---|
| `SMD-01` | Standard Model Definition Contract And Evidence Boundary | Definition surface that must be cited before this paper promotes the corresponding Standard Model-facing claim. |
| `SMD-10` | Electron Hole Exciton And Condensed Matter Correspondence | Definition surface that must be cited before this paper promotes the corresponding Standard Model-facing claim. |
| `SMD-11` | GR Continuum Interface And Units-Bearing Calibration | Definition surface that must be cited before this paper promotes the corresponding Standard Model-facing claim. |
| `SMD-12` | Standard Model Comparator And Falsifier Protocol | Definition surface that must be cited before this paper promotes the corresponding Standard Model-facing claim. |

This paper also imports SMB-01, the Standard Model Closure Bridge. SMB-01 supplies the closure-by-lane rule: rows are no longer treated as unresolved by default; they are closed when standard formalism, FLCR proof, CAM/crystal reapplication, normal-form translation, or external calibration satisfies the lane, and they remain obligations only when a required field is missing.

### Closed Rows Applied In This Paper

| Row | Closure | Evidence | Boundary |
|---|---|---|---|
| Materials candidate generation as descriptor workflow | closed internally at forge-reader scope | `FLCR-20`, `FLCR-21` | Closes descriptor/routing behavior, not material performance. |
| Electron-hole/exciton material vocabulary | closed by standard formalism | `SMD-10` | Closes model vocabulary for semiconductor-like rows. |
| Quantitative material claim | not closed here | `SMD-10`, `SMD-11` | Requires material parameters, units, and measured/simulated data. |

This paper should now separate we can generate and route material descriptors from we have proven a material has a measured property. The first is a closed FLCR workflow row. The second is a calibration row.

### Active Comparator Rows

| Comparator | External side | LCR side | Current result | Next required action |
|---|---|---|---|---|
| Descriptor generation | material feature/model fields | forge descriptor/kernel rows | internally closed | Add domain-specific schema for each material family. |
| Exciton/material behavior | band/exciton model | vacancy/residue bridge | formalism available | Add material constants and model assumptions. |
| Metamaterial performance | measured/simulated response | generated descriptor | calibration-bound | Attach dataset or simulator receipt. |

### Executable Evidence Bound In This Pass

This paper now binds the materials/metamaterials layer to a real MetaForge receipt and to the electron-hole-exciton definition surface. The result is stronger than a text analogy: the candidate-generation workflow is receipt-backed, while physical material validation remains explicitly open.

| Evidence | Path | Result imported here | Boundary preserved |
|---|---|---|---|
| MetaForge materials receipt | `local evidence artifact` | `pass_with_open_obligations`; closes a replayable candidate-generation ledger for material inventory, Pareto partner selection, ten-fold evaluation, seam proposal, production accounting, and additional material-pair replay. | Finite-element validation, fabrication/load testing, manufacturability constraints, and measured property validation remain open. |
| Graphene/hBN candidate row | same receipt | Top partner hBN, Pareto score 0.89, ten-fold candidate receipt, seam candidates, and positive bounded production accounting. | Candidate estimates are not measured material properties. |
| Electron-hole-exciton definition surface | `SMD-10` | Supplies the standard quasiparticle vocabulary needed for material and condensed-matter translation rows. | Binding/recombination/transport values require material parameters and data. |

The upgraded claim is: FLCR-36 can state that the materials reader/generator is operationally closed for candidate ledgers. It cannot claim fabricated metamaterial performance or measured condensed-matter behavior until external validation rows are attached.

### Online Source Rows Applied In This Pass

| Online source | Claim-lane effect | Boundary retained |
|---|---|---|
| `IRL-EXCITON-2D-REVIEW` | Supplies condensed-matter exciton formalism for 2D/material systems. | Does not validate any generated MetaForge material. |
| `IRL-NIST-CARRIER-DYNAMICS` | Supplies experimental carrier/exciton metrology context. | Requires material-specific measurement. |
| `IRL-NIST-PV-EXCITON` | Supplies heterojunction exciton-separation context for materials claims. | Candidate materials remain candidates until fabrication/simulation/test rows close. |

Online data therefore lets FLCR-36 cite real materials/exciton measurement lanes while preserving the MetaForge receipt boundary: generation is closed; measured performance is not.

### Assertive Closure Promotions

| Row | Closure now allowed | Evidence | Residue moved out of the open row |
|---|---|---|---|
| Materials candidate generation | closed as replayable ledger | `metaforge_materials_receipt.json` | Fabrication/load-test/finite-element validation. |
| Condensed-matter exciton source lane | closed by standard formalism and NIST metrology sources | `SMD-10`, exciton/NIST sources | Material-specific values. |
| Graphene/hBN candidate row | closed as candidate output | MetaForge receipt | Measured material property claim. |

The non-timid conclusion is: FLCR-36 has a working materials candidate engine and real condensed-matter source lanes. It should stop presenting candidate generation as open and reserve validation for experiments/simulations.

## 8. Dependencies And Downstream Use

This paper may be imported by later FLCR papers only through the claim lanes
above. The default downstream consumers are:

- `FLCR-11` through `FLCR-18` for window, receipt, admission, CA, algebraic,
  curvature, residue, and exceptional machinery.
- `FLCR-28` through `FLCR-30` for CAM/crystal, corpus ribbon, and universal
  normal-form intake.
- `FLCR-31` through `FLCR-40` only after the LCR-native result has been cited
  and the translation claim has its own evidence lane.

## 9. Limitations And Falsifiers

- fabrication, finite-element performance, spectroscopy, and device claims remain empirical
- External calibration claims require units, datasets, citations, and reproducible data binding.
- A later translation paper may strengthen this result only by adding the missing lane evidence.

A falsifier for this paper is any example that satisfies the declared input
conditions while violating the stated construction, receipt, or lane boundary.
An interpretation that merely wants a stronger downstream conclusion is not a
falsifier; it is an obligation routed to a later paper.

## 10. Publication Readiness Tasks

- Validator identities and receipt hashes are recorded in the manifest or receipt appendix.
- External theorems require final citation entries before journal submission.
- Every theorem, proposition, and protocol must retain a claim lane and evidence boundary.
- The Markdown, LaTeX, and PDF forms are generated from the same canonical source.

## Dual Positioning: Story And Formal Carrier

This paper must be read in two synchronized ways. Sequentially, it explains why
the next state exists in the corpus story. Formally, it binds that state to
accepted mathematics, IRL formalism, code receipts, validators, CAM/crystal
lookups, and claim-lane boundaries.

Assigned original ribbon role(s): `22`/residual_action.

| Original slot | Family | Lift | Role | Proof form |
|---|---|---:|---|---|
| `22` | residual_action | 2 | order-3 slot-2: mark the correction, residue, vacancy, or mismatch surface | residual accounting and bounded/unbounded split |

The formal obligation is to state the strongest valid claim available for this
paper without letting interpretation silently change the addressed object. Any
author interpretation belongs beside the formalism as a declared relabeling,
bridge, or analog, and must be accompanied by the evidence lane that makes the
claim consumable by later papers.

## State-Bound Proof Contract

This paper receives: state emitted by prior slot 21 and reopened at original slot 22 (MetaForge Applied Materials).

It must produce: formal result of original slot 22 plus the same-family lift path toward slot 32.

Semantic transition: measure the mismatch, residue, vacancy, correction surface, or remaining obligation after enumeration.

Accepted formalism targets to bind in the journal rewrite:

- residue classes and quotient accounting
- error-correction or syndrome notation
- truth tables and exhaustive finite checks
- bounded versus unbounded domain separation

| Slot | Family | Lift | Produced proof form |
|---|---|---:|---|
| `22` | residual_action | 2 | residual accounting and bounded/unbounded split |

The formal carrier uses these accepted tools while preserving interpretive
claims as explicit relabelings, correspondences, or bridges. Claim promotion is admissible only when a receipt, standard citation,
CAM/crystal reapplication, normal-form result, calibration datum, or falsifier
boundary is attached.

## Provenance And Crystal Evidence Integration

This section integrates prior work, CAM/crystal projections, NSIT tooling,
standards-window evidence, and routed supplements as provenance-bearing
evidence. Source material is not treated as manuscript text; it is bound into
the paper only through claim lanes, receipts, validators, normal forms,
calibration rows, or explicit falsifier boundaries.

### Expansion Rule For This Slot

Use past work to split closed core from residue: correction tables, mismatch rows, open obligations, and bounded/unbounded domains must remain separate.

### Primary Evidence Inputs

| Source | Placement reason |
|---|---|
| `22_MetaForge_Applied_Materials.md` | primary assigned source for the paper's formal spine |
| `supplements/22_INTERNAL_REASONING_SUPPLEMENT.md` | paper-local reasoning supplement contributing to definitions, proof sketch, and limitations |
| `virtuous\22_MetaForge_Applied_Materials_VIRTUOUS.md` | prior enriched paper body; should be mined for mature claims and proof ordering |

### Secondary And Orbital Evidence Inputs

| Source | Placement reason |
|---|---|
| `supplements/SM_BRIDGE_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/METAFORGE_MATERIALS_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/SPECTRE_TILING_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/RECEIPT_VERIFIER_CATALOG.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/APPLIED_FORGES_WORKBOOK.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_PYRAMID_INDEX.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_5P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_7P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_9P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `CAM_CLAIM_100_SCORE_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_TOOL_CLOSURE_MATRIX.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_REASONED_CLOSURE_PASS.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| Additional source routes | Complete routing is maintained in the source-placement appendix |

### Crystal And Standards Evidence To Bind

- Paper Reworks crystal projection: 33 paper markdown files, 9 supplements, 5 queues, 6 lattice-forge unification artifacts, 140 faces, 140 vignettes, and 280 CAM nodes.
- Standards-window intake: 192/192 corpus conformance verdicts PASS; 140/142 obligations have candidate routes; 2/4/8/16/32 window lattice is available for cross-paper reads.
- Agent/crystal harvest: agent-generated memory, runtime standards starter, current runtime build, repo-harvest CAM, notebook-derived bundles, and downloaded crystal payloads are orbital evidence surfaces.
- NSIT inventory baseline: 220 validators, 1786 receipt/data artifacts, 1137 formal-paper-like artifacts, 114 supplements, and 86 memory/CAM artifacts.

### Paper-Specific CAM/Score Rows

| 22 | 82 | applied forge closeable | MetaForge materials, material-ledger routes, TMD/interlayer exciton candidate, applied forge supplement | finite-element/fabrication/material measurement datasets |

### Paper-Specific NSIT Closure Rows

No direct NSIT row matched the assigned legacy papers in the first-pass matrix; validator matching by object name remains a receipt-attachment requirement.

### Source Integration Summary

The legacy source and internal reasoning supplement are treated as source
evidence rather than manuscript prose. Their contributions enter this paper as
claim-lane entries, receipt or validator references, finite-domain statements,
and limitation boundaries. Speculative or cross-domain interpretations remain
separate from closed local results until an explicit adapter, citation,
normal-form derivation, calibration row, or falsifier is attached.
## Claim Binding Queue

This queue records the evidence discipline for claim strengthening. It separates claims that already have support from residues that remain in falsifier or open-obligation lanes.

| Queue | Lane | Promote now | Bind next | Residue |
|---|---|---|---|---|
| Symbolic Carrier Versus Physical Carrier | `external_calibration_result` | Promote addressable symbolic-carrier and transport claims where the paper names carrier, path, residue, or traversal rules. | Map every physical carrier phrase to a standard physics object, Hamiltonian/model, dataset, or calibration route before treating it as measured physics. | Physical identity, units, material constants, and measured transport remain calibration-bound. |
| Electron-Hole-Exciton Standard Accounting | `standard_theorem_citation_bound_result` | Treat hole, vacancy, exciton, recombination, screening, band-gap, and effective-mass language as standard-model correspondence when a material model is present. | Attach standard equations/citations and state what LCR adds: addressability, obligation routing, and residue bookkeeping. | Actual material behavior and quantitative exciton claims need a material model, units, and data. |
| Applied Forge Internal/External Validation Split | `receipt_bound_internal_result` | Promote internal forge reader, descriptor, candidate-generation, and finite validation kernels when validators pass. | Attach forge tool path, input object, output descriptor/candidate, validator result, and explicit external-validation boundary. | Wet-lab, fabrication, biological, gameplay-global, or real-world optimization claims remain external-validation needs. |

### Binding Discipline

Each queue item is represented as a delta:

```text
local claim at paper time
-> attached later source/tool/receipt/theorem
-> revised representation
-> invariant boundary and remaining residue
```

This preserves the sequential story while allowing later tools, crystals, and
standard formalisms to return through the proper lane.

## Claim Delta Ledger

This ledger applies the paper's claim-binding queues as explicit back-application
deltas. It keeps the sequential paper story intact while allowing later
receipts, standard formalisms, CAM/crystal routes, and validators to sharpen the
claim.

| Delta | Local claim at paper time | Later evidence | Revised representation | Boundary kept |
|---|---|---|---|---|
| Symbolic Vs Physical Carrier | This paper may use carrier language for addressable symbolic transport inside the LCR/CAM system. | Standard physics carrier terminology, local verifier receipts, material/plasma/transport supplements, and calibration routes. | Split symbolic carrier closure from measured physical carrier identity. | Physical identity, units, Hamiltonians, datasets, and measured constants remain external-calibration claims. |
| Electron Hole Exciton Accounting | Vacancy, complement, hole, residue, and excitation language may appear as LCR addressability/residue vocabulary. | Standard electron-hole-exciton formalism, material-model rows, band-gap/screening/recombination equations, and NP-12 routing. | Treat hole/exciton vocabulary as standard correspondence where a material model exists, while preserving LCR's contribution as addressability and obligation bookkeeping. | Quantitative material behavior requires model parameters, units, citations, and data. |
| Applied Forge Internal External Split | This paper may claim an internal forge reader/generator/descriptor kernel where the tool produces replayable internal outputs. | Forge validators, applied-forge workbooks, material/protein/game receipts, CAM addresses, and source-routing rows. | Promote internal representation/generation kernels when validators pass, while routing real-world validation separately. | Fabrication, wet-lab, biological, gameplay-global, manufacturing, or measured optimization claims remain external-validation needs. |

The revised representation records the strongest claim supported by the current evidence package. Promotion into theorem or proposition language occurs only when the named evidence is attached in the manifest or workbook replay.

## Source-Backed Evidence Summary

Routed archive and mirror cards are treated as provenance summaries rather than
body text. They identify candidate receipts, validators, theorem registries, or
supplemental source routes. A card strengthens this paper only when its
contribution is bound to a claim lane, evidence object, and boundary.

| Evidence card | Score | Publication contribution | Boundary |
|---|---:|---|---|
| CQE-paper-22.50: Paper 22.50 - MetaForge Claim Contract | 97 | A Paper 22 claim is admitted only when it is framed as a materials candidate unless simulation, fabrication, and measurement receipts are attached. A candidate must include material-source rows, partner-selection scor... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| CQE-paper-22: Paper 22 - MetaForge Applied Materials | 97 | Paper 22 moves the Forge family into applied materials. Its closed result is a replayable candidate-generation ledger: a finite material database is searched for Pareto partners, a selected pair is run through a deter... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| CQE-paper-22.25: Paper 22.25 - MetaForge Toolkit Supplement | 93 | This supplement describes how to run and inspect the MetaForge materials pipeline. It supports Paper 22 but does not replace its proof. Run: `python production/formal-papers/CQE-paper-22/verify_metaforge_materials.py`... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| FORMAL: Paper 23 — C-Form: FoldForge Protein Folding Gluon | 89 | **C = the protein fold Gluon** — the contact-map/topo Gluon that transports protein chain fold hypotheses through contact-map and topology receipts. In the lattice_forge substrate, C is realized as the **fold Gluon** ... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| FORMAL: Paper 22 — C-Form: MetaForge Applied Materials Gluon | 85 | **C = the material Gluon** — the applied materials Gluon that transports the morphic Gluon (Paper 21) into physical material candidates. In the lattice_forge substrate, C is realized as the **material Gluon** that: - ... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| Additional evidence cards | 25 total | The complete card inventory is maintained in the archive evidence matrix. | Cards are source-discovery aids until bound to paper-local evidence. |

## Journal Apparatus

### Article Type And Intended Venue Fit

This manuscript is written as a formal-methods and mathematical-systems paper
inside the series *Formalizing LCR, Unifying Standard Models*. Its intended
reader is a technical reviewer who needs claim boundaries, reproducibility
routes, and cross-paper dependencies to be visible without relying on private
context.

### Structured Contribution Statement

| Item | Statement |
|---|---|
| Publication ID | `FLCR-36` |
| Legacy source slot(s) | `22` |
| Ribbon role | order-3 slot-2: mark the correction, residue, vacancy, or mismatch surface |
| Proof form | residual accounting and bounded/unbounded split |
| Received state | state emitted by prior slot 21 and reopened at original slot 22 (MetaForge Applied Materials) |
| Produced state | formal result of original slot 22 plus the same-family lift path toward slot 32 |

### Claim-Evidence Table

| Claim | Lane | Evidence to attach | Boundary |
|---|---|---|---|
| Theorem 36.1 | `external_calibration_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | forge-generated material candidates can be translated into condensed-matter hypotheses when descriptors, band context, and validation lane are attached |
| Proposition 36.2 | `normal_form_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | materials translation can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 36.3 | `falsifier_or_open_obligation` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | fabrication, finite-element performance, spectroscopy, and device claims remain empirical |

### Figure Plan

| Figure | Purpose | Caption |
|---|---|---|
| FLCR-36-F1 | Residual split diagram | Schematic showing how `FLCR-36` turns its received state into the produced state while preserving claim lanes and residue boundaries. |
| FLCR-36-F2 | Evidence routing map | Diagram of source papers, archive cards, CAM/crystal routes, validators, and workbook replay paths used by this manuscript. |
| FLCR-36-F3 | Same-family lift context | Diagram placing this paper in the original `00-79` ribbon family and showing predecessor/successor slots. |

### In-Text Figure FLCR-36-F1: Residual split diagram

```text
received state
  -> Residual split diagram
  -> formal claim lane
  -> evidence object / receipt / citation
  -> produced state
  -> remaining residue
```

### Table Plan

| Table | Purpose |
|---|---|
| FLCR-36-T1 | Residual accounting table |
| FLCR-36-T2 | Claim-lane/evidence-boundary table |
| FLCR-36-T3 | Archive evidence card and source-backed upgrade table |
| FLCR-36-T4 | Workbook replay and falsifier table |

### Worked Example

Split one claim into closed core, residue, bounded domain, and unbounded burden. The example must name the input object, the operation,
the evidence object, the allowed revised claim, and the remaining boundary.

### Nomenclature And Glossary

| Term | Paper-local meaning |
|---|---|
| CAM | Defined by this paper as part of the `residual_action` proof role; final definition is recorded in the paper-local glossary. |
| bounded domain | Defined by this paper as part of the `residual_action` proof role; final definition is recorded in the paper-local glossary. |
| claim lane | Defined by this paper as part of the `residual_action` proof role; final definition is recorded in the paper-local glossary. |
| correction surface | Defined by this paper as part of the `residual_action` proof role; final definition is recorded in the paper-local glossary. |
| crystal | Defined by this paper as part of the `residual_action` proof role; final definition is recorded in the paper-local glossary. |
| receipt | Defined by this paper as part of the `residual_action` proof role; final definition is recorded in the paper-local glossary. |
| residue | Defined by this paper as part of the `residual_action` proof role; final definition is recorded in the paper-local glossary. |
| unbounded burden | Defined by this paper as part of the `residual_action` proof role; final definition is recorded in the paper-local glossary. |

### Appendix FLCR-36-A: Evidence Package

The appendix records:

1. Legacy source excerpts or source-card references used in the final claim ledger.
2. Receipt and verifier paths, including pass/fail/partial status.
3. CAM/crystal query or projection rows used by the paper, with source identity and boundary.
4. Standards-window and NSIT evidence used for conformance or routing.
5. Falsifier, calibration, or external-data rows that remain unresolved.

### Data And Code Availability

The publication package contains the canonical Markdown sources, manifests, source-routing matrices, validation reports, and generated PDF/TeX outputs.

Code and verifier references are cited through manifests, archive evidence cards, receipt catalogs, or workbook replay tables. External datasets or
standards citations must be attached before any calibration-bound claim is
promoted.

### Reviewer Checklist

| Check | Reviewer question |
|---|---|
| Claim lane | Does every strong claim declare its lane and evidence type? |
| Boundary | Does the paper preserve what it does not prove? |
| Reproducibility | Is there a receipt, verifier, source card, citation, or replay table for the claim? |
| Cross-paper import | Does the paper cite the prior FLCR/OPR slot before consuming its result? |
| Interpretation | Does the analog layer preserve the addressed state while changing labels/access paths? |

### Declarations

No human-subjects, clinical, or animal-research protocol is asserted by this
paper. External empirical claims require separate dataset, calibration, or
domain-validation attachments. Competing-interest and funding statements are recorded in the submission metadata.

## 11. Publication Integration Addendum

### 11.1 Role In The Series

`FLCR-36` (`Condensed Matter, Materials, And Metamaterials`) occupies the `residual_action` role at lift depth `2`.
The paper receives state emitted by prior slot 21 and reopened at original slot 22 (MetaForge Applied Materials). It produces formal result of original slot 22 plus the same-family lift path toward slot 32. The state transition is:
measure the mismatch, residue, vacancy, correction surface, or remaining obligation after enumeration.

The paper-local proof form is:

```text
residual accounting and bounded/unbounded split
```

The integration result is a bounded residual object separated from its downstream repair obligations. This addendum records how that result is
consumed by the publication series without relying on editorial instructions or
private working context.

### 11.2 Formal Carrier

| Formal carrier | Function |
|---|---|
| residue classes and quotient accounting | Formal carrier for the paper-local result. |
| error-correction or syndrome notation | Formal carrier for the paper-local result. |
| truth tables and exhaustive finite checks | Formal carrier for the paper-local result. |
| bounded versus unbounded domain separation | Formal carrier for the paper-local result. |

The LCR, CAM, crystal, forge, and analog vocabulary functions as a typed access
layer over these carriers. A relabeling is admissible only when the addressed
object, evidence lane, boundary, and downstream import rule remain attached.

### 11.3 Claim Ledger

| Claim | Lane | Statement |
|---|---|---|
| Theorem 36.1 | `external_calibration_result` | forge-generated material candidates can be translated into condensed-matter hypotheses when descriptors, band context, and validation lane are attached |
| Proposition 36.2 | `normal_form_result` | materials translation can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 36.3 | `falsifier_or_open_obligation` | fabrication, finite-element performance, spectroscopy, and device claims remain empirical |

These claims are consumed at their stated lane. A stronger downstream statement
creates a new claim envelope with its own evidence object.

### 11.4 Evidence Package

| Evidence class | Routed items | Status |
|---|---|---|
| Legacy sources | `22_MetaForge_Applied_Materials.md`, `supplements/METAFORGE_MATERIALS_SUPPLEMENT.md`, `NP-12_Electron_Hole_Exciton_Accounting_For_Open_Math.md` | routed evidence |
| Evidence inputs | `CAM_CLAIM_100_SCORE_AUDIT.md`, `NSIT_TOOL_CLOSURE_MATRIX.md`, `NSIT_REASONED_CLOSURE_PASS.md`, `PAPER_REWORKS_CRYSTAL_PROJECTION.json` | routed evidence |
| CAM/crystal sources | `PAPER_REWORKS_CRYSTAL_PROJECTION.json`, `AGENT_CRYSTAL_WORK_HARVEST.json`, `runtime standards artifact`, `notebook-derived source bundle` | routed evidence |
| Standards-window inputs | `window_summary.json`, `node DBs`, `window DBs` | routed evidence |
| Receipts | external requirement | not attached in this source package |
| Validators | external requirement | not attached in this source package |

Standards-window, runtime, and notebook-derived artifacts are treated
as evidence-routing surfaces. They support source discovery, conformance
checking, and reapplication, but they do not replace citations, receipts,
normal-form derivations, calibration rows, or falsifiers.

### 11.5 Results Representation

The paper's results section is organized around five publication objects:

1. the exact object acted on at this slot;
2. the admissible operation or transformation;
3. the receipt, enumeration, derivation, lookup, or external theorem supporting
   the operation;
4. the residue or boundary left after the result;
5. the downstream import rule.

### 11.6 Figures And Tables

| Figure | Role |
|---|---|
| FLCR-36-F1: Residual split diagram | Visualizes the proof object, routing, or boundary. |
| FLCR-36-F2: Evidence routing map | Visualizes the proof object, routing, or boundary. |
| FLCR-36-F3: Same-family lift context | Visualizes the proof object, routing, or boundary. |

| Table | Role |
|---|---|
| FLCR-36-T1: Residual accounting table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-36-T2: Claim-lane/evidence-boundary table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-36-T3: Archive evidence card and source-backed upgrade table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-36-T4: Workbook replay and falsifier table | Records claim lanes, evidence, sources, or falsifiers. |

### 11.7 Limits And Falsifiers

The paper proves only the object and domain declared in its claim ledger.
Physical, Standard Model, observer, calibration, or synthesis claims require
the additional lane evidence stated by their destination papers. CAM/crystal
and forge language is operational only when represented as an address, lookup,
receipt, validator, or reapplication path.
