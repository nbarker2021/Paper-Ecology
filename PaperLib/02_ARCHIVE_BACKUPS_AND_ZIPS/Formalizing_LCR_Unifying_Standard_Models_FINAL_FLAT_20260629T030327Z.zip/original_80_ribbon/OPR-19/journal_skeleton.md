# OPR-19 - Observer Face Selection

**Publication layer:** original 80-ribbon paper draft  
**Status:** source_backed  
**Source file:** `19_Observer_Face_Selection.md`  
**Linked FLCR papers:** `FLCR-18`, `FLCR-38`  
**Family:** `window_action`  
**Lift depth:** 1  
**Same-family predecessor:** `09`  
**Same-family successor:** `29`  
**Required proof form:** window count, source preservation, and meta-ribbon proof

## Abstract

This paper develops original ribbon slot `19` as a `window_action` paper at lift
depth `1`. Its task is to read a completed window, expose its meta-state, and declare the prestate for the next lift. The paper is
both a sequential semantic explainer and a formal proof carrier: it explains
why this state occurs here in the ribbon, and it binds that explanation to
accepted formalism, receipts, CAM/crystal routes, claim lanes, analog replay,
and falsifier boundaries.

## Contribution

The paper contributes the following local result:

```text
The window readout is valid when it preserves the sources, closures, residues, and next-prestate assignments of the window it summarizes.
```

This result must be stated maximally but typed correctly. If the slot is
source-backed, the source should be rewritten into journal form. If the slot is
expansion-needed, the result should be staged as a proof obligation whose
evidence can be assembled from same-family predecessors, linked FLCR papers,
validators, CAM/crystal memory, and analog replay.

## Source And Routing Status

This slot is source-backed by `19_Observer_Face_Selection.md`. The rewrite task is to extract the theorem, method, evidence rows, and limitations from that source rather than treating the source as a quote dump.

| Routing item | Current assignment |
|---|---|
| Original slot | `19` |
| Slot family | `window_action` |
| Lift depth | `1` |
| Same-family predecessor | `09` |
| Same-family successor | `29` |
| Linked FLCR papers | `FLCR-18`, `FLCR-38` |
| Required proof form | window count, source preservation, and meta-ribbon proof |

## Formal Object

The formal object is the state emitted into slot `19` after the previous
ribbon step and after the same-family predecessor `09`. The paper must name
that object with enough precision that another paper can import it without
guessing whether the object is a theorem, receipt, analogy, calibration row, or
open obligation.

Minimum object envelope:

```text
O_19 = (incoming_state, slot_family, lift_depth, operation,
           evidence_lane, produced_state, residue, downstream_import_rule)
```

For this paper the operation is:

```text
Summarize closed rows, open rows, carry-forward lanes, and next-lift expectations without changing local claim status.
```

## Accepted Formalism

| Formal carrier | Role in the paper |
|---|---|
| windowed readouts | Use as accepted formal carrier for this slot. |
| meta-ribbon summaries | Use as accepted formal carrier for this slot. |
| source preservation | Use as accepted formal carrier for this slot. |
| prestate declaration | Use as accepted formal carrier for this slot. |

These accepted tools are the review-facing carrier. LCR/CAM/crystal language
may relabel, route, or query the object, but it must not change the addressed
state without an adapter receipt.

## Methods

1. Define the incoming state and same-family lift context.
2. Apply the slot-family operation: Summarize closed rows, open rows, carry-forward lanes, and next-lift expectations without changing local claim status.
3. Bind each strong claim to a lane: receipt-bound, citation-bound,
   CAM/crystal reapplication, normal-form, calibration, synthesis dependency,
   or falsifier/open obligation.
4. Record the produced state and residue as separate outputs.
5. Export a downstream import rule for the next paper and the same-family
   successor.

## Results To Prove

| Result | Lane | Evidence needed |
|---|---|---|
| Slot-local theorem | `normal_form_result` or `receipt_bound_internal_result` | Exact source theorem, verifier, enumeration, derivation, or adapter. |
| Same-family lift theorem | `normal_form_result` | Evidence that the prior same-family slot can be lifted without identity loss. |
| Residue route | `falsifier_or_open_obligation` | Explicit unresolved channel, dependency, or calibration need. |
| Downstream import rule | `normal_form_result` | Claim envelope stating what the next slot may consume. |

## Figures And Tables

| Artifact | Purpose |
|---|---|
| OPR-19-F1 | Show the slot-local proof object and same-family lift context. |
| OPR-19-F2 | Show source routing from FLCR, CAM/crystal, validators, and analog workbook material. |
| OPR-19-T1 | List claims, lanes, evidence objects, and boundaries. |
| OPR-19-T2 | List predecessor/successor obligations and downstream import permissions. |

## Analog Workbook Route

Analog replay: Use a window board: all cards in the window remain visible while the next board receives only the declared summary state.

The analog route must demonstrate label preservation. The reader should be able
to change language, medium, or access path while preserving the addressed state.
The workbook must therefore answer:

| Check | Required answer |
|---|---|
| Addressed state | What object remains invariant? |
| Relabeling | Which label, analogy, coordinate, or access route changes? |
| Evidence lane | Which lane permits that change? |
| Import boundary | What may the next paper consume? |

## Falsifiers And Open Channels

A falsifier is any case that satisfies the incoming-state and slot-family
conditions while breaking the stated operation, evidence lane, produced state,
or downstream import rule. A missing receipt, missing source, or missing
calibration is not automatically a disproof; it is an open channel that must be
named and routed.

Open channels for this slot:

- Attach exact source paragraphs, verifier paths, hashes, or CAM/crystal query
  routes.
- Decide whether the strongest claim is local proof, standard-theorem
  correspondence, normal-form lift, calibration-bound physical claim, or
  synthesis dependency.
- Convert any remaining metaphor into a declared relabeling or adapter.

## Downstream Import Rule

The next ribbon paper may import only the produced state and boundary declared
here. The same-family successor `29` may import the lift relation only after
the local result and residue have been separated. If a later paper needs a
stronger interpretation, it must attach a new evidence object rather than
silently upgrading this slot.
