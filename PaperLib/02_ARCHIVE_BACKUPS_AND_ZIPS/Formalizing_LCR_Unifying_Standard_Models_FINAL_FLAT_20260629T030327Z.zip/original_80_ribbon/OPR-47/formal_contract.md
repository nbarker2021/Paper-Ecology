# Formal Contract - OPR-47

## Formal Carrier

This slot uses `bridge_action` at lift depth `4` to produce the following proof
form:

```text
bridge, projection, calibration, or sample-preservation proof
```

The accepted carrier is the combination of source-backed definitions,
same-family lift relations, claim-lane envelopes, receipts or validators, and
explicit residue routing.

## Dimensional Role

order-5 slot-7: project between discrete, continuous, lattice, or physical-facing forms

## Source Status

Source file: `expansion required from same-family lift logic`
