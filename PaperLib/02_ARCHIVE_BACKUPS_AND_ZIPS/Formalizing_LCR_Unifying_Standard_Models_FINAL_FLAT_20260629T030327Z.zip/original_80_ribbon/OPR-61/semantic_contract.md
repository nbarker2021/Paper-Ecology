# Semantic Contract - OPR-61

## State Transition

`Enumeration Action At Lift 6` explains why the ribbon needs a `enumeration_action` action at lift depth
`6`. The semantic layer connects the prior ribbon state to the produced
state while preserving the formal object named in the formal contract.

## Same-Family Context

Previous lift: `51`  
Next lift: `71`
