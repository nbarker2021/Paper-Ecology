# Semantic Contract - OPR-58

## State Transition

`Terminal Address Surface At Lift 5` explains why the ribbon needs a `terminal_action` action at lift depth
`5`. The semantic layer connects the prior ribbon state to the produced
state while preserving the formal object named in the formal contract.

## Same-Family Context

Previous lift: `48`  
Next lift: `68`
