# Export Validation Report

Export root: `D:\Paper Reworks\FINAL_PAPERS_FLCR_UNIFIED`
Papers in manifest: 40
PDFs exported: 40
Errors: 0

Unified export is complete.
