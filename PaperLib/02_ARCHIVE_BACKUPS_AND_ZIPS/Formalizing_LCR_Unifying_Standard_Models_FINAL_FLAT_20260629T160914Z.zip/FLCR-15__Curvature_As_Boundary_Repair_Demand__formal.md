# FLCR-15 - Curvature As Boundary-Repair Demand

**Series:** Formalizing LCR, Unifying Standard Models  
**Artifact:** formal paper source  
**Status:** first-pass rich rewrite; requires final citation and build pass.  
**Claim posture:** maximal local claim posture with explicit lane boundaries.

## Abstract

This paper formalizes curvature-like behavior as accumulated repair demand. The operative object is repair-curvature map. The core result is that boundary repair demand can be represented as a structured curvature-like ledger over discrete transitions. The paper also defines how this result routes forward: FLCR-35 may translate this into GR-facing language after preserving the repair-row evidence chain. Its main residue is explicit: Einstein-equation identity, measured curvature, and physical spacetime calibration remain downstream.

## Keywords

repair-curvature map; LCR; receipt; claim lane; normal form.

## 1. Contribution And Scope

- Defines repair-curvature map as a first-class FLCR object.
- States the local result: boundary repair demand can be represented as a structured curvature-like ledger over discrete transitions.
- Routes downstream use through claim lanes rather than inherited prose: FLCR-35 may translate this into GR-facing language after preserving the repair-row evidence chain.
- Preserves the residue boundary: Einstein-equation identity, measured curvature, and physical spacetime calibration remain downstream.

This paper is part of the LCR-native base layer. Standard Model or physical
language is permitted only as deferred mapping, analogy, or explicitly bounded
future calibration. The editable surface is the claim lane and source-routing
layer; the base objects must remain stable enough for downstream papers to
consume them without ambiguity.

## 2. Source Routing

Primary routed sources:

- `14_GR_Boundary_Repair_Curvature.md`
- `virtuous/14_GR_Boundary-Repair_Curvature_VIRTUOUS.md`
- `supplements/14_INTERNAL_REASONING_SUPPLEMENT.md`

Cross-corpus evidence classes:

- `CAM_CLAIM_100_SCORE_AUDIT.md`
- `NSIT_TOOL_CLOSURE_MATRIX.md`
- `NSIT_REASONED_CLOSURE_PASS.md`
- `PAPER_REWORKS_CRYSTAL_PROJECTION.json`
- standards, glue, window, and node databases where applicable
- notebook-derived review prompts and orbital source manifests

## 3. Definitions

- **Repair curvature.** A discrete accumulation of typed boundary repair demand.
- **Metric receipt.** A proposed downstream object binding repair data to a metric-style representation.
- **Receipt boundary.** The exact scope in which the paper's result can be replayed or consumed.
- **Promotion route.** The evidence path required before a stronger downstream claim can use this result.

## 4. Formal Claims

| Claim | Lane | Statement |
|-------|------|-----------|
| Theorem 15.1 | `receipt_bound_internal_result` | boundary repair demand can be represented as a structured curvature-like ledger over discrete transitions |
| Proposition 15.2 | `normal_form_result` | repair-curvature map can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 15.3 | `falsifier_or_open_obligation` | Einstein-equation identity, measured curvature, and physical spacetime calibration remain downstream |

## 5. Paper-Specific Development

1. Identify the local object and its assigned sources for FLCR-15.
2. Separate what is internally receipt-bound from what is citation-bound, CAM-bound, calibration-bound, or still an obligation.
3. State the strongest admissible claim in its current lane.
4. Export only the lane-safe result to downstream papers and preserve the residue.

### Proof Sketch

The proof strategy for FLCR-15 is a typed construction argument. The paper names repair curvature as the active object, binds it to the routed legacy and orbital sources, and then allows downstream use only through the declared claim lane. This does not erase stronger ambitions; it keeps them addressable as dependencies, calibration tasks, or falsifiers.

## 6. Construction

The construction is intentionally staged. First, the paper names the finite or
typed object that can be inspected directly. Second, it declares the admissible
operations over that object. Third, it records the receipt or source class that
allows another paper to consume the result. Fourth, it names the residue that
must not be silently promoted.

For this paper, the operative object is `Curvature As Boundary-Repair Demand`. Its safe consumption
rule is:

```text
source object -> declared operation -> receipt/lane -> downstream import
```

The unsafe consumption rule is:

```text
source phrase -> downstream identity claim
```

That second pattern is explicitly rejected by FLCR-01 and must be rewritten as
a claim-lane promotion with evidence.

## 7. Evidence And Receipts

| Evidence source | What it contributes |
|-----------------|---------------------|
| Legacy paper body | Primary formal and source-integration material assigned by the series map. |
| Internal and pyramid supplements | Cross-paper reasoning windows, deferred back-application slots, and route constraints. |
| NSIT tool closure matrix | Existing verifier/tool families that can close internal or batch claims. |
| CAM/crystal and standards-window evidence | Projected memory, source routing, standards reports, and window/node databases. |

## Resolved-State Closure Pass

This pass removes false restrictions on the paper's claim posture. A row is no longer called open merely because a stronger future claim exists. The satisfied lane is closed now; only the stronger claim that lacks its required adapter, comparator, calibration, or falsifier remains as residue.

### Closed Now

| Row | Lane | Resolved state | Remaining boundary |
|---|---|---|---|
| paper lift enumeration | `receipt_bound_internal_result` | 8/8 LCR states succeeded; error walls=0; avg TarPit mass=0.513979. | This closes the paper-local finite lift readout, not every stronger physical interpretation. |
| boundary repair | `normal_form_result` | The typed boundary repair surface is closed as an admission table for legal next-state repair. | The family closure is a structural lane; measured physics still requires destination-specific calibration. |
| decade-2 tower | `receipt_bound_internal_result` | The decade tower is resolved with avg TarPit mass=0.510236 and mass sum=40.818854. | The decade total is an internal tower metric, not a standalone universal physical constant. |
| family-05 cross-lift comparison | `cam_crystal_reapplication_result` | Family tower binds FLCR-05, FLCR-15, FLCR-25, FLCR-35; avg TarPit mass=0.514757; error walls=0. | Cross-lift agreement strengthens routing and comparison; it does not erase paper-local boundaries. |
| curvature-as-repair | `normal_form_result` | Curvature is closed as boundary repair demand in the LCR formal layer. | GR identity requires continuum/calibration lane. |

### Claim Posture After This Pass

`FLCR-15` should now be read as a resolved-state contribution for `Curvature As Boundary-Repair Demand` at its declared lane. The paper may state the strongest claim supported by these rows directly. It should reserve caution only for a specifically named stronger claim whose required evidence is absent.

## 8. Dependencies And Downstream Use

This paper may be imported by later FLCR papers only through the claim lanes
above. The default downstream consumers are:

- `FLCR-11` through `FLCR-18` for window, receipt, admission, CA, algebraic,
  curvature, residue, and exceptional machinery.
- `FLCR-28` through `FLCR-30` for CAM/crystal, corpus ribbon, and universal
  normal-form intake.
- `FLCR-31` through `FLCR-40` only after the LCR-native result has been cited
  and the translation claim has its own evidence lane.

## 9. Limitations And Falsifiers

- Einstein-equation identity, measured curvature, and physical spacetime calibration remain downstream
- External calibration claims require units, datasets, citations, and reproducible data binding.
- A later translation paper may strengthen this result only by adding the missing lane evidence.

A falsifier for this paper is any example that satisfies the declared input
conditions while violating the stated construction, receipt, or lane boundary.
An interpretation that merely wants a stronger downstream conclusion is not a
falsifier; it is an obligation routed to a later paper.

## 10. Publication Readiness Tasks

- Validator identities and receipt hashes are recorded in the manifest or receipt appendix.
- External theorems require final citation entries before journal submission.
- Every theorem, proposition, and protocol must retain a claim lane and evidence boundary.
- The Markdown, LaTeX, and PDF forms are generated from the same canonical source.

## Dual Positioning: Story And Formal Carrier

This paper must be read in two synchronized ways. Sequentially, it explains why
the next state exists in the corpus story. Formally, it binds that state to
accepted mathematics, IRL formalism, code receipts, validators, CAM/crystal
lookups, and claim-lane boundaries.

Assigned original ribbon role(s): `14`/boundary_action.

| Original slot | Family | Lift | Role | Proof form |
|---|---|---:|---|---|
| `14` | boundary_action | 1 | order-2 slot-4: type the boundary, repair row, or curvature-demand condition | typed boundary row and next-state admissibility |

The formal obligation is to state the strongest valid claim available for this
paper without letting interpretation silently change the addressed object. Any
author interpretation belongs beside the formalism as a declared relabeling,
bridge, or analog, and must be accompanied by the evidence lane that makes the
claim consumable by later papers.

## State-Bound Proof Contract

This paper receives: state emitted by prior slot 13 and reopened at original slot 14 (GR Boundary Repair Curvature).

It must produce: formal result of original slot 14 plus the same-family lift path toward slot 24.

Semantic transition: type the boundary condition that decides whether the state repairs, reflects, curves, or routes onward.

Accepted formalism targets to bind in the journal rewrite:

- boundary value problems
- typed interfaces and admissibility conditions
- topological boundary/interior distinction
- falsifier rows for failed promotions

| Slot | Family | Lift | Produced proof form |
|---|---|---:|---|
| `14` | boundary_action | 1 | typed boundary row and next-state admissibility |

The formal carrier uses these accepted tools while preserving interpretive
claims as explicit relabelings, correspondences, or bridges. Claim promotion is admissible only when a receipt, standard citation,
CAM/crystal reapplication, normal-form result, calibration datum, or falsifier
boundary is attached.

## Provenance And Crystal Evidence Integration

This section integrates prior work, CAM/crystal projections, NSIT tooling,
standards-window evidence, and routed supplements as provenance-bearing
evidence. Source material is not treated as manuscript text; it is bound into
the paper only through claim lanes, receipts, validators, normal forms,
calibration rows, or explicit falsifier boundaries.

### Expansion Rule For This Slot

Use past work to type the boundary: admitted, repaired, reflected, calibration-required, falsified, or routed onward.

### Primary Evidence Inputs

| Source | Placement reason |
|---|---|
| `14_GR_Boundary_Repair_Curvature.md` | primary assigned source for the paper's formal spine |
| `supplements/14_INTERNAL_REASONING_SUPPLEMENT.md` | paper-local reasoning supplement contributing to definitions, proof sketch, and limitations |
| `virtuous\14_GR_Boundary-Repair_Curvature_VIRTUOUS.md` | prior enriched paper body; should be mined for mature claims and proof ordering |

### Secondary And Orbital Evidence Inputs

| Source | Placement reason |
|---|---|
| `supplements/SM_BRIDGE_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/RECEIPT_VERIFIER_CATALOG.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_PYRAMID_INDEX.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_5P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_7P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_9P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `CAM_CLAIM_100_SCORE_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_TOOL_CLOSURE_MATRIX.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_REASONED_CLOSURE_PASS.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `ORBITAL_DATA_CROSS_POPULATION_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `AGENT_CRYSTAL_WORK_HARVEST.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `PAPER_REWORKS_CRYSTAL_PROJECTION.json` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| Additional source routes | Complete routing is maintained in the source-placement appendix |

### Crystal And Standards Evidence To Bind

- Paper Reworks crystal projection: 33 paper markdown files, 9 supplements, 5 queues, 6 lattice-forge unification artifacts, 140 faces, 140 vignettes, and 280 CAM nodes.
- Standards-window intake: 192/192 corpus conformance verdicts PASS; 140/142 obligations have candidate routes; 2/4/8/16/32 window lattice is available for cross-paper reads.
- Agent/crystal harvest: agent-generated memory, runtime standards starter, current runtime build, repo-harvest CAM, notebook-derived bundles, and downloaded crystal payloads are orbital evidence surfaces.
- NSIT inventory baseline: 220 validators, 1786 receipt/data artifacts, 1137 formal-paper-like artifacts, 114 supplements, and 86 memory/CAM artifacts.

### Paper-Specific CAM/Score Rows

| 14 | 87 | internal curvature map closed | CL affirmative verifier: curvature = correction = C-participation, Rule90 flat | measured GR/Einstein bridge and physical calibration |

### Paper-Specific NSIT Closure Rows

No direct NSIT row matched the assigned legacy papers in the first-pass matrix; validator matching by object name remains a receipt-attachment requirement.

### Source Integration Summary

The legacy source and internal reasoning supplement are treated as source
evidence rather than manuscript prose. Their contributions enter this paper as
claim-lane entries, receipt or validator references, finite-domain statements,
and limitation boundaries. Speculative or cross-domain interpretations remain
separate from closed local results until an explicit adapter, citation,
normal-form derivation, calibration row, or falsifier is attached.
## Claim Binding Queue

This queue records the evidence discipline for claim strengthening. It separates claims that already have support from residues that remain in falsifier or open-obligation lanes.

| Queue | Lane | Promote now | Bind next | Residue |
|---|---|---|---|---|
| Continuum Edge And Sampling-Stability Bridge | `external_calibration_result` | Promote discrete-continuous bridge claims only when the sample rule, norm, error bound, or counterexample policy is stated. | Attach sampling rule, interpolation/limit statement, norm, error bound, units, and boundary condition. | Loose continuum, GR, plasma, or energy language stays presentation-level until calibrated. |

### Binding Discipline

Each queue item is represented as a delta:

```text
local claim at paper time
-> attached later source/tool/receipt/theorem
-> revised representation
-> invariant boundary and remaining residue
```

This preserves the sequential story while allowing later tools, crystals, and
standard formalisms to return through the proper lane.

## Claim Delta Ledger

This ledger applies the paper's claim-binding queues as explicit back-application
deltas. It keeps the sequential paper story intact while allowing later
receipts, standard formalisms, CAM/crystal routes, and validators to sharpen the
claim.

| Delta | Local claim at paper time | Later evidence | Revised representation | Boundary kept |
|---|---|---|---|---|
| Continuum Sampling Bridge | This paper may bridge discrete and continuous language only as far as its sampling, projection, or boundary rule supports. | Sampling/interpolation rules, norms, error bounds, boundary conditions, units, and calibration routes. | Promote bridge claims only when sample rule, norm, and error or counterexample policy are stated. | Loose continuum, GR, plasma, or energy language remains presentation-level or calibration-bound. |

The revised representation records the strongest claim supported by the current evidence package. Promotion into theorem or proposition language occurs only when the named evidence is attached in the manifest or workbook replay.

## Source-Backed Evidence Summary

Routed archive and mirror cards are treated as provenance summaries rather than
body text. They identify candidate receipts, validators, theorem registries, or
supplemental source routes. A card strengthens this paper only when its
contribution is bound to a claim lane, evidence object, and boundary.

| Evidence card | Score | Publication contribution | Boundary |
|---|---:|---|---|
| FORMAL: Paper 22 — C-Form: MetaForge Applied Materials Gluon | 85 | **C = the material Gluon** — the applied materials Gluon that transports the morphic Gluon (Paper 21) into physical material candidates. In the lattice_forge substrate, C is realized as the **material Gluon** that: - ... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| FORMAL: Paper 11 — C-Form: Theory Admission Gate Gluon | 77 | **C = the admission filter Gluon** — the trust anchor that filters external theories by Gluon mass matching. In the lattice_forge substrate, C is realized as the **admission gate** that: - Takes an external theory's G... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| CQE-paper-14: Paper 14 - GR Boundary-Repair Curvature | 77 | This paper defines the CQECMPLX substrate meaning of curvature as a boundary-repair demand. The closed result is a transport-ledger theorem: every route has a typed status, demonstrated rows carry zero repair score, n... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| CQE-paper-14.50: Paper 14.50 - Boundary-Repair Curvature Claim Contract | 77 | The contract keeps the useful object clean: repair is a real substrate quantity. Physical curvature is a proposed interpretation until proven. | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| SUMMARY-II-Folded-Strand-Physics: Summary Paper II — Folded Strand Physics: The Gluon as Quark, Mass, Curvature, Tower, and Moonshine | 75 | This paper presents the **physics applications** of the Gluon formalism. We do not use the word "Gluon" because the fit is good. We use it because the substrate **IS** SU(3), and the physics IS the **standard model ga... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| Additional evidence cards | 12 total | The complete card inventory is maintained in the archive evidence matrix. | Cards are source-discovery aids until bound to paper-local evidence. |

## Journal Apparatus

### Article Type And Intended Venue Fit

This manuscript is written as a formal-methods and mathematical-systems paper
inside the series *Formalizing LCR, Unifying Standard Models*. Its intended
reader is a technical reviewer who needs claim boundaries, reproducibility
routes, and cross-paper dependencies to be visible without relying on private
context.

### Structured Contribution Statement

| Item | Statement |
|---|---|
| Publication ID | `FLCR-15` |
| Legacy source slot(s) | `14` |
| Ribbon role | order-2 slot-4: type the boundary, repair row, or curvature-demand condition |
| Proof form | typed boundary row and next-state admissibility |
| Received state | state emitted by prior slot 13 and reopened at original slot 14 (GR Boundary Repair Curvature) |
| Produced state | formal result of original slot 14 plus the same-family lift path toward slot 24 |

### Claim-Evidence Table

| Claim | Lane | Evidence to attach | Boundary |
|---|---|---|---|
| Theorem 15.1 | `receipt_bound_internal_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | boundary repair demand can be represented as a structured curvature-like ledger over discrete transitions |
| Proposition 15.2 | `normal_form_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | repair-curvature map can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 15.3 | `falsifier_or_open_obligation` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | Einstein-equation identity, measured curvature, and physical spacetime calibration remain downstream |

### Figure Plan

| Figure | Purpose | Caption |
|---|---|---|
| FLCR-15-F1 | Typed boundary/admission diagram | Schematic showing how `FLCR-15` turns its received state into the produced state while preserving claim lanes and residue boundaries. |
| FLCR-15-F2 | Evidence routing map | Diagram of source papers, archive cards, CAM/crystal routes, validators, and workbook replay paths used by this manuscript. |
| FLCR-15-F3 | Same-family lift context | Diagram placing this paper in the original `00-79` ribbon family and showing predecessor/successor slots. |

### In-Text Figure FLCR-15-F1: Typed boundary/admission diagram

```text
received state
  -> Typed boundary/admission diagram
  -> formal claim lane
  -> evidence object / receipt / citation
  -> produced state
  -> remaining residue
```

### Table Plan

| Table | Purpose |
|---|---|
| FLCR-15-T1 | Boundary verdict table |
| FLCR-15-T2 | Claim-lane/evidence-boundary table |
| FLCR-15-T3 | Archive evidence card and source-backed upgrade table |
| FLCR-15-T4 | Workbook replay and falsifier table |

### Worked Example

Classify a candidate as admitted, repaired, boundary, rejected, or calibration-required. The example must name the input object, the operation,
the evidence object, the allowed revised claim, and the remaining boundary.

### Nomenclature And Glossary

| Term | Paper-local meaning |
|---|---|
| CAM | Defined by this paper as part of the `boundary_action` proof role; final definition is recorded in the paper-local glossary. |
| admission | Defined by this paper as part of the `boundary_action` proof role; final definition is recorded in the paper-local glossary. |
| boundary | Defined by this paper as part of the `boundary_action` proof role; final definition is recorded in the paper-local glossary. |
| claim lane | Defined by this paper as part of the `boundary_action` proof role; final definition is recorded in the paper-local glossary. |
| crystal | Defined by this paper as part of the `boundary_action` proof role; final definition is recorded in the paper-local glossary. |
| falsifier | Defined by this paper as part of the `boundary_action` proof role; final definition is recorded in the paper-local glossary. |
| receipt | Defined by this paper as part of the `boundary_action` proof role; final definition is recorded in the paper-local glossary. |
| repair row | Defined by this paper as part of the `boundary_action` proof role; final definition is recorded in the paper-local glossary. |

### Appendix FLCR-15-A: Evidence Package

The appendix records:

1. Legacy source excerpts or source-card references used in the final claim ledger.
2. Receipt and verifier paths, including pass/fail/partial status.
3. CAM/crystal query or projection rows used by the paper, with source identity and boundary.
4. Standards-window and NSIT evidence used for conformance or routing.
5. Falsifier, calibration, or external-data rows that remain unresolved.

### Data And Code Availability

The publication package contains the canonical Markdown sources, manifests, source-routing matrices, validation reports, and generated PDF/TeX outputs.

Code and verifier references are cited through manifests, archive evidence cards, receipt catalogs, or workbook replay tables. External datasets or
standards citations must be attached before any calibration-bound claim is
promoted.

### Reviewer Checklist

| Check | Reviewer question |
|---|---|
| Claim lane | Does every strong claim declare its lane and evidence type? |
| Boundary | Does the paper preserve what it does not prove? |
| Reproducibility | Is there a receipt, verifier, source card, citation, or replay table for the claim? |
| Cross-paper import | Does the paper cite the prior FLCR/OPR slot before consuming its result? |
| Interpretation | Does the analog layer preserve the addressed state while changing labels/access paths? |

### Declarations

No human-subjects, clinical, or animal-research protocol is asserted by this
paper. External empirical claims require separate dataset, calibration, or
domain-validation attachments. Competing-interest and funding statements are recorded in the submission metadata.

## 11. Publication Integration Addendum

### 11.1 Role In The Series

`FLCR-15` (`Curvature As Boundary-Repair Demand`) occupies the `boundary_action` role at lift depth `1`.
The paper receives state emitted by prior slot 13 and reopened at original slot 14 (GR Boundary Repair Curvature). It produces formal result of original slot 14 plus the same-family lift path toward slot 24. The state transition is:
type the boundary condition that decides whether the state repairs, reflects, curves, or routes onward.

The paper-local proof form is:

```text
typed boundary row and next-state admissibility
```

The integration result is a typed boundary/admission table for legal next-state repair. This addendum records how that result is
consumed by the publication series without relying on editorial instructions or
private working context.

### 11.2 Formal Carrier

| Formal carrier | Function |
|---|---|
| boundary value problems | Formal carrier for the paper-local result. |
| typed interfaces and admissibility conditions | Formal carrier for the paper-local result. |
| topological boundary/interior distinction | Formal carrier for the paper-local result. |
| falsifier rows for failed promotions | Formal carrier for the paper-local result. |

The LCR, CAM, crystal, forge, and analog vocabulary functions as a typed access
layer over these carriers. A relabeling is admissible only when the addressed
object, evidence lane, boundary, and downstream import rule remain attached.

### 11.3 Claim Ledger

| Claim | Lane | Statement |
|---|---|---|
| Theorem 15.1 | `receipt_bound_internal_result` | boundary repair demand can be represented as a structured curvature-like ledger over discrete transitions |
| Proposition 15.2 | `normal_form_result` | repair-curvature map can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 15.3 | `falsifier_or_open_obligation` | Einstein-equation identity, measured curvature, and physical spacetime calibration remain downstream |

These claims are consumed at their stated lane. A stronger downstream statement
creates a new claim envelope with its own evidence object.

### 11.4 Evidence Package

| Evidence class | Routed items | Status |
|---|---|---|
| Legacy sources | `14_GR_Boundary_Repair_Curvature.md`, `virtuous/14_GR_Boundary-Repair_Curvature_VIRTUOUS.md`, `supplements/14_INTERNAL_REASONING_SUPPLEMENT.md` | routed evidence |
| Evidence inputs | `CAM_CLAIM_100_SCORE_AUDIT.md`, `NSIT_TOOL_CLOSURE_MATRIX.md`, `NSIT_REASONED_CLOSURE_PASS.md`, `PAPER_REWORKS_CRYSTAL_PROJECTION.json` | routed evidence |
| CAM/crystal sources | `PAPER_REWORKS_CRYSTAL_PROJECTION.json`, `AGENT_CRYSTAL_WORK_HARVEST.json`, `runtime standards artifact`, `notebook-derived source bundle` | routed evidence |
| Standards-window inputs | `window_summary.json`, `node DBs`, `window DBs` | routed evidence |
| Receipts | external requirement | not attached in this source package |
| Validators | external requirement | not attached in this source package |

Standards-window, runtime, and notebook-derived artifacts are treated
as evidence-routing surfaces. They support source discovery, conformance
checking, and reapplication, but they do not replace citations, receipts,
normal-form derivations, calibration rows, or falsifiers.

### 11.5 Results Representation

The paper's results section is organized around five publication objects:

1. the exact object acted on at this slot;
2. the admissible operation or transformation;
3. the receipt, enumeration, derivation, lookup, or external theorem supporting
   the operation;
4. the residue or boundary left after the result;
5. the downstream import rule.

### 11.6 Figures And Tables

| Figure | Role |
|---|---|
| FLCR-15-F1: Typed boundary/admission diagram | Visualizes the proof object, routing, or boundary. |
| FLCR-15-F2: Evidence routing map | Visualizes the proof object, routing, or boundary. |
| FLCR-15-F3: Same-family lift context | Visualizes the proof object, routing, or boundary. |

| Table | Role |
|---|---|
| FLCR-15-T1: Boundary verdict table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-15-T2: Claim-lane/evidence-boundary table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-15-T3: Archive evidence card and source-backed upgrade table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-15-T4: Workbook replay and falsifier table | Records claim lanes, evidence, sources, or falsifiers. |

### 11.7 Limits And Falsifiers

The paper proves only the object and domain declared in its claim ledger.
Physical, Standard Model, observer, calibration, or synthesis claims require
the additional lane evidence stated by their destination papers. CAM/crystal
and forge language is operational only when represented as an address, lookup,
receipt, validator, or reapplication path.
