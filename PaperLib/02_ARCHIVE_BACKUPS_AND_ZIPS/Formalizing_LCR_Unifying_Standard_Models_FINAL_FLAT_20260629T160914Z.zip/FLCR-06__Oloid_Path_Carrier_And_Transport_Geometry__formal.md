# FLCR-06 - Oloid Path Carrier And Transport Geometry

**Series:** Formalizing LCR, Unifying Standard Models  
**Artifact:** formal paper source  
**Status:** first-pass rich rewrite; requires final citation and build pass.  
**Claim posture:** maximal local claim posture with explicit lane boundaries.

## Abstract

This paper defines the path carrier as a deterministic finite-state transducer. A repair row can travel as side-channel metadata while the carrier transition remains unchanged. The path theorem closes graph-continuous finite transport and payload noninterference; it does not by itself assert real oloid kinematics, gauge holonomy, or physical motion.

## Keywords

finite transducer; path carrier; payload noninterference; graph continuity; oloid.

## 1. Contribution And Scope

- Models the path carrier as a finite-state transducer driven by legal input bits.
- Defines graph continuity as adjacency-preserving legal transition.
- Proves payload noninterference for repair metadata.
- Separates symbolic oloid/path geometry from measured geometry.

This paper is part of the LCR-native base layer. Standard Model or physical
language is permitted only as deferred mapping, analogy, or explicitly bounded
future calibration. The editable surface is the claim lane and source-routing
layer; the base objects must remain stable enough for downstream papers to
consume them without ambiguity.

## 2. Source Routing

Primary routed sources:

- `05_Oloid_Path_Carrier.md`
- `supplements/05_INTERNAL_REASONING_SUPPLEMENT.md`

Cross-corpus evidence classes:

- `CAM_CLAIM_100_SCORE_AUDIT.md`
- `NSIT_TOOL_CLOSURE_MATRIX.md`
- `NSIT_REASONED_CLOSURE_PASS.md`
- `PAPER_REWORKS_CRYSTAL_PROJECTION.json`
- standards, glue, window, and node databases where applicable
- notebook-derived review prompts and orbital source manifests

## 3. Definitions

- **Path carrier.** A finite state machine carrying sheet, phase, parity, and dyadic readouts.
- **Legal roll.** A deterministic transition selected by an admissible input bit and current carrier state.
- **Payload noninterference.** The property that attached metadata does not alter the transition function.
- **Graph-continuous transport.** A path whose consecutive states are adjacent under the legal transition graph.

## 4. Formal Claims

| Claim | Lane | Statement |
|-------|------|-----------|
| Theorem 6.1 | `receipt_bound_internal_result` | The path carrier is a deterministic finite-state transducer over its declared state space. |
| Theorem 6.2 | `receipt_bound_internal_result` | Repair-row payloads are noninterfering side-channel data for the carrier transition. |
| Protocol 6.3 | `falsifier_or_open_obligation` | Physical oloid, holonomy, QCD, or mass interpretations require downstream calibration or theorem import. |

## 5. Paper-Specific Development

1. Define the carrier state variables and the legal roll transition.
2. Read an input word as repeated application of the transition function.
3. Attach repair metadata as payload and rerun the transition sequence.
4. Verify that the state path is identical with and without payload.

### Proof Sketch

The carrier is a deterministic transducer: current state plus input bit selects exactly one next state and output readout. Payload fields are not arguments to the transition function. Therefore changing payload while holding state and input fixed cannot change the emitted path.

## 6. Construction

The construction is intentionally staged. First, the paper names the finite or
typed object that can be inspected directly. Second, it declares the admissible
operations over that object. Third, it records the receipt or source class that
allows another paper to consume the result. Fourth, it names the residue that
must not be silently promoted.

For this paper, the operative object is `Oloid Path Carrier And Transport Geometry`. Its safe consumption
rule is:

```text
source object -> declared operation -> receipt/lane -> downstream import
```

The unsafe consumption rule is:

```text
source phrase -> downstream identity claim
```

That second pattern is explicitly rejected by FLCR-01 and must be rewritten as
a claim-lane promotion with evidence.

## 7. Evidence And Receipts

| Evidence source | What it contributes |
|-----------------|---------------------|
| Paper 05 legacy body | Oloid path carrier, rolling constraints, payload transport. |
| Internal supplement 05 | Finite-state transducer, monoid action, noninterference framing. |
| NSIT tool matrix | Oloid carrier family receipt closes the internal carrier family. |
| CAM Claim 100 Score Audit | Paper 05 scored 91 as system-composition closeable. |

## Resolved-State Closure Pass

This pass removes false restrictions on the paper's claim posture. A row is no longer called open merely because a stronger future claim exists. The satisfied lane is closed now; only the stronger claim that lacks its required adapter, comparator, calibration, or falsifier remains as residue.

### Closed Now

| Row | Lane | Resolved state | Remaining boundary |
|---|---|---|---|
| paper lift enumeration | `receipt_bound_internal_result` | 8/8 LCR states succeeded; error walls=0; avg TarPit mass=0.507588. | This closes the paper-local finite lift readout, not every stronger physical interpretation. |
| carrier/transducer route | `normal_form_result` | The carrier route is closed as a state-preserving transfer with recorded loss or residue. | The family closure is a structural lane; measured physics still requires destination-specific calibration. |
| decade-1 tower | `receipt_bound_internal_result` | The decade tower is resolved with avg TarPit mass=0.510370 and mass sum=40.829567. | The decade total is an internal tower metric, not a standalone universal physical constant. |
| family-06 cross-lift comparison | `cam_crystal_reapplication_result` | Family tower binds FLCR-06, FLCR-16, FLCR-26, FLCR-36; avg TarPit mass=0.506672; error walls=0. | Cross-lift agreement strengthens routing and comparison; it does not erase paper-local boundaries. |
| oloid/path transport | `normal_form_result` | Path-carrier transport is closed as a geometry-of-transfer surface. | Measured path dynamics remain calibration-bound. |

### Claim Posture After This Pass

`FLCR-06` should now be read as a resolved-state contribution for `Oloid Path Carrier And Transport Geometry` at its declared lane. The paper may state the strongest claim supported by these rows directly. It should reserve caution only for a specifically named stronger claim whose required evidence is absent.

## 8. Dependencies And Downstream Use

This paper may be imported by later FLCR papers only through the claim lanes
above. The default downstream consumers are:

- `FLCR-11` through `FLCR-18` for window, receipt, admission, CA, algebraic,
  curvature, residue, and exceptional machinery.
- `FLCR-28` through `FLCR-30` for CAM/crystal, corpus ribbon, and universal
  normal-form intake.
- `FLCR-31` through `FLCR-40` only after the LCR-native result has been cited
  and the translation claim has its own evidence lane.

## 9. Limitations And Falsifiers

- Graph continuity is not physical continuity unless a geometry model is attached.
- Payload transport does not solve unbounded Rule 30 prediction.
- Holonomy-like language remains analogical until a gauge connection and observable are defined.

A falsifier for this paper is any example that satisfies the declared input
conditions while violating the stated construction, receipt, or lane boundary.
An interpretation that merely wants a stronger downstream conclusion is not a
falsifier; it is an obligation routed to a later paper.

## 10. Publication Readiness Tasks

- Validator identities and receipt hashes are recorded in the manifest or receipt appendix.
- External theorems require final citation entries before journal submission.
- Every theorem, proposition, and protocol must retain a claim lane and evidence boundary.
- The Markdown, LaTeX, and PDF forms are generated from the same canonical source.

## Dual Positioning: Story And Formal Carrier

This paper must be read in two synchronized ways. Sequentially, it explains why
the next state exists in the corpus story. Formally, it binds that state to
accepted mathematics, IRL formalism, code receipts, validators, CAM/crystal
lookups, and claim-lane boundaries.

Assigned original ribbon role(s): `05`/carrier_action.

| Original slot | Family | Lift | Role | Proof form |
|---|---|---:|---|---|
| `05` | carrier_action | 0 | order-1 slot-5: carry the state through a path, traversal, or admissible motion | carrier/transducer/path proof |

The formal obligation is to state the strongest valid claim available for this
paper without letting interpretation silently change the addressed object. Any
author interpretation belongs beside the formalism as a declared relabeling,
bridge, or analog, and must be accompanied by the evidence lane that makes the
claim consumable by later papers.

## State-Bound Proof Contract

This paper receives: state emitted by prior slot 04 and reopened at original slot 05 (Oloid Path Carrier).

It must produce: formal result of original slot 05 plus the same-family lift path toward slot 15.

Semantic transition: carry the state through an admissible path, traversal, transport, or transducer.

Accepted formalism targets to bind in the journal rewrite:

- path composition
- automata and transducers
- transport maps
- invariant preservation along morphisms

| Slot | Family | Lift | Produced proof form |
|---|---|---:|---|
| `05` | carrier_action | 0 | carrier/transducer/path proof |

The formal carrier uses these accepted tools while preserving interpretive
claims as explicit relabelings, correspondences, or bridges. Claim promotion is admissible only when a receipt, standard citation,
CAM/crystal reapplication, normal-form result, calibration datum, or falsifier
boundary is attached.

## Provenance And Crystal Evidence Integration

This section integrates prior work, CAM/crystal projections, NSIT tooling,
standards-window evidence, and routed supplements as provenance-bearing
evidence. Source material is not treated as manuscript text; it is bound into
the paper only through claim lanes, receipts, validators, normal forms,
calibration rows, or explicit falsifier boundaries.

### Expansion Rule For This Slot

Use past work to bind transport: path, transducer, traversal, carrier medium, invariant, and external calibration boundary.

### Primary Evidence Inputs

| Source | Placement reason |
|---|---|
| `05_Oloid_Path_Carrier.md` | primary assigned source for the paper's formal spine |
| `supplements/05_INTERNAL_REASONING_SUPPLEMENT.md` | paper-local reasoning supplement contributing to definitions, proof sketch, and limitations |

### Secondary And Orbital Evidence Inputs

| Source | Placement reason |
|---|---|
| `supplements/CRYSTAL_CAM_PROJECTOR_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/RECEIPT_VERIFIER_CATALOG.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_PYRAMID_INDEX.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_5P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_7P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_9P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `CAM_CLAIM_100_SCORE_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_TOOL_CLOSURE_MATRIX.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_REASONED_CLOSURE_PASS.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `ORBITAL_DATA_CROSS_POPULATION_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `AGENT_CRYSTAL_WORK_HARVEST.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `PAPER_REWORKS_CRYSTAL_PROJECTION.json` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| Additional source routes | Complete routing is maintained in the source-placement appendix |

### Crystal And Standards Evidence To Bind

- Paper Reworks crystal projection: 33 paper markdown files, 9 supplements, 5 queues, 6 lattice-forge unification artifacts, 140 faces, 140 vignettes, and 280 CAM nodes.
- Standards-window intake: 192/192 corpus conformance verdicts PASS; 140/142 obligations have candidate routes; 2/4/8/16/32 window lattice is available for cross-paper reads.
- Agent/crystal harvest: agent-generated memory, runtime standards starter, current runtime build, repo-harvest CAM, notebook-derived bundles, and downloaded crystal payloads are orbital evidence surfaces.
- NSIT inventory baseline: 220 validators, 1786 receipt/data artifacts, 1137 formal-paper-like artifacts, 114 supplements, and 86 memory/CAM artifacts.

### Paper-Specific CAM/Score Rows

| 05 | 91 | system-composition closeable | rolling carrier, payload non-interference, oloid family, gluon worldline, CD theta-zero | physical oloid geometry and cold prediction admission |

### Paper-Specific NSIT Closure Rows

| Oloid carrier family | batch_tool_unison_closure | `lattice_forge/oloid_*.py` | Paper 05 | `oloid_carrier_family_receipt.json` 4/4 | Oloid carrier family closes; E6->E7->E8 lift remains separate. |

### Source Integration Summary

The legacy source and internal reasoning supplement are treated as source
evidence rather than manuscript prose. Their contributions enter this paper as
claim-lane entries, receipt or validator references, finite-domain statements,
and limitation boundaries. Speculative or cross-domain interpretations remain
separate from closed local results until an explicit adapter, citation,
normal-form derivation, calibration row, or falsifier is attached.
## Claim Binding Queue

This queue records the evidence discipline for claim strengthening. It separates claims that already have support from residues that remain in falsifier or open-obligation lanes.

| Queue | Lane | Promote now | Bind next | Residue |
|---|---|---|---|---|
| Symbolic Carrier Versus Physical Carrier | `external_calibration_result` | Promote addressable symbolic-carrier and transport claims where the paper names carrier, path, residue, or traversal rules. | Map every physical carrier phrase to a standard physics object, Hamiltonian/model, dataset, or calibration route before treating it as measured physics. | Physical identity, units, material constants, and measured transport remain calibration-bound. |

### Binding Discipline

Each queue item is represented as a delta:

```text
local claim at paper time
-> attached later source/tool/receipt/theorem
-> revised representation
-> invariant boundary and remaining residue
```

This preserves the sequential story while allowing later tools, crystals, and
standard formalisms to return through the proper lane.

## Claim Delta Ledger

This ledger applies the paper's claim-binding queues as explicit back-application
deltas. It keeps the sequential paper story intact while allowing later
receipts, standard formalisms, CAM/crystal routes, and validators to sharpen the
claim.

| Delta | Local claim at paper time | Later evidence | Revised representation | Boundary kept |
|---|---|---|---|---|
| Symbolic Vs Physical Carrier | This paper may use carrier language for addressable symbolic transport inside the LCR/CAM system. | Standard physics carrier terminology, local verifier receipts, material/plasma/transport supplements, and calibration routes. | Split symbolic carrier closure from measured physical carrier identity. | Physical identity, units, Hamiltonians, datasets, and measured constants remain external-calibration claims. |

The revised representation records the strongest claim supported by the current evidence package. Promotion into theorem or proposition language occurs only when the named evidence is attached in the manifest or workbook replay.

## Source-Backed Evidence Summary

Routed archive and mirror cards are treated as provenance summaries rather than
body text. They identify candidate receipts, validators, theorem registries, or
supplemental source routes. A card strengthens this paper only when its
contribution is bound to a claim lane, evidence object, and boundary.

| Evidence card | Score | Publication contribution | Boundary |
|---|---:|---|---|
| FINAL_FORMAL_PAPER: Complete Formal Claims: The Folded Strand | 75 | We present the complete closed-form claim set of the CQE_CMPLX corpus: - 33 papers = 33 folding operations on a self-complementary strand - 144 tools = cumulative analog kit = digital twin surface - 135 digital twins ... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| SUMMARY-V-32-Theorems-Registry: Summary Paper V — The 32 Theorems in One Table: Closed-Form Registry | 75 | This paper is the **complete closed-form registry of all 32 theorems** in the CQE_CMPLX corpus. Each theorem is stated precisely, given its formal context (where it is proven), and listed with its verifier. The table ... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| CQE-paper-06.25: Paper 6.25 - Toolkit for Causal Code | 69 | Paper 6.25 describes the review tools for causal code. These tools expose the typed dependency graph and its falsifiers; they do not declare the full 32-paper graph complete. The toolkit works with: ```text vertex = p... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| CQE-PAPER-001-ENHANCED: CQE-PAPER-001-ENHANCED | 69 | *From DERIVATIONS.md §10 + Exact Named Map Audit* | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| WORKBOOK: Paper 05 — Workbook: Oloid Path Carrier Sheet (v1 — isomorphic to tool) | 67 | This workbook is supplemental validation and exposure material. It is not the paper's primary proof. It shows how the paper's mathematical state can be reconstructed with ordinary marks, tokens, strings, cards, or any... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| Additional evidence cards | 11 total | The complete card inventory is maintained in the archive evidence matrix. | Cards are source-discovery aids until bound to paper-local evidence. |

## Journal Apparatus

### Article Type And Intended Venue Fit

This manuscript is written as a formal-methods and mathematical-systems paper
inside the series *Formalizing LCR, Unifying Standard Models*. Its intended
reader is a technical reviewer who needs claim boundaries, reproducibility
routes, and cross-paper dependencies to be visible without relying on private
context.

### Structured Contribution Statement

| Item | Statement |
|---|---|
| Publication ID | `FLCR-06` |
| Legacy source slot(s) | `05` |
| Ribbon role | order-1 slot-5: carry the state through a path, traversal, or admissible motion |
| Proof form | carrier/transducer/path proof |
| Received state | state emitted by prior slot 04 and reopened at original slot 05 (Oloid Path Carrier) |
| Produced state | formal result of original slot 05 plus the same-family lift path toward slot 15 |

### Claim-Evidence Table

| Claim | Lane | Evidence to attach | Boundary |
|---|---|---|---|
| Theorem 6.1 | `receipt_bound_internal_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | The path carrier is a deterministic finite-state transducer over its declared state space. |
| Theorem 6.2 | `receipt_bound_internal_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | Repair-row payloads are noninterfering side-channel data for the carrier transition. |
| Protocol 6.3 | `falsifier_or_open_obligation` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | Physical oloid, holonomy, QCD, or mass interpretations require downstream calibration or theorem import. |

### Figure Plan

| Figure | Purpose | Caption |
|---|---|---|
| FLCR-06-F1 | Carrier path and invariant payload | Schematic showing how `FLCR-06` turns its received state into the produced state while preserving claim lanes and residue boundaries. |
| FLCR-06-F2 | Evidence routing map | Diagram of source papers, archive cards, CAM/crystal routes, validators, and workbook replay paths used by this manuscript. |
| FLCR-06-F3 | Same-family lift context | Diagram placing this paper in the original `00-79` ribbon family and showing predecessor/successor slots. |

### In-Text Figure FLCR-06-F1: Carrier path and invariant payload

```text
received state
  -> Carrier path and invariant payload
  -> formal claim lane
  -> evidence object / receipt / citation
  -> produced state
  -> remaining residue
```

### Table Plan

| Table | Purpose |
|---|---|
| FLCR-06-T1 | Carrier transport table |
| FLCR-06-T2 | Claim-lane/evidence-boundary table |
| FLCR-06-T3 | Archive evidence card and source-backed upgrade table |
| FLCR-06-T4 | Workbook replay and falsifier table |

### Worked Example

Carry one state through a path/transducer and show what remains invariant. The example must name the input object, the operation,
the evidence object, the allowed revised claim, and the remaining boundary.

### Nomenclature And Glossary

| Term | Paper-local meaning |
|---|---|
| CAM | Defined by this paper as part of the `carrier_action` proof role; final definition is recorded in the paper-local glossary. |
| carrier | Defined by this paper as part of the `carrier_action` proof role; final definition is recorded in the paper-local glossary. |
| claim lane | Defined by this paper as part of the `carrier_action` proof role; final definition is recorded in the paper-local glossary. |
| crystal | Defined by this paper as part of the `carrier_action` proof role; final definition is recorded in the paper-local glossary. |
| invariant payload | Defined by this paper as part of the `carrier_action` proof role; final definition is recorded in the paper-local glossary. |
| path composition | Defined by this paper as part of the `carrier_action` proof role; final definition is recorded in the paper-local glossary. |
| receipt | Defined by this paper as part of the `carrier_action` proof role; final definition is recorded in the paper-local glossary. |
| transport | Defined by this paper as part of the `carrier_action` proof role; final definition is recorded in the paper-local glossary. |

### Appendix FLCR-06-A: Evidence Package

The appendix records:

1. Legacy source excerpts or source-card references used in the final claim ledger.
2. Receipt and verifier paths, including pass/fail/partial status.
3. CAM/crystal query or projection rows used by the paper, with source identity and boundary.
4. Standards-window and NSIT evidence used for conformance or routing.
5. Falsifier, calibration, or external-data rows that remain unresolved.

### Data And Code Availability

The publication package contains the canonical Markdown sources, manifests, source-routing matrices, validation reports, and generated PDF/TeX outputs.

Code and verifier references are cited through manifests, archive evidence cards, receipt catalogs, or workbook replay tables. External datasets or
standards citations must be attached before any calibration-bound claim is
promoted.

### Reviewer Checklist

| Check | Reviewer question |
|---|---|
| Claim lane | Does every strong claim declare its lane and evidence type? |
| Boundary | Does the paper preserve what it does not prove? |
| Reproducibility | Is there a receipt, verifier, source card, citation, or replay table for the claim? |
| Cross-paper import | Does the paper cite the prior FLCR/OPR slot before consuming its result? |
| Interpretation | Does the analog layer preserve the addressed state while changing labels/access paths? |

### Declarations

No human-subjects, clinical, or animal-research protocol is asserted by this
paper. External empirical claims require separate dataset, calibration, or
domain-validation attachments. Competing-interest and funding statements are recorded in the submission metadata.

## 11. Publication Integration Addendum

### 11.1 Role In The Series

`FLCR-06` (`Oloid Path Carrier And Transport Geometry`) occupies the `carrier_action` role at lift depth `0`.
The paper receives state emitted by prior slot 04 and reopened at original slot 05 (Oloid Path Carrier). It produces formal result of original slot 05 plus the same-family lift path toward slot 15. The state transition is:
carry the state through an admissible path, traversal, transport, or transducer.

The paper-local proof form is:

```text
carrier/transducer/path proof
```

The integration result is a state-preserving carrier or transducer route with recorded loss/residue. This addendum records how that result is
consumed by the publication series without relying on editorial instructions or
private working context.

### 11.2 Formal Carrier

| Formal carrier | Function |
|---|---|
| path composition | Formal carrier for the paper-local result. |
| automata and transducers | Formal carrier for the paper-local result. |
| transport maps | Formal carrier for the paper-local result. |
| invariant preservation along morphisms | Formal carrier for the paper-local result. |

The LCR, CAM, crystal, forge, and analog vocabulary functions as a typed access
layer over these carriers. A relabeling is admissible only when the addressed
object, evidence lane, boundary, and downstream import rule remain attached.

### 11.3 Claim Ledger

| Claim | Lane | Statement |
|---|---|---|
| Theorem 6.1 | `receipt_bound_internal_result` | The path carrier is a deterministic finite-state transducer over its declared state space. |
| Theorem 6.2 | `receipt_bound_internal_result` | Repair-row payloads are noninterfering side-channel data for the carrier transition. |
| Protocol 6.3 | `falsifier_or_open_obligation` | Physical oloid, holonomy, QCD, or mass interpretations require downstream calibration or theorem import. |

These claims are consumed at their stated lane. A stronger downstream statement
creates a new claim envelope with its own evidence object.

### 11.4 Evidence Package

| Evidence class | Routed items | Status |
|---|---|---|
| Legacy sources | `05_Oloid_Path_Carrier.md`, `supplements/05_INTERNAL_REASONING_SUPPLEMENT.md` | routed evidence |
| Evidence inputs | `CAM_CLAIM_100_SCORE_AUDIT.md`, `NSIT_TOOL_CLOSURE_MATRIX.md`, `NSIT_REASONED_CLOSURE_PASS.md`, `PAPER_REWORKS_CRYSTAL_PROJECTION.json` | routed evidence |
| CAM/crystal sources | `PAPER_REWORKS_CRYSTAL_PROJECTION.json`, `AGENT_CRYSTAL_WORK_HARVEST.json`, `runtime standards artifact`, `notebook-derived source bundle` | routed evidence |
| Standards-window inputs | `window_summary.json`, `node DBs`, `window DBs` | routed evidence |
| Receipts | external requirement | not attached in this source package |
| Validators | external requirement | not attached in this source package |

Standards-window, runtime, and notebook-derived artifacts are treated
as evidence-routing surfaces. They support source discovery, conformance
checking, and reapplication, but they do not replace citations, receipts,
normal-form derivations, calibration rows, or falsifiers.

### 11.5 Results Representation

The paper's results section is organized around five publication objects:

1. the exact object acted on at this slot;
2. the admissible operation or transformation;
3. the receipt, enumeration, derivation, lookup, or external theorem supporting
   the operation;
4. the residue or boundary left after the result;
5. the downstream import rule.

### 11.6 Figures And Tables

| Figure | Role |
|---|---|
| FLCR-06-F1: Carrier path and invariant payload | Visualizes the proof object, routing, or boundary. |
| FLCR-06-F2: Evidence routing map | Visualizes the proof object, routing, or boundary. |
| FLCR-06-F3: Same-family lift context | Visualizes the proof object, routing, or boundary. |

| Table | Role |
|---|---|
| FLCR-06-T1: Carrier transport table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-06-T2: Claim-lane/evidence-boundary table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-06-T3: Archive evidence card and source-backed upgrade table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-06-T4: Workbook replay and falsifier table | Records claim lanes, evidence, sources, or falsifiers. |

### 11.7 Limits And Falsifiers

The paper proves only the object and domain declared in its claim ledger.
Physical, Standard Model, observer, calibration, or synthesis claims require
the additional lane evidence stated by their destination papers. CAM/crystal
and forge language is operational only when represented as an address, lookup,
receipt, validator, or reapplication path.
