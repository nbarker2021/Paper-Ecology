# FLCR-07 - Causal Links And Obligation Ledgers

**Series:** Formalizing LCR, Unifying Standard Models  
**Artifact:** formal paper source  
**Status:** first-pass rich rewrite; requires final citation and build pass.  
**Claim posture:** maximal local claim posture with explicit lane boundaries.

## Abstract

This paper turns the FLCR corpus into an auditable dependency graph. It distinguishes proof-support edges, obligation edges, negative verdicts, receipt edges, and workflow routes. This prevents open obligations from being consumed as proofs while still allowing them to act as springboards for later reapplication.

## Keywords

causal ledger; proof graph; obligation; receipt DAG; negative result.

## 1. Contribution And Scope

- Defines typed edges for support, obligation, receipt, and negative verdicts.
- Treats failed extraction attempts as reusable search-pruning data.
- Frames the paper corpus as a content-addressed provenance graph.
- Prepares the T10 master receipt and later layer-2 synthesis ledgers.

This paper is part of the LCR-native base layer. Standard Model or physical
language is permitted only as deferred mapping, analogy, or explicitly bounded
future calibration. The editable surface is the claim lane and source-routing
layer; the base objects must remain stable enough for downstream papers to
consume them without ambiguity.

## 2. Source Routing

Primary routed sources:

- `06_Causal_Link_and_Obligation_Ledger.md`
- `supplements/06_INTERNAL_REASONING_SUPPLEMENT.md`

Cross-corpus evidence classes:

- `CAM_CLAIM_100_SCORE_AUDIT.md`
- `NSIT_TOOL_CLOSURE_MATRIX.md`
- `NSIT_REASONED_CLOSURE_PASS.md`
- `PAPER_REWORKS_CRYSTAL_PROJECTION.json`
- standards, glue, window, and node databases where applicable
- notebook-derived review prompts and orbital source manifests

## 3. Definitions

- **Proof-support edge.** A dependency edge whose target may consume the source as evidence within a declared lane.
- **Obligation edge.** A next-need edge that routes work but does not prove its target.
- **Negative verdict.** A tested route that failed in a named scope and should be searchable as constraint data.
- **Corpus lockfile.** A reproducible graph of paper IDs, theorem IDs, receipts, hashes, and dependency edges.

## 4. Formal Claims

| Claim | Lane | Statement |
|-------|------|-----------|
| Theorem 7.1 | `normal_form_result` | A valid FLCR causal graph must type its edges before they can be consumed by paper claims. |
| Proposition 7.2 | `receipt_bound_internal_result` | Negative extraction verdicts reduce future search space and therefore belong in the ledger. |
| Protocol 7.3 | `falsifier_or_open_obligation` | Obligation edges may route future work but cannot serve as proof-support edges without promotion. |

## 5. Paper-Specific Development

1. Define graph nodes as papers, claims, receipts, validators, obligations, and negative verdicts.
2. Type each edge before allowing another node to consume it.
3. Separate proof-support edges from obligation routing edges.
4. Store negative verdicts as reusable constraints with tested scope.

### Proof Sketch

A typed dependency graph prevents category errors. If an edge is marked as obligation routing, downstream consumers cannot treat it as proof without a promotion receipt. If a negative verdict is scoped and stored, future search can avoid repeating the same failed route while preserving the possibility of a different route later.

## 6. Construction

The construction is intentionally staged. First, the paper names the finite or
typed object that can be inspected directly. Second, it declares the admissible
operations over that object. Third, it records the receipt or source class that
allows another paper to consume the result. Fourth, it names the residue that
must not be silently promoted.

For this paper, the operative object is `Causal Links And Obligation Ledgers`. Its safe consumption
rule is:

```text
source object -> declared operation -> receipt/lane -> downstream import
```

The unsafe consumption rule is:

```text
source phrase -> downstream identity claim
```

That second pattern is explicitly rejected by FLCR-01 and must be rewritten as
a claim-lane promotion with evidence.

## 7. Evidence And Receipts

| Evidence source | What it contributes |
|-----------------|---------------------|
| Paper 06 legacy body | Causal link and obligation ledger, Rule90/Lucas decomposition route. |
| Internal supplement 06 | Proof graph, Merkle DAG, dependency-resolution, negative-result framing. |
| NSIT tool matrix | Rule90/Lucas decomposition receipt closes internal correction core; standards tools close graph requirements. |
| CAM Claim 100 Score Audit | Paper 06 scored 92 as system-composition closeable. |

## Resolved-State Closure Pass

This pass removes false restrictions on the paper's claim posture. A row is no longer called open merely because a stronger future claim exists. The satisfied lane is closed now; only the stronger claim that lacks its required adapter, comparator, calibration, or falsifier remains as residue.

### Closed Now

| Row | Lane | Resolved state | Remaining boundary |
|---|---|---|---|
| paper lift enumeration | `receipt_bound_internal_result` | 8/8 LCR states succeeded; error walls=0; avg TarPit mass=0.509294. | This closes the paper-local finite lift readout, not every stronger physical interpretation. |
| causal ledger | `normal_form_result` | The causal/obligation ledger is closed as a dependency-preserving channel, not as an unresolved label. | The family closure is a structural lane; measured physics still requires destination-specific calibration. |
| decade-1 tower | `receipt_bound_internal_result` | The decade tower is resolved with avg TarPit mass=0.510370 and mass sum=40.829567. | The decade total is an internal tower metric, not a standalone universal physical constant. |
| family-07 cross-lift comparison | `cam_crystal_reapplication_result` | Family tower binds FLCR-07, FLCR-17, FLCR-27, FLCR-37; avg TarPit mass=0.507568; error walls=0. | Cross-lift agreement strengthens routing and comparison; it does not erase paper-local boundaries. |
| obligation ledger | `normal_form_result` | Open obligations are resolved as active channels from prestate to next evidence, not negative truth labels. | A channel closes only when its named evidence arrives. |

### Claim Posture After This Pass

`FLCR-07` should now be read as a resolved-state contribution for `Causal Links And Obligation Ledgers` at its declared lane. The paper may state the strongest claim supported by these rows directly. It should reserve caution only for a specifically named stronger claim whose required evidence is absent.

## 8. Dependencies And Downstream Use

This paper may be imported by later FLCR papers only through the claim lanes
above. The default downstream consumers are:

- `FLCR-11` through `FLCR-18` for window, receipt, admission, CA, algebraic,
  curvature, residue, and exceptional machinery.
- `FLCR-28` through `FLCR-30` for CAM/crystal, corpus ribbon, and universal
  normal-form intake.
- `FLCR-31` through `FLCR-40` only after the LCR-native result has been cited
  and the translation claim has its own evidence lane.

## 9. Limitations And Falsifiers

- A graph edge is not automatically proof; its edge type controls consumption.
- A failed route remains failed only for its tested scope.
- Full 32-paper graph population remains a later lockfile task.

A falsifier for this paper is any example that satisfies the declared input
conditions while violating the stated construction, receipt, or lane boundary.
An interpretation that merely wants a stronger downstream conclusion is not a
falsifier; it is an obligation routed to a later paper.

## 10. Publication Readiness Tasks

- Validator identities and receipt hashes are recorded in the manifest or receipt appendix.
- External theorems require final citation entries before journal submission.
- Every theorem, proposition, and protocol must retain a claim lane and evidence boundary.
- The Markdown, LaTeX, and PDF forms are generated from the same canonical source.

## Dual Positioning: Story And Formal Carrier

This paper must be read in two synchronized ways. Sequentially, it explains why
the next state exists in the corpus story. Formally, it binds that state to
accepted mathematics, IRL formalism, code receipts, validators, CAM/crystal
lookups, and claim-lane boundaries.

Assigned original ribbon role(s): `06`/ledger_action.

| Original slot | Family | Lift | Role | Proof form |
|---|---|---:|---|---|
| `06` | ledger_action | 0 | order-1 slot-6: bind state into causal, observer, or synchronization ledgers | ledger, graph, and synchronization proof |

The formal obligation is to state the strongest valid claim available for this
paper without letting interpretation silently change the addressed object. Any
author interpretation belongs beside the formalism as a declared relabeling,
bridge, or analog, and must be accompanied by the evidence lane that makes the
claim consumable by later papers.

## State-Bound Proof Contract

This paper receives: state emitted by prior slot 05 and reopened at original slot 06 (Causal Link and Obligation Ledger).

It must produce: formal result of original slot 06 plus the same-family lift path toward slot 16.

Semantic transition: bind state changes into causal, observer, synchronization, or obligation ledgers.

Accepted formalism targets to bind in the journal rewrite:

- directed graphs and partial orders
- causal/event ledgers
- synchronization protocols
- traceability and provenance invariants

| Slot | Family | Lift | Produced proof form |
|---|---|---:|---|
| `06` | ledger_action | 0 | ledger, graph, and synchronization proof |

The formal carrier uses these accepted tools while preserving interpretive
claims as explicit relabelings, correspondences, or bridges. Claim promotion is admissible only when a receipt, standard citation,
CAM/crystal reapplication, normal-form result, calibration datum, or falsifier
boundary is attached.

## Provenance And Crystal Evidence Integration

This section integrates prior work, CAM/crystal projections, NSIT tooling,
standards-window evidence, and routed supplements as provenance-bearing
evidence. Source material is not treated as manuscript text; it is bound into
the paper only through claim lanes, receipts, validators, normal forms,
calibration rows, or explicit falsifier boundaries.

### Expansion Rule For This Slot

Use past work to turn obligations into graph rows: event, observer, dependency, validator, falsifier, and next lane.

### Primary Evidence Inputs

| Source | Placement reason |
|---|---|
| `06_Causal_Link_and_Obligation_Ledger.md` | primary assigned source for the paper's formal spine |
| `supplements/06_INTERNAL_REASONING_SUPPLEMENT.md` | paper-local reasoning supplement contributing to definitions, proof sketch, and limitations |

### Secondary And Orbital Evidence Inputs

| Source | Placement reason |
|---|---|
| `supplements/OBLIGATION_LEDGER_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/RECEIPT_VERIFIER_CATALOG.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/LATTICE_FORGE_UNIFICATION_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_PYRAMID_INDEX.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_5P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_7P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_9P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `CAM_CLAIM_100_SCORE_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_TOOL_CLOSURE_MATRIX.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_REASONED_CLOSURE_PASS.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `ORBITAL_DATA_CROSS_POPULATION_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `AGENT_CRYSTAL_WORK_HARVEST.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| Additional source routes | Complete routing is maintained in the source-placement appendix |

### Crystal And Standards Evidence To Bind

- Paper Reworks crystal projection: 33 paper markdown files, 9 supplements, 5 queues, 6 lattice-forge unification artifacts, 140 faces, 140 vignettes, and 280 CAM nodes.
- Standards-window intake: 192/192 corpus conformance verdicts PASS; 140/142 obligations have candidate routes; 2/4/8/16/32 window lattice is available for cross-paper reads.
- Agent/crystal harvest: agent-generated memory, runtime standards starter, current runtime build, repo-harvest CAM, notebook-derived bundles, and downloaded crystal payloads are orbital evidence surfaces.
- NSIT inventory baseline: 220 validators, 1786 receipt/data artifacts, 1137 formal-paper-like artifacts, 114 supplements, and 86 memory/CAM artifacts.

### Paper-Specific CAM/Score Rows

| 06 | 92 | system-composition closeable | typed causal edges, Rule90/Lucas, triadic keystone, negative extraction verdict | full 32-paper graph/hash population |

### Paper-Specific NSIT Closure Rows

| O2-prime verifiable core: Rule30 = Rule90 plus correction, Lucas closed form, depth-N decomposition | individual_tool_closure | `lattice_forge/rule90_linearization.py` | Paper 06 | `rule90_lucas_decomposition_receipt.json` 7/7 | Internal correction core closes; unbounded McKay collapse remains separate. |

### Source Integration Summary

The legacy source and internal reasoning supplement are treated as source
evidence rather than manuscript prose. Their contributions enter this paper as
claim-lane entries, receipt or validator references, finite-domain statements,
and limitation boundaries. Speculative or cross-domain interpretations remain
separate from closed local results until an explicit adapter, citation,
normal-form derivation, calibration row, or falsifier is attached.
## Claim Binding Queue

This queue records the evidence discipline for claim strengthening. It separates claims that already have support from residues that remain in falsifier or open-obligation lanes.

| Queue | Lane | Promote now | Bind next | Residue |
|---|---|---|---|---|
| Formal-Methods Receipt And Governance Closure | `normal_form_result` | Promote claim-envelope, receipt, lane, causal-graph, and conformance obligations as formal-methods artifacts when standards reports are attached. | Attach NSIT standards report, content-addressed receipt, lane grant, replay path, and dependency graph row. | Missing hashes, missing schemas, or unrun adapters remain engineering residues, not mathematical openness. |
| Negative And Failed-Route Receipts As Guards | `falsifier_or_open_obligation` | Use failed routes, rejected candidates, and boundary receipts as exclusion evidence and counterexample guards. | Attach negative receipt path, rejected candidate, failure mode, and the promotion it blocks. | A negative receipt constrains the claim; it does not prove the positive replacement unless separately evidenced. |

### Binding Discipline

Each queue item is represented as a delta:

```text
local claim at paper time
-> attached later source/tool/receipt/theorem
-> revised representation
-> invariant boundary and remaining residue
```

This preserves the sequential story while allowing later tools, crystals, and
standard formalisms to return through the proper lane.

## Claim Delta Ledger

This ledger applies the paper's claim-binding queues as explicit back-application
deltas. It keeps the sequential paper story intact while allowing later
receipts, standard formalisms, CAM/crystal routes, and validators to sharpen the
claim.

| Delta | Local claim at paper time | Later evidence | Revised representation | Boundary kept |
|---|---|---|---|---|
| Formal Methods Receipt Closure | This paper may treat receipts, claim lanes, dependency graphs, and replay contracts as formal objects, not mere editorial apparatus. | NSIT standards, claim envelopes, content-addressed receipts, lane grants, standards-window 192/192 conformance, and graph/replay artifacts. | Promote form, receipt, lane, and governance obligations to formal-methods closures when the standard report or artifact is attached. | Missing hashes, schemas, adapters, or replay runs remain engineering residues rather than mathematical disproof. |
| Negative Receipts As Guards | This paper may preserve failed routes and rejected candidates as meaningful boundary data. | Negative receipts, failed verifier rows, rejected-as-datum outputs, and obligation ledgers. | Use negative receipts as exclusion evidence and promotion guards. | A negative receipt blocks a promotion; it does not prove a positive replacement unless separately evidenced. |

The revised representation records the strongest claim supported by the current evidence package. Promotion into theorem or proposition language occurs only when the named evidence is attached in the manifest or workbook replay.

## Source-Backed Evidence Summary

Routed archive and mirror cards are treated as provenance summaries rather than
body text. They identify candidate receipts, validators, theorem registries, or
supplemental source routes. A card strengthens this paper only when its
contribution is bound to a claim lane, evidence object, and boundary.

| Evidence card | Score | Publication contribution | Boundary |
|---|---:|---|---|
| SUMMARY-IX-Open-Obligations: Summary Paper IX — The Open Obligations: The 2×2 Failure Points and the Empirical Platform Diagnostic System | 79 | This paper is the **complete open obligations manifest** of the CQE_CMPLX corpus. The corpus is honest about what is and isn't proven. The framework for this honesty is the **empirical platform diagnostic system** — a... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| FORMAL: Paper 11 — C-Form: Theory Admission Gate Gluon | 77 | **C = the admission filter Gluon** — the trust anchor that filters external theories by Gluon mass matching. In the lattice_forge substrate, C is realized as the **admission gate** that: - Takes an external theory's G... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| CQE-paper-06.50: Paper 6.50 - Causal Code Claim Contract | 77 | Paper 6.50 lets later papers import causal code honestly. It keeps the graph useful as proof infrastructure without allowing open or circular support to be mistaken for closure. | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| FINAL_FORMAL_PAPER: Complete Formal Claims: The Folded Strand | 75 | We present the complete closed-form claim set of the CQE_CMPLX corpus: - 33 papers = 33 folding operations on a self-complementary strand - 144 tools = cumulative analog kit = digital twin surface - 135 digital twins ... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| COMPLETE_RECURSIVE_CLOSURE_MAP: CQECMPLX — COMPLETE RECURSIVE LIGHT-CONE CLOSURE OF ALL 33 PAPERS | 75 | **The CQECMPLX suite has zero genuine open obligations.** Every "open" item is a boundary error that locally re-invokes the Nth-bit request (light-cone decomposition) using the exact same methods encoded in the lib. T... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| Additional evidence cards | 54 total | The complete card inventory is maintained in the archive evidence matrix. | Cards are source-discovery aids until bound to paper-local evidence. |

## Journal Apparatus

### Article Type And Intended Venue Fit

This manuscript is written as a formal-methods and mathematical-systems paper
inside the series *Formalizing LCR, Unifying Standard Models*. Its intended
reader is a technical reviewer who needs claim boundaries, reproducibility
routes, and cross-paper dependencies to be visible without relying on private
context.

### Structured Contribution Statement

| Item | Statement |
|---|---|
| Publication ID | `FLCR-07` |
| Legacy source slot(s) | `06` |
| Ribbon role | order-1 slot-6: bind state into causal, observer, or synchronization ledgers |
| Proof form | ledger, graph, and synchronization proof |
| Received state | state emitted by prior slot 05 and reopened at original slot 06 (Causal Link and Obligation Ledger) |
| Produced state | formal result of original slot 06 plus the same-family lift path toward slot 16 |

### Claim-Evidence Table

| Claim | Lane | Evidence to attach | Boundary |
|---|---|---|---|
| Theorem 7.1 | `normal_form_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | A valid FLCR causal graph must type its edges before they can be consumed by paper claims. |
| Proposition 7.2 | `receipt_bound_internal_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | Negative extraction verdicts reduce future search space and therefore belong in the ledger. |
| Protocol 7.3 | `falsifier_or_open_obligation` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | Obligation edges may route future work but cannot serve as proof-support edges without promotion. |

### Figure Plan

| Figure | Purpose | Caption |
|---|---|---|
| FLCR-07-F1 | Causal/obligation ledger graph | Schematic showing how `FLCR-07` turns its received state into the produced state while preserving claim lanes and residue boundaries. |
| FLCR-07-F2 | Evidence routing map | Diagram of source papers, archive cards, CAM/crystal routes, validators, and workbook replay paths used by this manuscript. |
| FLCR-07-F3 | Same-family lift context | Diagram placing this paper in the original `00-79` ribbon family and showing predecessor/successor slots. |

### In-Text Figure FLCR-07-F1: Causal/obligation ledger graph

```text
received state
  -> Causal/obligation ledger graph
  -> formal claim lane
  -> evidence object / receipt / citation
  -> produced state
  -> remaining residue
```

### Table Plan

| Table | Purpose |
|---|---|
| FLCR-07-T1 | Obligation ledger table |
| FLCR-07-T2 | Claim-lane/evidence-boundary table |
| FLCR-07-T3 | Archive evidence card and source-backed upgrade table |
| FLCR-07-T4 | Workbook replay and falsifier table |

### Worked Example

Convert one obligation into event, dependency, validator, and downstream route rows. The example must name the input object, the operation,
the evidence object, the allowed revised claim, and the remaining boundary.

### Nomenclature And Glossary

| Term | Paper-local meaning |
|---|---|
| CAM | Defined by this paper as part of the `ledger_action` proof role; final definition is recorded in the paper-local glossary. |
| causal edge | Defined by this paper as part of the `ledger_action` proof role; final definition is recorded in the paper-local glossary. |
| claim lane | Defined by this paper as part of the `ledger_action` proof role; final definition is recorded in the paper-local glossary. |
| crystal | Defined by this paper as part of the `ledger_action` proof role; final definition is recorded in the paper-local glossary. |
| ledger | Defined by this paper as part of the `ledger_action` proof role; final definition is recorded in the paper-local glossary. |
| negative receipt | Defined by this paper as part of the `ledger_action` proof role; final definition is recorded in the paper-local glossary. |
| obligation | Defined by this paper as part of the `ledger_action` proof role; final definition is recorded in the paper-local glossary. |
| receipt | Defined by this paper as part of the `ledger_action` proof role; final definition is recorded in the paper-local glossary. |

### Appendix FLCR-07-A: Evidence Package

The appendix records:

1. Legacy source excerpts or source-card references used in the final claim ledger.
2. Receipt and verifier paths, including pass/fail/partial status.
3. CAM/crystal query or projection rows used by the paper, with source identity and boundary.
4. Standards-window and NSIT evidence used for conformance or routing.
5. Falsifier, calibration, or external-data rows that remain unresolved.

### Data And Code Availability

The publication package contains the canonical Markdown sources, manifests, source-routing matrices, validation reports, and generated PDF/TeX outputs.

Code and verifier references are cited through manifests, archive evidence cards, receipt catalogs, or workbook replay tables. External datasets or
standards citations must be attached before any calibration-bound claim is
promoted.

### Reviewer Checklist

| Check | Reviewer question |
|---|---|
| Claim lane | Does every strong claim declare its lane and evidence type? |
| Boundary | Does the paper preserve what it does not prove? |
| Reproducibility | Is there a receipt, verifier, source card, citation, or replay table for the claim? |
| Cross-paper import | Does the paper cite the prior FLCR/OPR slot before consuming its result? |
| Interpretation | Does the analog layer preserve the addressed state while changing labels/access paths? |

### Declarations

No human-subjects, clinical, or animal-research protocol is asserted by this
paper. External empirical claims require separate dataset, calibration, or
domain-validation attachments. Competing-interest and funding statements are recorded in the submission metadata.

## 11. Publication Integration Addendum

### 11.1 Role In The Series

`FLCR-07` (`Causal Links And Obligation Ledgers`) occupies the `ledger_action` role at lift depth `0`.
The paper receives state emitted by prior slot 05 and reopened at original slot 06 (Causal Link and Obligation Ledger). It produces formal result of original slot 06 plus the same-family lift path toward slot 16. The state transition is:
bind state changes into causal, observer, synchronization, or obligation ledgers.

The paper-local proof form is:

```text
ledger, graph, and synchronization proof
```

The integration result is a causal ledger that preserves dependency, synchronization, and obligation history. This addendum records how that result is
consumed by the publication series without relying on editorial instructions or
private working context.

### 11.2 Formal Carrier

| Formal carrier | Function |
|---|---|
| directed graphs and partial orders | Formal carrier for the paper-local result. |
| causal/event ledgers | Formal carrier for the paper-local result. |
| synchronization protocols | Formal carrier for the paper-local result. |
| traceability and provenance invariants | Formal carrier for the paper-local result. |

The LCR, CAM, crystal, forge, and analog vocabulary functions as a typed access
layer over these carriers. A relabeling is admissible only when the addressed
object, evidence lane, boundary, and downstream import rule remain attached.

### 11.3 Claim Ledger

| Claim | Lane | Statement |
|---|---|---|
| Theorem 7.1 | `normal_form_result` | A valid FLCR causal graph must type its edges before they can be consumed by paper claims. |
| Proposition 7.2 | `receipt_bound_internal_result` | Negative extraction verdicts reduce future search space and therefore belong in the ledger. |
| Protocol 7.3 | `falsifier_or_open_obligation` | Obligation edges may route future work but cannot serve as proof-support edges without promotion. |

These claims are consumed at their stated lane. A stronger downstream statement
creates a new claim envelope with its own evidence object.

### 11.4 Evidence Package

| Evidence class | Routed items | Status |
|---|---|---|
| Legacy sources | `06_Causal_Link_and_Obligation_Ledger.md`, `supplements/06_INTERNAL_REASONING_SUPPLEMENT.md` | routed evidence |
| Evidence inputs | `CAM_CLAIM_100_SCORE_AUDIT.md`, `NSIT_TOOL_CLOSURE_MATRIX.md`, `NSIT_REASONED_CLOSURE_PASS.md`, `PAPER_REWORKS_CRYSTAL_PROJECTION.json` | routed evidence |
| CAM/crystal sources | `PAPER_REWORKS_CRYSTAL_PROJECTION.json`, `AGENT_CRYSTAL_WORK_HARVEST.json`, `runtime standards artifact`, `notebook-derived source bundle` | routed evidence |
| Standards-window inputs | `window_summary.json`, `node DBs`, `window DBs` | routed evidence |
| Receipts | external requirement | not attached in this source package |
| Validators | external requirement | not attached in this source package |

Standards-window, runtime, and notebook-derived artifacts are treated
as evidence-routing surfaces. They support source discovery, conformance
checking, and reapplication, but they do not replace citations, receipts,
normal-form derivations, calibration rows, or falsifiers.

### 11.5 Results Representation

The paper's results section is organized around five publication objects:

1. the exact object acted on at this slot;
2. the admissible operation or transformation;
3. the receipt, enumeration, derivation, lookup, or external theorem supporting
   the operation;
4. the residue or boundary left after the result;
5. the downstream import rule.

### 11.6 Figures And Tables

| Figure | Role |
|---|---|
| FLCR-07-F1: Causal/obligation ledger graph | Visualizes the proof object, routing, or boundary. |
| FLCR-07-F2: Evidence routing map | Visualizes the proof object, routing, or boundary. |
| FLCR-07-F3: Same-family lift context | Visualizes the proof object, routing, or boundary. |

| Table | Role |
|---|---|
| FLCR-07-T1: Obligation ledger table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-07-T2: Claim-lane/evidence-boundary table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-07-T3: Archive evidence card and source-backed upgrade table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-07-T4: Workbook replay and falsifier table | Records claim lanes, evidence, sources, or falsifiers. |

### 11.7 Limits And Falsifiers

The paper proves only the object and domain declared in its claim ledger.
Physical, Standard Model, observer, calibration, or synthesis claims require
the additional lane evidence stated by their destination papers. CAM/crystal
and forge language is operational only when represented as an address, lookup,
receipt, validator, or reapplication path.
