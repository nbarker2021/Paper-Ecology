# FLCR-22 - Protein Descriptor And Fold-Facing Kernel

**Series:** Formalizing LCR, Unifying Standard Models  
**Artifact:** formal paper source  
**Status:** first-pass rich rewrite; requires final citation and build pass.  
**Claim posture:** maximal local claim posture with explicit lane boundaries.

## Abstract

This paper formalizes protein fold descriptors as an applied LCR-facing kernel. The operative object is fold descriptor kernel. The core result is that contact, homology, and winding descriptors can be staged as internal addressable features before biological validation. The paper also defines how this result routes forward: applied biology workbooks may consume descriptors only with PDB/parser and benchmark receipts. Its main residue is explicit: native-structure prediction, fold-rate validation, and biological performance remain below full closure until datasets bind.

## Keywords

fold descriptor kernel; LCR; receipt; claim lane; normal form.

## 1. Contribution And Scope

- Defines fold descriptor kernel as a first-class FLCR object.
- States the local result: contact, homology, and winding descriptors can be staged as internal addressable features before biological validation.
- Routes downstream use through claim lanes rather than inherited prose: applied biology workbooks may consume descriptors only with PDB/parser and benchmark receipts.
- Preserves the residue boundary: native-structure prediction, fold-rate validation, and biological performance remain below full closure until datasets bind.

This paper is part of the LCR-native base layer. Standard Model or physical
language is permitted only as deferred mapping, analogy, or explicitly bounded
future calibration. The editable surface is the claim lane and source-routing
layer; the base objects must remain stable enough for downstream papers to
consume them without ambiguity.

## 2. Source Routing

Primary routed sources:

- `23_FoldForge_Protein_Folding.md`
- `virtuous/23_FoldForge_Protein_Folding_VIRTUOUS.md`
- `supplements/23_INTERNAL_REASONING_SUPPLEMENT.md`

Cross-corpus evidence classes:

- `CAM_CLAIM_100_SCORE_AUDIT.md`
- `NSIT_TOOL_CLOSURE_MATRIX.md`
- `NSIT_REASONED_CLOSURE_PASS.md`
- `PAPER_REWORKS_CRYSTAL_PROJECTION.json`
- standards, glue, window, and node databases where applicable
- notebook-derived review prompts and orbital source manifests

## 3. Definitions

- **Fold descriptor.** A protein-facing feature row derived from the applied forge reader.
- **Native-structure boundary.** The external validation gate for real protein structure claims.
- **Receipt boundary.** The exact scope in which the paper's result can be replayed or consumed.
- **Promotion route.** The evidence path required before a stronger downstream claim can use this result.

## 4. Formal Claims

| Claim | Lane | Statement |
|-------|------|-----------|
| Theorem 22.1 | `normal_form_result` | contact, homology, and winding descriptors can be staged as internal addressable features before biological validation |
| Proposition 22.2 | `normal_form_result` | fold descriptor kernel can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 22.3 | `falsifier_or_open_obligation` | native-structure prediction, fold-rate validation, and biological performance remain below full closure until datasets bind |

## 5. Paper-Specific Development

1. Identify the local object and its assigned sources for FLCR-22.
2. Separate what is internally receipt-bound from what is citation-bound, CAM-bound, calibration-bound, or still an obligation.
3. State the strongest admissible claim in its current lane.
4. Export only the lane-safe result to downstream papers and preserve the residue.

### Proof Sketch

The proof strategy for FLCR-22 is a typed construction argument. The paper names fold descriptor as the active object, binds it to the routed legacy and orbital sources, and then allows downstream use only through the declared claim lane. This does not erase stronger ambitions; it keeps them addressable as dependencies, calibration tasks, or falsifiers.

## 6. Construction

The construction is intentionally staged. First, the paper names the finite or
typed object that can be inspected directly. Second, it declares the admissible
operations over that object. Third, it records the receipt or source class that
allows another paper to consume the result. Fourth, it names the residue that
must not be silently promoted.

For this paper, the operative object is `Protein Descriptor And Fold-Facing Kernel`. Its safe consumption
rule is:

```text
source object -> declared operation -> receipt/lane -> downstream import
```

The unsafe consumption rule is:

```text
source phrase -> downstream identity claim
```

That second pattern is explicitly rejected by FLCR-01 and must be rewritten as
a claim-lane promotion with evidence.

## 7. Evidence And Receipts

| Evidence source | What it contributes |
|-----------------|---------------------|
| Legacy paper body | Primary formal and source-integration material assigned by the series map. |
| Internal and pyramid supplements | Cross-paper reasoning windows, deferred back-application slots, and route constraints. |
| NSIT tool closure matrix | Existing verifier/tool families that can close internal or batch claims. |
| CAM/crystal and standards-window evidence | Projected memory, source routing, standards reports, and window/node databases. |

## Resolved-State Closure Pass

This pass removes false restrictions on the paper's claim posture. A row is no longer called open merely because a stronger future claim exists. The satisfied lane is closed now; only the stronger claim that lacks its required adapter, comparator, calibration, or falsifier remains as residue.

### Closed Now

| Row | Lane | Resolved state | Remaining boundary |
|---|---|---|---|
| paper lift enumeration | `receipt_bound_internal_result` | 8/8 LCR states succeeded; error walls=0; avg TarPit mass=0.507121. | This closes the paper-local finite lift readout, not every stronger physical interpretation. |
| carrier enumeration | `normal_form_result` | The LCR carrier action is closed as an addressable finite-state surface for its declared domain. | The family closure is a structural lane; measured physics still requires destination-specific calibration. |
| decade-3 tower | `receipt_bound_internal_result` | The decade tower is resolved with avg TarPit mass=0.509294 and mass sum=40.743500. | The decade total is an internal tower metric, not a standalone universal physical constant. |
| family-02 cross-lift comparison | `cam_crystal_reapplication_result` | Family tower binds FLCR-02, FLCR-12, FLCR-22, FLCR-32; avg TarPit mass=0.511700; error walls=0. | Cross-lift agreement strengthens routing and comparison; it does not erase paper-local boundaries. |
| protein descriptor kernel | `normal_form_result` | Protein descriptor and fold-facing state are closed as descriptor surfaces. | Biophysical folding accuracy requires benchmark data. |

### Claim Posture After This Pass

`FLCR-22` should now be read as a resolved-state contribution for `Protein Descriptor And Fold-Facing Kernel` at its declared lane. The paper may state the strongest claim supported by these rows directly. It should reserve caution only for a specifically named stronger claim whose required evidence is absent.

## 8. Dependencies And Downstream Use

This paper may be imported by later FLCR papers only through the claim lanes
above. The default downstream consumers are:

- `FLCR-11` through `FLCR-18` for window, receipt, admission, CA, algebraic,
  curvature, residue, and exceptional machinery.
- `FLCR-28` through `FLCR-30` for CAM/crystal, corpus ribbon, and universal
  normal-form intake.
- `FLCR-31` through `FLCR-40` only after the LCR-native result has been cited
  and the translation claim has its own evidence lane.

## 9. Limitations And Falsifiers

- native-structure prediction, fold-rate validation, and biological performance remain below full closure until datasets bind
- External calibration claims require units, datasets, citations, and reproducible data binding.
- A later translation paper may strengthen this result only by adding the missing lane evidence.

A falsifier for this paper is any example that satisfies the declared input
conditions while violating the stated construction, receipt, or lane boundary.
An interpretation that merely wants a stronger downstream conclusion is not a
falsifier; it is an obligation routed to a later paper.

## 10. Publication Readiness Tasks

- Validator identities and receipt hashes are recorded in the manifest or receipt appendix.
- External theorems require final citation entries before journal submission.
- Every theorem, proposition, and protocol must retain a claim lane and evidence boundary.
- The Markdown, LaTeX, and PDF forms are generated from the same canonical source.

## Dual Positioning: Story And Formal Carrier

This paper must be read in two synchronized ways. Sequentially, it explains why
the next state exists in the corpus story. Formally, it binds that state to
accepted mathematics, IRL formalism, code receipts, validators, CAM/crystal
lookups, and claim-lane boundaries.

Assigned original ribbon role(s): `23`/fold_action.

| Original slot | Family | Lift | Role | Proof form |
|---|---|---:|---|---|
| `23` | fold_action | 2 | order-3 slot-3: fold the initial action into a higher-dimensional representation | fold map, coordinate atlas, and representation transport |

The formal obligation is to state the strongest valid claim available for this
paper without letting interpretation silently change the addressed object. Any
author interpretation belongs beside the formalism as a declared relabeling,
bridge, or analog, and must be accompanied by the evidence lane that makes the
claim consumable by later papers.

## State-Bound Proof Contract

This paper receives: state emitted by prior slot 22 and reopened at original slot 23 (FoldForge Protein Folding).

It must produce: formal result of original slot 23 plus the same-family lift path toward slot 33.

Semantic transition: fold the local state into a higher representation while preserving addressability.

Accepted formalism targets to bind in the journal rewrite:

- representation theory
- group actions and equivariance
- tensor or coordinate atlases
- transport maps between equivalent descriptions

| Slot | Family | Lift | Produced proof form |
|---|---|---:|---|
| `23` | fold_action | 2 | fold map, coordinate atlas, and representation transport |

The formal carrier uses these accepted tools while preserving interpretive
claims as explicit relabelings, correspondences, or bridges. Claim promotion is admissible only when a receipt, standard citation,
CAM/crystal reapplication, normal-form result, calibration datum, or falsifier
boundary is attached.

## Provenance And Crystal Evidence Integration

This section integrates prior work, CAM/crystal projections, NSIT tooling,
standards-window evidence, and routed supplements as provenance-bearing
evidence. Source material is not treated as manuscript text; it is bound into
the paper only through claim lanes, receipts, validators, normal forms,
calibration rows, or explicit falsifier boundaries.

### Expansion Rule For This Slot

Use past work to strengthen representation transport: every face, gauge, atlas, or fold label must point to a preserved source object.

### Primary Evidence Inputs

| Source | Placement reason |
|---|---|
| `23_FoldForge_Protein_Folding.md` | primary assigned source for the paper's formal spine |
| `supplements/23_INTERNAL_REASONING_SUPPLEMENT.md` | paper-local reasoning supplement contributing to definitions, proof sketch, and limitations |
| `virtuous\23_FoldForge_Protein_Folding_VIRTUOUS.md` | prior enriched paper body; should be mined for mature claims and proof ordering |

### Secondary And Orbital Evidence Inputs

| Source | Placement reason |
|---|---|
| `supplements/METAFORGE_MATERIALS_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/RECEIPT_VERIFIER_CATALOG.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/APPLIED_FORGES_WORKBOOK.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_PYRAMID_INDEX.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_5P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_7P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `supplements/INTERNAL_REASONING_9P_WINDOW_SUPPLEMENT.md` | cross-cutting supplement; paper-relevant rows, receipts, and guard language are bound through evidence lanes |
| `CAM_CLAIM_100_SCORE_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_TOOL_CLOSURE_MATRIX.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `NSIT_REASONED_CLOSURE_PASS.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `ORBITAL_DATA_CROSS_POPULATION_AUDIT.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| `AGENT_CRYSTAL_WORK_HARVEST.md` | series-wide audit/score/closure evidence; import paper-specific rows and leave global context outside the body |
| Additional source routes | Complete routing is maintained in the source-placement appendix |

### Crystal And Standards Evidence To Bind

- Paper Reworks crystal projection: 33 paper markdown files, 9 supplements, 5 queues, 6 lattice-forge unification artifacts, 140 faces, 140 vignettes, and 280 CAM nodes.
- Standards-window intake: 192/192 corpus conformance verdicts PASS; 140/142 obligations have candidate routes; 2/4/8/16/32 window lattice is available for cross-paper reads.
- Agent/crystal harvest: agent-generated memory, runtime standards starter, current runtime build, repo-harvest CAM, notebook-derived bundles, and downloaded crystal payloads are orbital evidence surfaces.
- NSIT inventory baseline: 220 validators, 1786 receipt/data artifacts, 1137 formal-paper-like artifacts, 114 supplements, and 86 memory/CAM artifacts.

### Paper-Specific CAM/Score Rows

| 23 | 74 | applied partial closure | FoldForge contact/homology/winding framing, parser route, applied forge validation lane | PDB/native structure parser and fold-rate validation |

### Paper-Specific NSIT Closure Rows

No direct NSIT row matched the assigned legacy papers in the first-pass matrix; validator matching by object name remains a receipt-attachment requirement.

### Source Integration Summary

The legacy source and internal reasoning supplement are treated as source
evidence rather than manuscript prose. Their contributions enter this paper as
claim-lane entries, receipt or validator references, finite-domain statements,
and limitation boundaries. Speculative or cross-domain interpretations remain
separate from closed local results until an explicit adapter, citation,
normal-form derivation, calibration row, or falsifier is attached.
## Claim Binding Queue

This queue records the evidence discipline for claim strengthening. It separates claims that already have support from residues that remain in falsifier or open-obligation lanes.

| Queue | Lane | Promote now | Bind next | Residue |
|---|---|---|---|---|
| Applied Forge Internal/External Validation Split | `receipt_bound_internal_result` | Promote internal forge reader, descriptor, candidate-generation, and finite validation kernels when validators pass. | Attach forge tool path, input object, output descriptor/candidate, validator result, and explicit external-validation boundary. | Wet-lab, fabrication, biological, gameplay-global, or real-world optimization claims remain external-validation needs. |

### Binding Discipline

Each queue item is represented as a delta:

```text
local claim at paper time
-> attached later source/tool/receipt/theorem
-> revised representation
-> invariant boundary and remaining residue
```

This preserves the sequential story while allowing later tools, crystals, and
standard formalisms to return through the proper lane.

## Claim Delta Ledger

This ledger applies the paper's claim-binding queues as explicit back-application
deltas. It keeps the sequential paper story intact while allowing later
receipts, standard formalisms, CAM/crystal routes, and validators to sharpen the
claim.

| Delta | Local claim at paper time | Later evidence | Revised representation | Boundary kept |
|---|---|---|---|---|
| Applied Forge Internal External Split | This paper may claim an internal forge reader/generator/descriptor kernel where the tool produces replayable internal outputs. | Forge validators, applied-forge workbooks, material/protein/game receipts, CAM addresses, and source-routing rows. | Promote internal representation/generation kernels when validators pass, while routing real-world validation separately. | Fabrication, wet-lab, biological, gameplay-global, manufacturing, or measured optimization claims remain external-validation needs. |

The revised representation records the strongest claim supported by the current evidence package. Promotion into theorem or proposition language occurs only when the named evidence is attached in the manifest or workbook replay.

## Source-Backed Evidence Summary

Routed archive and mirror cards are treated as provenance summaries rather than
body text. They identify candidate receipts, validators, theorem registries, or
supplemental source routes. A card strengthens this paper only when its
contribution is bound to a claim lane, evidence object, and boundary.

| Evidence card | Score | Publication contribution | Boundary |
|---|---:|---|---|
| FORMAL: Paper 23 — C-Form: FoldForge Protein Folding Gluon | 89 | **C = the protein fold Gluon** — the contact-map/topo Gluon that transports protein chain fold hypotheses through contact-map and topology receipts. In the lattice_forge substrate, C is realized as the **fold Gluon** ... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| FORMAL: Paper 22 — C-Form: MetaForge Applied Materials Gluon | 85 | **C = the material Gluon** — the applied materials Gluon that transports the morphic Gluon (Paper 21) into physical material candidates. In the lattice_forge substrate, C is realized as the **material Gluon** that: - ... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| SUMMARY-III-Computational-Substrates: Summary Paper III — Computational Substrates: The Gluon as Fold, Knight, Traversal, Pinch, Delay, Game, Monster | 83 | This paper presents the **computational substrate applications** of the Gluon formalism. We do not use the word "Gluon" because the fit is good. We use it because the substrate **IS** SU(3), and the computational subs... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| FORMAL: Paper 25 — C-Form: Energetic Traversal Maps Gluon | 81 | **C = the traversal energy Gluon** — the energy/ledger Gluon that adds energy and traversal costs to cross-language, figure, material, and fold transformations. In the lattice_forge substrate, C is realized as the **t... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| CQE-paper-22.75: Paper 22.75 - MetaForge Next-State Bridge | 81 | Paper 22 exports a candidate-ledger pattern to the next applied papers. The pattern is: choose a domain inventory, score admissible partners or transforms, run the finite candidate transport, preserve failures as obli... | Source-backed support; promotion requires the paper-local claim lane and evidence boundary. |
| Additional evidence cards | 18 total | The complete card inventory is maintained in the archive evidence matrix. | Cards are source-discovery aids until bound to paper-local evidence. |

## Journal Apparatus

### Article Type And Intended Venue Fit

This manuscript is written as a formal-methods and mathematical-systems paper
inside the series *Formalizing LCR, Unifying Standard Models*. Its intended
reader is a technical reviewer who needs claim boundaries, reproducibility
routes, and cross-paper dependencies to be visible without relying on private
context.

### Structured Contribution Statement

| Item | Statement |
|---|---|
| Publication ID | `FLCR-22` |
| Legacy source slot(s) | `23` |
| Ribbon role | order-3 slot-3: fold the initial action into a higher-dimensional representation |
| Proof form | fold map, coordinate atlas, and representation transport |
| Received state | state emitted by prior slot 22 and reopened at original slot 23 (FoldForge Protein Folding) |
| Produced state | formal result of original slot 23 plus the same-family lift path toward slot 33 |

### Claim-Evidence Table

| Claim | Lane | Evidence to attach | Boundary |
|---|---|---|---|
| Theorem 22.1 | `normal_form_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | contact, homology, and winding descriptors can be staged as internal addressable features before biological validation |
| Proposition 22.2 | `normal_form_result` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | fold descriptor kernel can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 22.3 | `falsifier_or_open_obligation` | Receipt, source card, validator, citation, or CAM route named in the paper manifest | native-structure prediction, fold-rate validation, and biological performance remain below full closure until datasets bind |

### Figure Plan

| Figure | Purpose | Caption |
|---|---|---|
| FLCR-22-F1 | Representation fold atlas | Schematic showing how `FLCR-22` turns its received state into the produced state while preserving claim lanes and residue boundaries. |
| FLCR-22-F2 | Evidence routing map | Diagram of source papers, archive cards, CAM/crystal routes, validators, and workbook replay paths used by this manuscript. |
| FLCR-22-F3 | Same-family lift context | Diagram placing this paper in the original `00-79` ribbon family and showing predecessor/successor slots. |

### In-Text Figure FLCR-22-F1: Representation fold atlas

```text
received state
  -> Representation fold atlas
  -> formal claim lane
  -> evidence object / receipt / citation
  -> produced state
  -> remaining residue
```

### Table Plan

| Table | Purpose |
|---|---|
| FLCR-22-T1 | Face/representation correspondence table |
| FLCR-22-T2 | Claim-lane/evidence-boundary table |
| FLCR-22-T3 | Archive evidence card and source-backed upgrade table |
| FLCR-22-T4 | Workbook replay and falsifier table |

### Worked Example

Map one source object across two labels/faces while preserving its address. The example must name the input object, the operation,
the evidence object, the allowed revised claim, and the remaining boundary.

### Nomenclature And Glossary

| Term | Paper-local meaning |
|---|---|
| CAM | Defined by this paper as part of the `fold_action` proof role; final definition is recorded in the paper-local glossary. |
| atlas | Defined by this paper as part of the `fold_action` proof role; final definition is recorded in the paper-local glossary. |
| claim lane | Defined by this paper as part of the `fold_action` proof role; final definition is recorded in the paper-local glossary. |
| crystal | Defined by this paper as part of the `fold_action` proof role; final definition is recorded in the paper-local glossary. |
| face | Defined by this paper as part of the `fold_action` proof role; final definition is recorded in the paper-local glossary. |
| fold | Defined by this paper as part of the `fold_action` proof role; final definition is recorded in the paper-local glossary. |
| receipt | Defined by this paper as part of the `fold_action` proof role; final definition is recorded in the paper-local glossary. |
| representation transport | Defined by this paper as part of the `fold_action` proof role; final definition is recorded in the paper-local glossary. |

### Appendix FLCR-22-A: Evidence Package

The appendix records:

1. Legacy source excerpts or source-card references used in the final claim ledger.
2. Receipt and verifier paths, including pass/fail/partial status.
3. CAM/crystal query or projection rows used by the paper, with source identity and boundary.
4. Standards-window and NSIT evidence used for conformance or routing.
5. Falsifier, calibration, or external-data rows that remain unresolved.

### Data And Code Availability

The publication package contains the canonical Markdown sources, manifests, source-routing matrices, validation reports, and generated PDF/TeX outputs.

Code and verifier references are cited through manifests, archive evidence cards, receipt catalogs, or workbook replay tables. External datasets or
standards citations must be attached before any calibration-bound claim is
promoted.

### Reviewer Checklist

| Check | Reviewer question |
|---|---|
| Claim lane | Does every strong claim declare its lane and evidence type? |
| Boundary | Does the paper preserve what it does not prove? |
| Reproducibility | Is there a receipt, verifier, source card, citation, or replay table for the claim? |
| Cross-paper import | Does the paper cite the prior FLCR/OPR slot before consuming its result? |
| Interpretation | Does the analog layer preserve the addressed state while changing labels/access paths? |

### Declarations

No human-subjects, clinical, or animal-research protocol is asserted by this
paper. External empirical claims require separate dataset, calibration, or
domain-validation attachments. Competing-interest and funding statements are recorded in the submission metadata.

## 11. Publication Integration Addendum

### 11.1 Role In The Series

`FLCR-22` (`Protein Descriptor And Fold-Facing Kernel`) occupies the `fold_action` role at lift depth `2`.
The paper receives state emitted by prior slot 22 and reopened at original slot 23 (FoldForge Protein Folding). It produces formal result of original slot 23 plus the same-family lift path toward slot 33. The state transition is:
fold the local state into a higher representation while preserving addressability.

The paper-local proof form is:

```text
fold map, coordinate atlas, and representation transport
```

The integration result is a representation-transport chart with named invariants and residues. This addendum records how that result is
consumed by the publication series without relying on editorial instructions or
private working context.

### 11.2 Formal Carrier

| Formal carrier | Function |
|---|---|
| representation theory | Formal carrier for the paper-local result. |
| group actions and equivariance | Formal carrier for the paper-local result. |
| tensor or coordinate atlases | Formal carrier for the paper-local result. |
| transport maps between equivalent descriptions | Formal carrier for the paper-local result. |

The LCR, CAM, crystal, forge, and analog vocabulary functions as a typed access
layer over these carriers. A relabeling is admissible only when the addressed
object, evidence lane, boundary, and downstream import rule remain attached.

### 11.3 Claim Ledger

| Claim | Lane | Statement |
|---|---|---|
| Theorem 22.1 | `normal_form_result` | contact, homology, and winding descriptors can be staged as internal addressable features before biological validation |
| Proposition 22.2 | `normal_form_result` | fold descriptor kernel can be imported by later papers only through its declared source, receipt, and lane. |
| Protocol 22.3 | `falsifier_or_open_obligation` | native-structure prediction, fold-rate validation, and biological performance remain below full closure until datasets bind |

These claims are consumed at their stated lane. A stronger downstream statement
creates a new claim envelope with its own evidence object.

### 11.4 Evidence Package

| Evidence class | Routed items | Status |
|---|---|---|
| Legacy sources | `23_FoldForge_Protein_Folding.md`, `virtuous/23_FoldForge_Protein_Folding_VIRTUOUS.md`, `supplements/23_INTERNAL_REASONING_SUPPLEMENT.md` | routed evidence |
| Evidence inputs | `CAM_CLAIM_100_SCORE_AUDIT.md`, `NSIT_TOOL_CLOSURE_MATRIX.md`, `NSIT_REASONED_CLOSURE_PASS.md`, `PAPER_REWORKS_CRYSTAL_PROJECTION.json` | routed evidence |
| CAM/crystal sources | `PAPER_REWORKS_CRYSTAL_PROJECTION.json`, `AGENT_CRYSTAL_WORK_HARVEST.json`, `runtime standards artifact`, `notebook-derived source bundle` | routed evidence |
| Standards-window inputs | `window_summary.json`, `node DBs`, `window DBs` | routed evidence |
| Receipts | external requirement | not attached in this source package |
| Validators | external requirement | not attached in this source package |

Standards-window, runtime, and notebook-derived artifacts are treated
as evidence-routing surfaces. They support source discovery, conformance
checking, and reapplication, but they do not replace citations, receipts,
normal-form derivations, calibration rows, or falsifiers.

### 11.5 Results Representation

The paper's results section is organized around five publication objects:

1. the exact object acted on at this slot;
2. the admissible operation or transformation;
3. the receipt, enumeration, derivation, lookup, or external theorem supporting
   the operation;
4. the residue or boundary left after the result;
5. the downstream import rule.

### 11.6 Figures And Tables

| Figure | Role |
|---|---|
| FLCR-22-F1: Representation fold atlas | Visualizes the proof object, routing, or boundary. |
| FLCR-22-F2: Evidence routing map | Visualizes the proof object, routing, or boundary. |
| FLCR-22-F3: Same-family lift context | Visualizes the proof object, routing, or boundary. |

| Table | Role |
|---|---|
| FLCR-22-T1: Face/representation correspondence table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-22-T2: Claim-lane/evidence-boundary table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-22-T3: Archive evidence card and source-backed upgrade table | Records claim lanes, evidence, sources, or falsifiers. |
| FLCR-22-T4: Workbook replay and falsifier table | Records claim lanes, evidence, sources, or falsifiers. |

### 11.7 Limits And Falsifiers

The paper proves only the object and domain declared in its claim ledger.
Physical, Standard Model, observer, calibration, or synthesis claims require
the additional lane evidence stated by their destination papers. CAM/crystal
and forge language is operational only when represented as an address, lookup,
receipt, validator, or reapplication path.
